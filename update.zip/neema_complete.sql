SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS neema_db;
CREATE DATABASE neema_db;
USE neema_db;


CREATE TABLE Branches (
    BranchID INT PRIMARY KEY,
    CountyName VARCHAR(50) UNIQUE NOT NULL,
    OfficeStatus ENUM('Active', 'In Development', 'Closed') DEFAULT 'Active'
);

INSERT INTO Branches (BranchID, CountyName) VALUES 
(0, 'Nationwide'),
(1, 'Mombasa'), (2, 'Kwale'), (3, 'Kilifi'), (4, 'Tana River'), (5, 'Lamu'), 
(6, 'Taita Taveta'), (7, 'Garissa'), (8, 'Wajir'), (9, 'Mandera'), (10, 'Marsabit'), 
(11, 'Isiolo'), (12, 'Meru'), (13, 'Tharaka Nithi'), (14, 'Embu'), (15, 'Kitui'), 
(16, 'Machakos'), (17, 'Makueni'), (18, 'Nyandarua'), (19, 'Nyeri'), (20, 'Kirinyaga'), 
(21, 'Murang''a'), (22, 'Kiambu'), (23, 'Turkana'), (24, 'West Pokot'), (25, 'Samburu'), 
(26, 'Trans Nzoia'), (27, 'Uasin Gishu'), (28, 'Elgeyo Marakwet'), (29, 'Nandi'), (30, 'Baringo'), 
(31, 'Laikipia'), (32, 'Nakuru'), (33, 'Narok'), (34, 'Kajiado'), (35, 'Kericho'), 
(36, 'Bomet'), (37, 'Kakamega'), (38, 'Vihiga'), (39, 'Bungoma'), (40, 'Busia'), 
(41, 'Siaya'), (42, 'Kisumu'), (43, 'Homa Bay'), (44, 'Migori'), (45, 'Kisii'), 
(46, 'Nyamira'), (47, 'Nairobi');

CREATE TABLE Projects (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    ProjectType ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    Budget DECIMAL(15, 2),
    StartDate DATE,
    EndDate DATE,
    BranchID INT,
    ProjectLeadID INT,
    CONSTRAINT fk_project_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID),
    CONSTRAINT fk_project_lead
        FOREIGN KEY (ProjectLeadID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE ProjectTeam (
    AssignmentID INT PRIMARY KEY AUTO_INCREMENT,
    ProjectID INT,
    EmployeeID INT,
    ProjectRole VARCHAR(50), 
    CONSTRAINT fk_team_project
        FOREIGN KEY (ProjectID)
        REFERENCES Projects(ProjectID),
    CONSTRAINT fk_team_employee
        FOREIGN KEY (EmployeeID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Organizations (
    OrganizationID INT PRIMARY KEY,
    OrganizationName VARCHAR(150) NOT NULL,
    OrganizationFocus ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    BranchID INT,
    ContactEmail VARCHAR(100),
    ContactPhone VARCHAR(20),
    CONSTRAINT fk_org_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID)
);

CREATE TABLE Licenses (
    LicenseID INT PRIMARY KEY,
    OrganizationID INT,
    LicenseType ENUM('Environmental Impact', 'Waste Disposal', 'Water Abstraction', 'Emissions', 'Other') NOT NULL,
    ApplicationDate DATE NOT NULL,
    LicenseStatus ENUM('Pending Inspection', 'Approved', 'Rejected', 'Revoked') DEFAULT 'Pending Inspection',
    IssueDate DATE,
    ExpiryDate DATE,
    CONSTRAINT fk_license_org
        FOREIGN KEY (OrganizationID)
        REFERENCES Organizations(OrganizationID)
);

CREATE TABLE Inspections (
    InspectionID INT PRIMARY KEY AUTO_INCREMENT,
    LicenseID INT,
    InspectorID INT,
    InspectionDate DATE,
    InspectionResult ENUM('Pass', 'Fail', 'Pending Remediation', 'Scheduled') DEFAULT 'Scheduled',
    Remarks TEXT,
    CONSTRAINT fk_inspection_license
        FOREIGN KEY (LicenseID)
        REFERENCES Licenses(LicenseID),
    CONSTRAINT fk_inspection_inspector
        FOREIGN KEY (InspectorID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Incidents (
    IncidentID INT PRIMARY KEY AUTO_INCREMENT,
    IncidentType ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    IncidentDate DATE NOT NULL,
    Description TEXT,
    BranchID INT,
    ReportedByID INT,
    ResolutionStatus ENUM('Open', 'Investigating', 'Resolved', 'Closed') DEFAULT 'Open',
    CONSTRAINT fk_incident_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID),
    CONSTRAINT fk_incident_reporter
        FOREIGN KEY (ReportedByID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Donors (
    DonorID INT PRIMARY KEY AUTO_INCREMENT,
    DonorName VARCHAR(150) NOT NULL,
    DonorType ENUM('Government', 'Corporate', 'Foundation', 'Individual', 'International NGO') NOT NULL,
    ContactPerson VARCHAR(100),
    ContactEmail VARCHAR(100),
    ContactPhone VARCHAR(20)
);

CREATE TABLE ProjectFunding (
    FundingID INT PRIMARY KEY AUTO_INCREMENT,
    ProjectID INT,
    DonorID INT,
    Amount DECIMAL(15, 2) NOT NULL,
    FundingDate DATE NOT NULL,
    CONSTRAINT fk_funding_project
        FOREIGN KEY (ProjectID)
        REFERENCES Projects(ProjectID),
    CONSTRAINT fk_funding_donor
        FOREIGN KEY (DonorID)
        REFERENCES Donors(DonorID)
);

CREATE TABLE EnvironmentalAudits (
    AuditID INT PRIMARY KEY AUTO_INCREMENT,
    OrganizationID INT,
    LeadAuditorID INT,
    AuditFocus ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    AuditDate DATE NOT NULL,
    AuditStatus ENUM('Scheduled', 'In Progress', 'Completed', 'Overdue') DEFAULT 'Scheduled',
    ComplianceScore DECIMAL(5, 2),
    NextAuditDate DATE,
    CONSTRAINT fk_audit_org
        FOREIGN KEY (OrganizationID)
        REFERENCES Organizations(OrganizationID),
    CONSTRAINT fk_audit_auditor
        FOREIGN KEY (LeadAuditorID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE ResearchStudies (
    StudyID INT PRIMARY KEY AUTO_INCREMENT,
    StudyTitle VARCHAR(255) NOT NULL,
    FocusArea ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    LeadResearcherID INT,
    BranchID INT,
    StartDate DATE NOT NULL,
    EndDate DATE,
    StudyStatus ENUM('Proposed', 'Data Collection', 'Data Analysis', 'Published', 'Archived') DEFAULT 'Proposed',
    Abstract TEXT,
    CONSTRAINT fk_research_lead
        FOREIGN KEY (LeadResearcherID)
        REFERENCES Employees(EmployeeID),
    CONSTRAINT fk_research_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID)
);

CREATE TABLE ResearchFunding (
    ResearchFundingID INT PRIMARY KEY AUTO_INCREMENT,
    StudyID INT,
    DonorID INT,
    Amount DECIMAL(15, 2) NOT NULL,
    FundingDate DATE NOT NULL,
    GrantReferenceNumber VARCHAR(100),
    CONSTRAINT fk_researchfunding_study
        FOREIGN KEY (StudyID)
        REFERENCES ResearchStudies(StudyID),
    CONSTRAINT fk_researchfunding_donor
        FOREIGN KEY (DonorID)
        REFERENCES Donors(DonorID)
);

DROP DATABASE IF EXISTS neema_db;
CREATE DATABASE neema_db;
USE neema_db;

CREATE TABLE Branches (
    BranchID INT PRIMARY KEY,
    CountyName VARCHAR(50) UNIQUE NOT NULL,
    OfficeStatus ENUM('Active', 'In Development', 'Closed') DEFAULT 'Active'
);

INSERT INTO Branches (BranchID, CountyName) VALUES 
(0, 'Nationwide'),
(1, 'Mombasa'), (2, 'Kwale'), (3, 'Kilifi'), (4, 'Tana River'), (5, 'Lamu'), 
(6, 'Taita Taveta'), (7, 'Garissa'), (8, 'Wajir'), (9, 'Mandera'), (10, 'Marsabit'), 
(11, 'Isiolo'), (12, 'Meru'), (13, 'Tharaka Nithi'), (14, 'Embu'), (15, 'Kitui'), 
(16, 'Machakos'), (17, 'Makueni'), (18, 'Nyandarua'), (19, 'Nyeri'), (20, 'Kirinyaga'), 
(21, 'Murang''a'), (22, 'Kiambu'), (23, 'Turkana'), (24, 'West Pokot'), (25, 'Samburu'), 
(26, 'Trans Nzoia'), (27, 'Uasin Gishu'), (28, 'Elgeyo Marakwet'), (29, 'Nandi'), (30, 'Baringo'), 
(31, 'Laikipia'), (32, 'Nakuru'), (33, 'Narok'), (34, 'Kajiado'), (35, 'Kericho'), 
(36, 'Bomet'), (37, 'Kakamega'), (38, 'Vihiga'), (39, 'Bungoma'), (40, 'Busia'), 
(41, 'Siaya'), (42, 'Kisumu'), (43, 'Homa Bay'), (44, 'Migori'), (45, 'Kisii'), 
(46, 'Nyamira'), (47, 'Nairobi');

CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE,
    IDNumber VARCHAR(10) UNIQUE NOT NULL,
    Gender ENUM('Male', 'Female') NOT NULL,
    BranchID INT, 
    JobTitle ENUM('manager','expert','associate expert','subordinate') NOT NULL,
    ManagerID INT,
    CONSTRAINT fk_employee_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID),
    CONSTRAINT fk_manager
        FOREIGN KEY (ManagerID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Projects (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    ProjectType ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    Budget DECIMAL(15, 2),
    StartDate DATE,
    EndDate DATE,
    BranchID INT,
    ProjectLeadID INT,
    CONSTRAINT fk_project_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID),
    CONSTRAINT fk_project_lead
        FOREIGN KEY (ProjectLeadID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE ProjectTeam (
    AssignmentID INT PRIMARY KEY AUTO_INCREMENT,
    ProjectID INT,
    EmployeeID INT,
    ProjectRole VARCHAR(50), 
    CONSTRAINT fk_team_project
        FOREIGN KEY (ProjectID)
        REFERENCES Projects(ProjectID),
    CONSTRAINT fk_team_employee
        FOREIGN KEY (EmployeeID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Organizations (
    OrganizationID INT PRIMARY KEY,
    OrganizationName VARCHAR(150) NOT NULL,
    OrganizationFocus ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    BranchID INT,
    ContactEmail VARCHAR(100),
    ContactPhone VARCHAR(20),
    CONSTRAINT fk_org_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID)
);

CREATE TABLE Licenses (
    LicenseID INT PRIMARY KEY,
    OrganizationID INT,
    LicenseType ENUM('Environmental Impact', 'Waste Disposal', 'Water Abstraction', 'Emissions', 'Other') NOT NULL,
    ApplicationDate DATE NOT NULL,
    LicenseStatus ENUM('Pending Inspection', 'Approved', 'Rejected', 'Revoked') DEFAULT 'Pending Inspection',
    IssueDate DATE,
    ExpiryDate DATE,
    CONSTRAINT fk_license_org
        FOREIGN KEY (OrganizationID)
        REFERENCES Organizations(OrganizationID)
);

CREATE TABLE Inspections (
    InspectionID INT PRIMARY KEY AUTO_INCREMENT,
    LicenseID INT,
    InspectorID INT,
    InspectionDate DATE,
    InspectionResult ENUM('Pass', 'Fail', 'Pending Remediation', 'Scheduled') DEFAULT 'Scheduled',
    Remarks TEXT,
    CONSTRAINT fk_inspection_license
        FOREIGN KEY (LicenseID)
        REFERENCES Licenses(LicenseID),
    CONSTRAINT fk_inspection_inspector
        FOREIGN KEY (InspectorID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Incidents (
    IncidentID INT PRIMARY KEY AUTO_INCREMENT,
    IncidentType ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    IncidentDate DATE NOT NULL,
    Description TEXT,
    BranchID INT,
    ReportedByID INT,
    ResolutionStatus ENUM('Open', 'Investigating', 'Resolved', 'Closed') DEFAULT 'Open',
    CONSTRAINT fk_incident_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID),
    CONSTRAINT fk_incident_reporter
        FOREIGN KEY (ReportedByID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE Donors (
    DonorID INT PRIMARY KEY AUTO_INCREMENT,
    DonorName VARCHAR(150) NOT NULL,
    DonorType ENUM('Government', 'Corporate', 'Foundation', 'Individual', 'International NGO') NOT NULL,
    ContactPerson VARCHAR(100),
    ContactEmail VARCHAR(100),
    ContactPhone VARCHAR(20)
);

CREATE TABLE ProjectFunding (
    FundingID INT PRIMARY KEY AUTO_INCREMENT,
    ProjectID INT,
    DonorID INT,
    Amount DECIMAL(15, 2) NOT NULL,
    FundingDate DATE NOT NULL,
    CONSTRAINT fk_funding_project
        FOREIGN KEY (ProjectID)
        REFERENCES Projects(ProjectID),
    CONSTRAINT fk_funding_donor
        FOREIGN KEY (DonorID)
        REFERENCES Donors(DonorID)
);

CREATE TABLE EnvironmentalAudits (
    AuditID INT PRIMARY KEY AUTO_INCREMENT,
    OrganizationID INT,
    LeadAuditorID INT,
    AuditFocus ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    AuditDate DATE NOT NULL,
    AuditStatus ENUM('Scheduled', 'In Progress', 'Completed', 'Overdue') DEFAULT 'Scheduled',
    ComplianceScore DECIMAL(5, 2),
    NextAuditDate DATE,
    CONSTRAINT fk_audit_org
        FOREIGN KEY (OrganizationID)
        REFERENCES Organizations(OrganizationID),
    CONSTRAINT fk_audit_auditor
        FOREIGN KEY (LeadAuditorID)
        REFERENCES Employees(EmployeeID)
);

CREATE TABLE ResearchStudies (
    StudyID INT PRIMARY KEY AUTO_INCREMENT,
    StudyTitle VARCHAR(255) NOT NULL,
    FocusArea ENUM(
        'Public Health & Medicine', 
        'WASH (Water, Sanitation & Hygiene)',
        'Marine & Coastal Conservation',
        'Freshwater Ecosystems',
        'Waste Management & Circular Economy', 
        'Education & Skills Training', 
        'Wildlife Anti-Poaching & Rescue', 
        'Climate Action & Renewable Energy', 
        'Agriculture & Food Security', 
        'Community Empowerment',
        'Infrastructure Development',
        'Disaster Relief',
        'Other'
    ) NOT NULL,
    LeadResearcherID INT,
    BranchID INT,
    StartDate DATE NOT NULL,
    EndDate DATE,
    StudyStatus ENUM('Proposed', 'Data Collection', 'Data Analysis', 'Published', 'Archived') DEFAULT 'Proposed',
    Abstract TEXT,
    CONSTRAINT fk_research_lead
        FOREIGN KEY (LeadResearcherID)
        REFERENCES Employees(EmployeeID),
    CONSTRAINT fk_research_branch
        FOREIGN KEY (BranchID)
        REFERENCES Branches(BranchID)
);

CREATE TABLE ResearchFunding (
    ResearchFundingID INT PRIMARY KEY AUTO_INCREMENT,
    StudyID INT,
    DonorID INT,
    Amount DECIMAL(15, 2) NOT NULL,
    FundingDate DATE NOT NULL,
    GrantReferenceNumber VARCHAR(100),
    CONSTRAINT fk_researchfunding_study
        FOREIGN KEY (StudyID)
        REFERENCES ResearchStudies(StudyID),
    CONSTRAINT fk_researchfunding_donor
        FOREIGN KEY (DonorID)
        REFERENCES Donors(DonorID)
);
SHOW DATABASES;

USE neema_db;

DELIMITER //

CREATE PROCEDURE sp_AddBranch(
    IN p_BranchID INT, IN p_CountyName VARCHAR(50), IN p_Status VARCHAR(20)
)
BEGIN
    INSERT INTO Branches (BranchID, CountyName, OfficeStatus)
    VALUES (p_BranchID, p_CountyName, p_Status);
END //

CREATE PROCEDURE sp_AddEmployee(
    IN p_EmpID INT, IN p_FName VARCHAR(50), IN p_LName VARCHAR(50), IN p_DOB DATE, 
    IN p_IDNum VARCHAR(10), IN p_Gender VARCHAR(10), IN p_BranchID INT, 
    IN p_Title VARCHAR(50), IN p_ManagerID INT
)
BEGIN
    INSERT INTO Employees (EmployeeID, FirstName, LastName, DateOfBirth, IDNumber, Gender, BranchID, JobTitle, ManagerID)
    VALUES (p_EmpID, p_FName, p_LName, p_DOB, p_IDNum, p_Gender, p_BranchID, p_Title, p_ManagerID);
END //

CREATE PROCEDURE sp_AddProject(
    IN p_ProjID INT, IN p_Name VARCHAR(100), IN p_Type VARCHAR(100), IN p_Budget DECIMAL(15,2), 
    IN p_Start DATE, IN p_End DATE, IN p_BranchID INT, IN p_LeadID INT
)
BEGIN
    INSERT INTO Projects (ProjectID, ProjectName, ProjectType, Budget, StartDate, EndDate, BranchID, ProjectLeadID)
    VALUES (p_ProjID, p_Name, p_Type, p_Budget, p_Start, p_End, p_BranchID, p_LeadID);
END //

CREATE PROCEDURE sp_AddProjectTeamMember(
    IN p_ProjID INT, IN p_EmpID INT, IN p_Role VARCHAR(50)
)
BEGIN
    INSERT INTO ProjectTeam (ProjectID, EmployeeID, ProjectRole)
    VALUES (p_ProjID, p_EmpID, p_Role);
END //

CREATE PROCEDURE sp_AddOrganization(
    IN p_OrgID INT, IN p_Name VARCHAR(150), IN p_Focus VARCHAR(100), 
    IN p_BranchID INT, IN p_Email VARCHAR(100), IN p_Phone VARCHAR(20)
)
BEGIN
    INSERT INTO Organizations (OrganizationID, OrganizationName, OrganizationFocus, BranchID, ContactEmail, ContactPhone)
    VALUES (p_OrgID, p_Name, p_Focus, p_BranchID, p_Email, p_Phone);
END //

CREATE PROCEDURE sp_AddLicense(
    IN p_LicID INT, IN p_OrgID INT, IN p_Type VARCHAR(50), 
    IN p_AppDate DATE, IN p_Status VARCHAR(30), IN p_Issue DATE, IN p_Expiry DATE
)
BEGIN
    INSERT INTO Licenses (LicenseID, OrganizationID, LicenseType, ApplicationDate, LicenseStatus, IssueDate, ExpiryDate)
    VALUES (p_LicID, p_OrgID, p_Type, p_AppDate, p_Status, p_Issue, p_Expiry);
END //

CREATE PROCEDURE sp_AddInspection(
    IN p_LicID INT, IN p_InspectorID INT, IN p_Date DATE, 
    IN p_Result VARCHAR(30), IN p_Remarks TEXT
)
BEGIN
    INSERT INTO Inspections (LicenseID, InspectorID, InspectionDate, InspectionResult, Remarks)
    VALUES (p_LicID, p_InspectorID, p_Date, p_Result, p_Remarks);
END //

CREATE PROCEDURE sp_AddIncident(
    IN p_Type VARCHAR(100), IN p_Date DATE, IN p_Desc TEXT, 
    IN p_BranchID INT, IN p_ReporterID INT, IN p_Status VARCHAR(20)
)
BEGIN
    INSERT INTO Incidents (IncidentType, IncidentDate, Description, BranchID, ReportedByID, ResolutionStatus)
    VALUES (p_Type, p_Date, p_Desc, p_BranchID, p_ReporterID, p_Status);
END //

CREATE PROCEDURE sp_AddDonor(
    IN p_Name VARCHAR(150), IN p_Type VARCHAR(50), IN p_Person VARCHAR(100), 
    IN p_Email VARCHAR(100), IN p_Phone VARCHAR(20)
)
BEGIN
    INSERT INTO Donors (DonorName, DonorType, ContactPerson, ContactEmail, ContactPhone)
    VALUES (p_Name, p_Type, p_Person, p_Email, p_Phone);
END //

CREATE PROCEDURE sp_AddProjectFunding(
    IN p_ProjID INT, IN p_DonorID INT, IN p_Amount DECIMAL(15,2), IN p_Date DATE
)
BEGIN
    INSERT INTO ProjectFunding (ProjectID, DonorID, Amount, FundingDate)
    VALUES (p_ProjID, p_DonorID, p_Amount, p_Date);
END //

CREATE PROCEDURE sp_AddAudit(
    IN p_OrgID INT, IN p_LeadID INT, IN p_Focus VARCHAR(100), IN p_Date DATE, 
    IN p_Status VARCHAR(30), IN p_Score DECIMAL(5,2), IN p_NextDate DATE
)
BEGIN
    INSERT INTO EnvironmentalAudits (OrganizationID, LeadAuditorID, AuditFocus, AuditDate, AuditStatus, ComplianceScore, NextAuditDate)
    VALUES (p_OrgID, p_LeadID, p_Focus, p_Date, p_Status, p_Score, p_NextDate);
END //

CREATE PROCEDURE sp_AddResearchStudy(
    IN p_Title VARCHAR(255), IN p_Focus VARCHAR(100), IN p_LeadID INT, 
    IN p_BranchID INT, IN p_Start DATE, IN p_End DATE, IN p_Status VARCHAR(30), IN p_Abstract TEXT
)
BEGIN
    INSERT INTO ResearchStudies (StudyTitle, FocusArea, LeadResearcherID, BranchID, StartDate, EndDate, StudyStatus, Abstract)
    VALUES (p_Title, p_Focus, p_LeadID, p_BranchID, p_Start, p_End, p_Status, p_Abstract);
END //

CREATE PROCEDURE sp_AddResearchFunding(
    IN p_StudyID INT, IN p_DonorID INT, IN p_Amount DECIMAL(15,2), 
    IN p_Date DATE, IN p_GrantRef VARCHAR(100)
)
BEGIN
    INSERT INTO ResearchFunding (StudyID, DonorID, Amount, FundingDate, GrantReferenceNumber)
    VALUES (p_StudyID, p_DonorID, p_Amount, p_Date, p_GrantRef);
END //

DELIMITER ;

CREATE VIEW VW_Report_HR_Directory AS
SELECT 
    e.EmployeeID, CONCAT(e.FirstName, ' ', e.LastName) AS 'Employee Name',
    e.JobTitle AS 'Title', b.CountyName AS 'Assigned Branch',
    CONCAT(m.FirstName, ' ', m.LastName) AS 'Manager Name'
FROM Employees e
JOIN Branches b ON e.BranchID = b.BranchID
LEFT JOIN Employees m ON e.ManagerID = m.EmployeeID;

CREATE VIEW VW_Report_Regulatory_Compliance AS
SELECT 
    o.OrganizationName, o.OrganizationFocus AS 'Industry', b.CountyName AS 'Location',
    l.LicenseType, l.LicenseStatus, 
    a.AuditDate AS 'Last Audit', a.ComplianceScore AS 'Audit Score'
FROM Organizations o
JOIN Branches b ON o.BranchID = b.BranchID
LEFT JOIN Licenses l ON o.OrganizationID = l.OrganizationID
LEFT JOIN EnvironmentalAudits a ON o.OrganizationID = a.OrganizationID;

CREATE VIEW VW_Report_Incidents_Log AS
SELECT 
    i.IncidentID, i.IncidentDate, i.IncidentType, b.CountyName AS 'Location', 
    i.ResolutionStatus, CONCAT(e.FirstName, ' ', e.LastName) AS 'Reported By'
FROM Incidents i
JOIN Branches b ON i.BranchID = b.BranchID
JOIN Employees e ON i.ReportedByID = e.EmployeeID;

CREATE VIEW VW_Report_Financial_Donations AS
SELECT 
    d.DonorName, d.DonorType, 
    COALESCE(SUM(pf.Amount), 0) AS 'Total Project Funding',
    COALESCE(SUM(rf.Amount), 0) AS 'Total Research Funding',
    (COALESCE(SUM(pf.Amount), 0) + COALESCE(SUM(rf.Amount), 0)) AS 'Grand Total Given'
FROM Donors d
LEFT JOIN ProjectFunding pf ON d.DonorID = pf.DonorID
LEFT JOIN ResearchFunding rf ON d.DonorID = rf.DonorID
GROUP BY d.DonorID, d.DonorName, d.DonorType;

CREATE VIEW VW_Report_Projects_Overview AS
SELECT 
    p.ProjectName, p.ProjectType, b.CountyName AS 'Location', 
    p.Budget, CONCAT(e.FirstName, ' ', e.LastName) AS 'Project Lead'
FROM Projects p
JOIN Branches b ON p.BranchID = b.BranchID
JOIN Employees e ON p.ProjectLeadID = e.EmployeeID;

CREATE VIEW VW_Report_Research_Portfolio AS
SELECT 
    rs.StudyTitle, rs.FocusArea, rs.StudyStatus, 
    CONCAT(e.FirstName, ' ', e.LastName) AS 'Lead Researcher',
    b.CountyName AS 'Location',
    COALESCE(SUM(rf.Amount), 0) AS 'Total Funding Received'
FROM ResearchStudies rs
JOIN Employees e ON rs.LeadResearcherID = e.EmployeeID
JOIN Branches b ON rs.BranchID = b.BranchID
LEFT JOIN ResearchFunding rf ON rs.StudyID = rf.StudyID
GROUP BY rs.StudyID, rs.StudyTitle, rs.FocusArea, rs.StudyStatus, e.FirstName, e.LastName, b.CountyName;

USE neema_db;

DROP USER IF EXISTS 'neema_admin'@'localhost'; CREATE USER 'neema_admin'@'localhost' IDENTIFIED BY 'NeemaAdmin2026!';
GRANT ALL PRIVILEGES ON neema_db.* TO 'neema_admin'@'localhost';

DROP USER IF EXISTS 'neema_employee'@'localhost'; CREATE USER 'neema_employee'@'localhost' IDENTIFIED BY 'NeemaEmp2026!';
DROP USER IF EXISTS 'neema_manager'@'localhost';
CREATE USER 'neema_manager'@'localhost' IDENTIFIED BY 'NeemaManager2026!';
GRANT SELECT ON neema_db.VW_Report_HR_Directory TO 'neema_employee'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Regulatory_Compliance TO 'neema_employee'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Incidents_Log TO 'neema_employee'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Financial_Donations TO 'neema_employee'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Projects_Overview TO 'neema_employee'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Research_Portfolio TO 'neema_employee'@'localhost';
GRANT EXECUTE ON neema_db.* TO 'neema_employee'@'localhost';

GRANT SELECT ON neema_db.VW_Report_HR_Directory TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Regulatory_Compliance TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Incidents_Log TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Financial_Donations TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Projects_Overview TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.VW_Report_Research_Portfolio TO 'neema_manager'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON neema_db.Employees TO 'neema_manager'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON neema_db.Projects TO 'neema_manager'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON neema_db.Incidents TO 'neema_manager'@'localhost';
GRANT SELECT ON neema_db.Branches TO 'neema_manager'@'localhost';
GRANT EXECUTE ON neema_db.* TO 'neema_manager'@'localhost';

FLUSH PRIVILEGES;

USE neema_db;

SELECT '--- NEEMA OPERATIONS DASHBOARD ---' AS 'Welcome';

SELECT * FROM VW_Report_Projects_Overview;

SELECT * FROM VW_Report_Incidents_Log;

SELECT * FROM VW_Report_Regulatory_Compliance;

SELECT * FROM VW_Report_Financial_Donations;

SELECT * FROM VW_Report_Research_Portfolio;

SELECT * FROM VW_Report_HR_Directory;

USE neema_db;

INSERT INTO Employees (EmployeeID, FirstName, LastName, DateOfBirth, IDNumber, Gender, BranchID, JobTitle, ManagerID) VALUES 
(101, 'Amina', 'Mohammed', '1982-04-12', 'ID-99382', 'Female', 47, 'manager', NULL),
(102, 'David', 'Ochieng', '1990-08-22', 'ID-88271', 'Male', 42, 'expert', 101),
(103, 'Sarah', 'Wanjiku', '1993-11-05', 'ID-77362', 'Female', 33, 'associate expert', 101),
(104, 'Daniel', 'Mutua', '1995-02-18', 'ID-66453', 'Male', 1, 'subordinate', 102),
(105, 'Grace', 'Kiprono', '1988-09-30', 'ID-55544', 'Female', 36, 'expert', 101);

INSERT INTO Projects (ProjectID, ProjectName, ProjectType, Budget, StartDate, EndDate, BranchID, ProjectLeadID) VALUES 
(1, 'Nairobi River Cleanup', 'WASH (Water, Sanitation & Hygiene)', 5500000.00, '2025-06-01', '2026-12-31', 47, 101),
(2, 'Mara Anti-Poaching Drone Unit', 'Wildlife Anti-Poaching & Rescue', 8200000.00, '2026-01-15', '2027-01-15', 33, 103),
(3, 'Mombasa Coral Restoration', 'Marine & Coastal Conservation', 4100000.00, '2025-10-01', '2026-10-01', 1, 104),
(4, 'Kisumu Waste-to-Energy', 'Waste Management & Circular Economy', 9500000.00, '2026-02-01', '2028-02-01', 42, 102),
(5, 'Bomet Reforestation Initiative', 'Climate Action & Renewable Energy', 3000000.00, '2025-08-20', '2026-08-20', 36, 105);

INSERT INTO ProjectTeam (ProjectID, EmployeeID, ProjectRole) VALUES 
(1, 101, 'Project Director'),
(1, 102, 'Water Quality Analyst'),
(2, 103, 'Drone Operator'),
(3, 104, 'Marine Biologist'),
(4, 102, 'Energy Consultant'),
(5, 105, 'Lead Botanist');

INSERT INTO Organizations (OrganizationID, OrganizationName, OrganizationFocus, BranchID, ContactEmail, ContactPhone) VALUES 
(1, 'EcoPlastics Kenya', 'Waste Management & Circular Economy', 47, 'info@ecoplastics.co.ke', '0700111222'),
(2, 'Lake Basin Fisheries', 'Freshwater Ecosystems', 42, 'contact@lakebasin.co.ke', '0711222333'),
(3, 'Savannah Tourism Partners', 'Wildlife Anti-Poaching & Rescue', 33, 'hello@savannahtourism.com', '0722333444'),
(4, 'Pwani Shipping Lines', 'Marine & Coastal Conservation', 1, 'compliance@pwanishipping.com', '0733444555'),
(5, 'Green Farms Ltd', 'Agriculture & Food Security', 36, 'agri@greenfarms.co.ke', '0744555666');

INSERT INTO Licenses (LicenseID, OrganizationID, LicenseType, ApplicationDate, LicenseStatus, IssueDate, ExpiryDate) VALUES 
(1, 1, 'Waste Disposal', '2026-01-10', 'Approved', '2026-01-25', '2027-01-25'),
(2, 2, 'Water Abstraction', '2026-02-15', 'Pending Inspection', NULL, NULL),
(3, 3, 'Environmental Impact', '2025-11-20', 'Approved', '2025-12-05', '2026-12-05'),
(4, 4, 'Emissions', '2026-03-01', 'Pending Inspection', NULL, NULL),
(5, 5, 'Environmental Impact', '2026-01-05', 'Rejected', NULL, NULL);

INSERT INTO Inspections (LicenseID, InspectorID, InspectionDate, InspectionResult, Remarks) VALUES 
(1, 102, '2026-01-20', 'Pass', 'Facility meets all local waste disposal guidelines.'),
(2, 102, '2026-03-20', 'Scheduled', 'Awaiting inspector availability.'),
(3, 103, '2025-11-30', 'Pass', 'Ecolodge construction plans approved.'),
(4, 104, '2026-03-18', 'Scheduled', 'Vessel emissions check scheduled at port.'),
(5, 105, '2026-01-15', 'Fail', 'Agricultural runoff prevention measures are inadequate.');

INSERT INTO Incidents (IncidentType, IncidentDate, Description, BranchID, ReportedByID, ResolutionStatus) VALUES 
('Waste Management & Circular Economy', '2026-02-28', 'Illegal dumping of industrial chemicals near residential area.', 47, 101, 'Investigating'),
('Wildlife Anti-Poaching & Rescue', '2026-03-10', 'Injured giraffe reported near the reserve border.', 33, 103, 'Resolved'),
('Marine & Coastal Conservation', '2026-03-12', 'Oil slick spotted 2 nautical miles off the coast.', 1, 104, 'Open'),
('Freshwater Ecosystems', '2026-01-25', 'Unusual fish die-off recorded in the bay.', 42, 102, 'Closed'),
('Climate Action & Renewable Energy', '2026-03-05', 'Wildfire contained at the edge of the protected forest block.', 36, 105, 'Resolved');

INSERT INTO Donors (DonorName, DonorType, ContactPerson, ContactEmail, ContactPhone) VALUES 
('Global Environment Fund', 'International NGO', 'Alice Smith', 'asmith@gef.org', '+18005551234'),
('Safaricom Foundation', 'Corporate', 'Joseph Kamau', 'jkamau@safaricom.co.ke', '0722000000'),
('Ministry of Environment', 'Government', 'Hon. Jane Doe', 'ps@environment.go.ke', '0201234567'),
('Wildlife Trust Africa', 'Foundation', 'Dr. Richard Leakey', 'rleakey@wta.org', '0733000000'),
('Blue Ocean Initiative', 'International NGO', 'Maria Gonzalez', 'mgonzalez@blueocean.org', '+447700900123');

INSERT INTO ProjectFunding (ProjectID, DonorID, Amount, FundingDate) VALUES 
(1, 2, 2500000.00, '2025-05-15'),
(1, 3, 3000000.00, '2025-05-20'),
(2, 4, 8200000.00, '2025-12-10'),
(3, 5, 4100000.00, '2025-09-05'),
(4, 1, 9500000.00, '2026-01-15');

INSERT INTO EnvironmentalAudits (OrganizationID, LeadAuditorID, AuditFocus, AuditDate, AuditStatus, ComplianceScore, NextAuditDate) VALUES 
(1, 102, 'Waste Management & Circular Economy', '2025-10-10', 'Completed', 92.50, '2026-10-10'),
(2, 102, 'Freshwater Ecosystems', '2026-04-15', 'Scheduled', NULL, NULL),
(3, 103, 'Wildlife Anti-Poaching & Rescue', '2026-02-20', 'Completed', 88.00, '2027-02-20'),
(4, 104, 'Marine & Coastal Conservation', '2025-08-05', 'Completed', 75.20, '2026-08-05'),
(5, 105, 'Agriculture & Food Security', '2026-03-01', 'In Progress', NULL, NULL);

INSERT INTO ResearchStudies (StudyTitle, FocusArea, LeadResearcherID, BranchID, StartDate, EndDate, StudyStatus, Abstract) VALUES 
('Impact of Microplastics on Mombasa Coral', 'Marine & Coastal Conservation', 104, 1, '2025-01-01', '2026-12-31', 'Data Collection', 'A two-year study assessing the degradation of coral reefs due to urban microplastic runoff.'),
('Nairobi River Toxicity Levels Q1', 'WASH (Water, Sanitation & Hygiene)', 101, 47, '2026-01-01', '2026-03-31', 'Data Analysis', 'Quarterly analysis of heavy metal concentrations in the upper basin.'),
('Drone Efficacy in Rhino Tracking', 'Wildlife Anti-Poaching & Rescue', 103, 33, '2025-06-01', '2025-12-31', 'Published', 'Analyzing the response time improvements using thermal imaging drones.'),
('Lake Victoria Algal Bloom Patterns', 'Freshwater Ecosystems', 102, 42, '2026-03-01', '2027-03-01', 'Data Collection', 'Tracking the seasonal growth of invasive algae utilizing satellite data.'),
('Soil Nutrient Depletion in Bomet', 'Agriculture & Food Security', 105, 36, '2026-04-01', '2026-10-01', 'Proposed', 'Proposed study on the impact of monocrop farming on indigenous soil health.');

INSERT INTO ResearchFunding (StudyID, DonorID, Amount, FundingDate, GrantReferenceNumber) VALUES 
(1, 5, 1200000.00, '2024-11-15', 'BOI-2025-MRN'),
(2, 3, 500000.00, '2025-12-01', 'GOV-NRB-001'),
(3, 4, 1800000.00, '2025-05-20', 'WTA-TECH-99'),
(4, 1, 2200000.00, '2026-02-10', 'GEF-LAKE-44'),
(5, 2, 750000.00, '2026-03-10', 'SAF-AGRI-02');



USE neema_db;


DELIMITER $$

DROP PROCEDURE IF EXISTS sp_welcome$$

CREATE PROCEDURE sp_welcome()
BEGIN
    DECLARE v_user VARCHAR(100);
    DECLARE v_hour INT;
    DECLARE v_greeting VARCHAR(20);
    DECLARE v_projects INT;
    DECLARE v_incidents_open INT;
    DECLARE v_pending_licenses INT;

    SET v_user  = CURRENT_USER();
    SET v_hour  = HOUR(NOW());

    IF v_hour < 12 THEN
        SET v_greeting = 'Good morning';
    ELSEIF v_hour < 18 THEN
        SET v_greeting = 'Good afternoon';
    ELSE
        SET v_greeting = 'Good evening';
    END IF;

    SELECT COUNT(*) INTO v_projects         FROM Projects;
    SELECT COUNT(*) INTO v_incidents_open   FROM Incidents WHERE ResolutionStatus IN ('Open','Investigating');
    SELECT COUNT(*) INTO v_pending_licenses FROM Licenses  WHERE LicenseStatus = 'Pending Inspection';

    SELECT '╔══════════════════════════════════════════════════╗' AS '';
    SELECT '║         NEEMA ENVIRONMENTAL MGMT SYSTEM          ║' AS '';
    SELECT '║           mazingira yetu | uhai wetu              ║' AS '';
    SELECT '╚══════════════════════════════════════════════════╝' AS '';

    SELECT CONCAT(v_greeting, ', ', v_user, '! Welcome to Neema DB.') AS 'Welcome';
    SELECT CONCAT('Connected at: ', DATE_FORMAT(NOW(), '%W %d %M %Y, %H:%i')) AS 'Session Info';

    IF v_user LIKE 'neema_admin%' THEN
        SELECT 'Role: ADMINISTRATOR — Full read/write access to all tables.' AS 'Access Level';
    ELSEIF v_user LIKE 'neema_employee%' THEN
        SELECT 'Role: EMPLOYEE — Read access to reports and views only.' AS 'Access Level';
    ELSE
        SELECT 'Role: UNKNOWN — Contact your administrator.' AS 'Access Level';
    END IF;

    SELECT
        v_projects           AS 'Total Projects',
        v_incidents_open     AS 'Open Incidents',
        v_pending_licenses   AS 'Pending Licenses';

    SELECT 'Type: CALL sp_welcome(); to see this again.' AS 'Tip';
END$$


DROP PROCEDURE IF EXISTS sp_add_image_columns$$

CREATE PROCEDURE sp_add_image_columns()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Employees' AND COLUMN_NAME = 'photo_url') THEN
        ALTER TABLE Employees ADD COLUMN photo_url VARCHAR(255) DEFAULT NULL;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Projects' AND COLUMN_NAME = 'cover_url') THEN
        ALTER TABLE Projects ADD COLUMN cover_url VARCHAR(255) DEFAULT NULL;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Organizations' AND COLUMN_NAME = 'logo_url') THEN
        ALTER TABLE Organizations ADD COLUMN logo_url VARCHAR(255) DEFAULT NULL;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Incidents' AND COLUMN_NAME = 'photo_url') THEN
        ALTER TABLE Incidents ADD COLUMN photo_url VARCHAR(255) DEFAULT NULL;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ResearchStudies' AND COLUMN_NAME = 'cover_url') THEN
        ALTER TABLE ResearchStudies ADD COLUMN cover_url VARCHAR(255) DEFAULT NULL;
    END IF;
END$$


DROP FUNCTION IF EXISTS fn_full_name$$

CREATE FUNCTION fn_full_name(p_employee_id INT)
RETURNS VARCHAR(101)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_name VARCHAR(101);
    SELECT CONCAT(FirstName, ' ', LastName) INTO v_name
    FROM Employees WHERE EmployeeID = p_employee_id;
    RETURN IFNULL(v_name, 'Unknown');
END$$


DROP FUNCTION IF EXISTS fn_employee_count_by_branch$$

CREATE FUNCTION fn_employee_count_by_branch(p_branch_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM Employees WHERE BranchID = p_branch_id;
    RETURN v_count;
END$$


DROP FUNCTION IF EXISTS fn_project_duration_days$$

CREATE FUNCTION fn_project_duration_days(p_project_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_days INT;
    SELECT DATEDIFF(IFNULL(EndDate, CURDATE()), StartDate) INTO v_days
    FROM Projects WHERE ProjectID = p_project_id;
    RETURN IFNULL(v_days, 0);
END$$


DROP FUNCTION IF EXISTS fn_project_status$$

CREATE FUNCTION fn_project_status(p_project_id INT)
RETURNS VARCHAR(20)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_start DATE;
    DECLARE v_end   DATE;
    SELECT StartDate, EndDate INTO v_start, v_end
    FROM Projects WHERE ProjectID = p_project_id;
    IF v_start > CURDATE() THEN
        RETURN 'Not Started';
    ELSEIF v_end IS NULL OR v_end >= CURDATE() THEN
        RETURN 'Active';
    ELSE
        RETURN 'Completed';
    END IF;
END$$


DROP FUNCTION IF EXISTS fn_total_project_funding$$

CREATE FUNCTION fn_total_project_funding(p_project_id INT)
RETURNS DECIMAL(15,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(15,2);
    SELECT COALESCE(SUM(Amount), 0) INTO v_total
    FROM ProjectFunding WHERE ProjectID = p_project_id;
    RETURN v_total;
END$$


DROP FUNCTION IF EXISTS fn_budget_utilisation_pct$$

CREATE FUNCTION fn_budget_utilisation_pct(p_project_id INT)
RETURNS DECIMAL(5,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_budget  DECIMAL(15,2);
    DECLARE v_funded  DECIMAL(15,2);
    SELECT Budget INTO v_budget FROM Projects WHERE ProjectID = p_project_id;
    SET v_funded = fn_total_project_funding(p_project_id);
    IF IFNULL(v_budget, 0) = 0 THEN
        RETURN 0;
    END IF;
    RETURN ROUND((v_funded / v_budget) * 100, 2);
END$$


DROP FUNCTION IF EXISTS fn_license_is_expired$$

CREATE FUNCTION fn_license_is_expired(p_license_id INT)
RETURNS VARCHAR(3)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_expiry DATE;
    SELECT ExpiryDate INTO v_expiry FROM Licenses WHERE LicenseID = p_license_id;
    IF v_expiry IS NULL THEN
        RETURN 'N/A';
    ELSEIF v_expiry < CURDATE() THEN
        RETURN 'YES';
    ELSE
        RETURN 'NO';
    END IF;
END$$


DROP FUNCTION IF EXISTS fn_days_to_license_expiry$$

CREATE FUNCTION fn_days_to_license_expiry(p_license_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_expiry DATE;
    SELECT ExpiryDate INTO v_expiry FROM Licenses WHERE LicenseID = p_license_id;
    IF v_expiry IS NULL THEN
        RETURN NULL;
    END IF;
    RETURN DATEDIFF(v_expiry, CURDATE());
END$$


DROP FUNCTION IF EXISTS fn_org_compliance_score$$

CREATE FUNCTION fn_org_compliance_score(p_org_id INT)
RETURNS DECIMAL(5,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_score DECIMAL(5,2);
    SELECT ROUND(AVG(ComplianceScore), 2) INTO v_score
    FROM EnvironmentalAudits
    WHERE OrganizationID = p_org_id AND ComplianceScore IS NOT NULL;
    RETURN IFNULL(v_score, 0);
END$$


DROP FUNCTION IF EXISTS fn_incident_count_by_branch$$

CREATE FUNCTION fn_incident_count_by_branch(p_branch_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM Incidents WHERE BranchID = p_branch_id;
    RETURN v_count;
END$$


DROP FUNCTION IF EXISTS fn_open_incidents_by_branch$$

CREATE FUNCTION fn_open_incidents_by_branch(p_branch_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM Incidents
    WHERE BranchID = p_branch_id
      AND ResolutionStatus IN ('Open', 'Investigating');
    RETURN v_count;
END$$


DROP FUNCTION IF EXISTS fn_total_donor_contributions$$

CREATE FUNCTION fn_total_donor_contributions(p_donor_id INT)
RETURNS DECIMAL(15,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_project_total  DECIMAL(15,2);
    DECLARE v_research_total DECIMAL(15,2);
    SELECT COALESCE(SUM(Amount), 0) INTO v_project_total
    FROM ProjectFunding WHERE DonorID = p_donor_id;
    SELECT COALESCE(SUM(Amount), 0) INTO v_research_total
    FROM ResearchFunding WHERE DonorID = p_donor_id;
    RETURN v_project_total + v_research_total;
END$$


DROP FUNCTION IF EXISTS fn_format_kes$$

CREATE FUNCTION fn_format_kes(p_amount DECIMAL(15,2))
RETURNS VARCHAR(30)
DETERMINISTIC
NO SQL
BEGIN
    RETURN CONCAT('KES ', FORMAT(p_amount, 2));
END$$


DROP FUNCTION IF EXISTS fn_branch_name$$

CREATE FUNCTION fn_branch_name(p_branch_id INT)
RETURNS VARCHAR(50)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_name VARCHAR(50);
    SELECT CountyName INTO v_name FROM Branches WHERE BranchID = p_branch_id;
    RETURN IFNULL(v_name, 'Unknown');
END$$


DROP FUNCTION IF EXISTS fn_manager_name$$

CREATE FUNCTION fn_manager_name(p_employee_id INT)
RETURNS VARCHAR(101)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_manager_id INT;
    DECLARE v_name       VARCHAR(101);
    SELECT ManagerID INTO v_manager_id FROM Employees WHERE EmployeeID = p_employee_id;
    IF v_manager_id IS NULL THEN
        RETURN 'No Manager';
    END IF;
    SELECT CONCAT(FirstName, ' ', LastName) INTO v_name
    FROM Employees WHERE EmployeeID = v_manager_id;
    RETURN IFNULL(v_name, 'Unknown');
END$$


DELIMITER ;

CALL sp_welcome();
CALL sp_add_image_columns();


CREATE TABLE IF NOT EXISTS AppSettings (
    SettingKey   VARCHAR(100) PRIMARY KEY,
    SettingValue TEXT,
    ImageData    LONGBLOB,
    UpdatedAt    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO AppSettings (SettingKey, SettingValue) VALUES
('org_name',    'Neema Environmental Management'),
('org_country', 'Kenya'),
('org_tagline', 'mazingira yetu | uhai wetu | wajibu wetu'),
('db_version',  '1.0.0')
ON DUPLICATE KEY UPDATE SettingValue = VALUES(SettingValue);

INSERT INTO AppSettings (SettingKey, SettingValue, ImageData)
VALUES ('app_icon', 'nema.png', FROM_BASE64('/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASwBLADASIAAhEBAxEB/8QAHQABAAEEAwEAAAAAAAAAAAAAAAECBgcIAwQFCf/EAFEQAAIBAwMCAgYECwQHBgYCAwABAgMEEQUGIQcxEkEIEyJRYXEUMnOxFSMzNDY3QnJ0gZFSYpKhFhcYJDVTwUNEVGOy0SUnOIKT8CbhVWSD/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAUGAQMEAgf/xAAxEQEAAgEDAwQBAwQCAgMBAAAAAQIDBAUREiExEzIzQVEGFCIVQmFxI4FDUiQ0wRb/2gAMAwEAAhEDEQA/ANywAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYpXuY5FQI5TwQu5hjlUCkhteTMnMKwcfjjFZlJHVr6lZ0c+srwjj3s9VrNvENd81Ke6XeB4dbcmlU/8AvtLPzOnX3fptPOK8JfJm2umy28Q5r7jp6ebLoyveCya2+7KDfhj4sfE68+odtFcW8n/NGyNBqJ8VaJ3rSR5sv7K94yvejHEupVLOPoM3/MLqVRx+Y1F/Q9f03Vf+rx/XdF/7Mjgx/b9Rbao/at5Q+Zzx3/aOeHDj35PM7fqY81eq73o7eLL5BaVPelhLw+KSin25O9R3Ppc0s3lJfDxHi2ly18w3U3PT38We+Dy6GtadV+pdU5fJndp16VVZhUT/AJmmaWr5h1U1GO/iXOChP4k58snmG3mFTeAU4I48u4OVYIbQ4aMcspBS1l5XBUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJPAEgjPBPkY8AQhkhzSXODLzzEKn2KW8Hlalr2n2alGrc04yXk2WfqvUKEJSp29DxrspJnTh0ebL7YR+p3TT4PdLINSvCnzKSSR511r2mW0vDVuqcZe5sxFqW59WvJvw3E4QfkeTWrVa9Tx1pucvfklcOyzb3yr+o/U/T8cMo6tvy0tm1Sp+sx7mW/fb+uKzaoUpU+Mdyysc4xlE5S88Eli2rDj8oPPvuozeHs1t0a3VyleTUW+x0Kuo31Zt1q8pZ+J1PHzwdilZXlZJ0qEp59yOv0dPjjxDh/carLPmXBJOTy2+fiU+BfE9OOhazLCVhVafwO9b7S1So03RnBefBqnU6arbGj1mRb/hJwl5l30tiX03iVRxz54Ox/q7ufEv97/yMf1HTx9vf9H1dvpZHPvGPeX5DpxcS73vh/kVPprXSb/CGfhg8zuum/L1Gxa2Y56Vg4XyIa+BfK6d3KeHd5fyOKv0/vILMLhy+GDP9S08/bz/AEfWV+ll+Feb/wAx4fNNl0XGy9RpRTUJTfuwebX29rEJPw2dRpfDuev3ems8zoNZR51C5uKMvxVRrB3qWvaxSwqd3KODgq6XqVL8pa1I/wAjq1Yzp8TTj8zZFMGSPpptk1WKe8yuex3tqNvFKtOVVnvWHUKnOUY1baUc+eTHCkmT3Xfg0Zdtw5PDrwbzqcXmWa7HdmlVqalO6p02/Js9e3vLevFSpVIyT80zX3CTyehaa3qlrhW91OMF5Jkdm2TjvSUzpv1RbxeGeotPzKuU/gYo0rf1xbRUK9KVZ+/Jd2kbw0+8pp1qsaM/7MnyRWbQZsXmFg029afN9910/Ik4KFxSrQU6c1JPs8nMpLBxTHCVretu8SkEeLkKXvD2kFLkT4kBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARIls461SMIOUnhLuOOXmbRWOZVLtk46taFKLlKWEi2dd3hYafGahUjUqRXEV5mPtb3ZqOpT/FzlQh/ZT7khptuy5vrshNbveDT9onuyFru8NPsYtU6sas1+ymWLrG9NQvZNW7lQXwZbE5OpNzqPxSfmRnHyLBp9rxYu9u6n6zfc+o7Vnhy3Ne4up+O4qym/iziikuGctra3N3Lw29OUnnHBc2jbJvr7H0lSoLHfB031GDTx+HFi0mp1c/labaUsPsdy10y/ukvo9CVVPzSMo6TsqxtIpV4Rrv3yRcVlptnarFGjGHyRF5t6iPZHKd0v6Ztb5OzFGmbL1G7jivGVD5ouHTOn1Ok/FXuPW/DBkJJL9lHV1C9t7Kk6tepGnBebIy+5Z8s9uybx7HptNXm3d5FptDSKUV4rWE2vPB6VDR7C3WKVCEf5Hg3e+NKp/kbiFT5HYsN4aTctRd1CMn5Nmm8aiY6plvxX0NZ6awuGFvCPCjgrUI+4pt60K9NVISUovs0zkbZyzNue6VpTHMc1hHhXwJwGviOF5nnls6YT8iFwx8SfL4mOzPdGA0n5BMcIzyx0whwi/IolSg+6RyYyvcO3HczFpeZxVnzDqVdPtaq/GUoyXxR0bjbWkXCfjtKbz8D2ckfI9xlyR4lptpMFvNVl6nsSyrrFu1S+Rb17sC5oQk6Nd1P7qRlX+RLS9x1Y9xzY/vlH5tk0+X64YHvNA1a1k/HZ1HBeeDzJKVObjNOLXdNGw1ahSqxcZwTT7ni6htjTLlPFrTjJ+eCTw73M++EFqf0vEd8c8sJYWOO4WU00sSXZl/at0+nTjKtb1nJ+UUi0r/RtSsptVreXhXZ4JXHrcGeOIlX8226rTTzMcObTdw6pZVFi5nKmv2cl66DvyjWlGneRVJdvE2Yz5ScXwycLHJ5zbfhzR2jh7027ajTW88s/WOpWd7BTt60ai+B3O64MA6dqt9p9SMratOME/qJ8F97d37Go1RvoqlhfWbIHU7Tkxd694W7Q/qHFm7ZO0siLtkhc+R1NOvqF7TU6FSM170zu5IqazE8SsVMtbxzBF5RJEe3bBJhsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFMs57kNvjkl8ywyOz95hhKzkN4y8nDc3FK3pSqVJJJLLLB3TviEPFb6dJVJPhyXkdODTXzTxWHBrNwxaWvNpXXru4LHTKcvXVoxnj2YvzMa7k3jfajL1Vu5UKafdPuW9e3lxe1nUuKkqjb832OvnDx3RZdJtePFxa/eVG3Dfc2oma07QqnJ1JOU25yfeTfLIfHLfB2tO0+7v6qp2tFz5w+C+dvbCWY172bb7+Bo6s+tw6eOJcWl27Uay3MQsiw0rUL+SVrbSqRfmkXroWwsONa8qSb/sMv3T9OtbOCjRowhj3I7qSXkV/Vbtkydq9oW7Q/p3FiiLX7y83TtF0+zjH1VrTjJeaXc9GMIpYjhIlJ5JSwRVr2vPeVixYMeKOKwnCKZdyplFWXhi37keYbbTxHLpazf0dOsp3Feooxiu7MJbm3HeateTaqyVDOFFPho9zqdr8ry7+g29Rukvre7JZCxjgndDpYivVZRd63O18nRSeyMImLcZeKLcWvNMAkppWY44V2MlonmJXbs3d91p9xCjdVZVKTajh+RmGyuad1QjWpSUotZ4NcfvMo9KdddWm9LqvxTgvEnkidfpeI64WrY9zt1+leWRcZZVhFK55Kl2IZcoAAGQAAA0AAwiML3EkS7GJESb7IjvxkZxH4lr1N3UrTUp2mpwVvHxYjLvle80Zc9MUx1MTMR5XSu3I/kdezvLa8oqpQqxnF9uTsLg2UyReOYkglhvB17mytriLVejGa+KOcmP8AkbK2mvh4vjrf3Rys/cOy7G+jJ28Vby/uosLWtq6lp8nKFCVSkv2jNj5OOvQpVqbhUipJ90SOm3PLhn8oXW7FgzxzHaWvLTjLw4zjuQ1nnGTL+vbNsr+LdKKoS98UY91zbGoaZOWKUp0V+2WHTblizdp8qdrNm1GmnmI7OnpWtX+mzjK3uJuCf1M8GRts70trxRp3co0aj4Sb7mKc+0447CLalmMmn70Z1O34s8cx5eNFu2fSW4nw2HpVY1IKUZJp9jky/eYZ21u290yrGFeUq9N8ZlLsjKOia1Z6nSUqFVSeMtFZ1WhyYJ7x2XnQbvi1VYiJ7vVWSopTz2ZUjiTETzAAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB5xwAAXbkEN4ZEvj2AnxLJOVjJRkNpLkccsTPHlLay2eVrms22mW8qlaoovHC97PN3Zua30qnKEZKVbHETFOs6td6pX9ZcTkln6ueCU0O3WzTzPhXN13qmnia0nu9Xc+6rvVKkqVOTp0v7r7luNc57DhLsdzR9LvNUufVW1KUl+0/cWauPFpaKRfLm1uT88unFSnNU4Ry28L4l37Y2XcXzjXvPFSguUv7Rdm1tnWun01VrRVSpJc+LyLuo0404qMYpRS4RCa3dptzXGs+1/p7ji+Z5+laPaWNGMaVGKaXdLlnpKOFgqRDeGQV72tPMrdiwUxRxWOEOIeSrugeW5TynyTlZEuxSBXnnB4G89WWlaPVrrDl2SbPbnNRj4n5Iw51O1v6dqX0ahUbpwWJR8snTpcXXfv4RW66uMGGePMrSuqzuLqpWk8ucm2ceEdmx0+4u3mnB+HOMnsR23Tccu4ln+R26je9JpZ6Lz3Uqm26jUc3iPK3gehqek17PM45lTXmedn4Hfpdfg1NOuk9nHn0mXDbptCc/A9Tat/U0/WaVSDx45KLZ5WfgyqnPw1ITT5i8m7JNMlZiJ5YwTfFkrbjhsfazVW3hNPvFM50W7sO9+naBRq+Jv9nn4Fxx7FXyV6bTD6fpcnqY4sAA8OgAAAAABjPcAxwKWnn4Ftb527S1bTqk6VNfSor2Glyy5yJLPBpz4K5azWWJiJjiWvVvqmraNeyoq5qpUpYcM4TL62x1FhUlGlqsFRiljx+86/VnQPDJarb0lGnBfjMebMYXlxSt4xq1+KT7y9xTsufNos3TE9nJzeluIbKadqVpqFH1ttVjOPvTO8sJGumj61f6bUp17avOVPhqGeGjJm1d/wBveqNDUPDSq9l8Sa0e8Y8v8b9pbq5ontPlf2OMonBx0asKtOM4TTjJZRyc4+BN1tFo5huGvezgubWjXg41YKUX5M5srHHIZ7rMx4eL0reOLQsXdOyqF14q1ovVz8oxXDMcalp93ptV07qi4POEbAPtyjzNZ0a01Ki4VqUcv9rHKJbR7pfFPFu8K3uWwUzRNqeWCJceR2tP1C7sK0attVlDwvLin3Pd3PtK60urKdupVqHfL8i2GpJ4ksFkplxaqn5UrLhz6HJ37MtbT3hb6hThTuWqdd8YLwhNSjlPJrtSnOjUVSlJxkuzRf2zN5uHgs9QljsoyfmQWu2uafyx+Fr2nf4txTKyamsckppnBb14VoKcGmmcscZIKYmJ4lbqXi8cwqBEu6J7h7AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApy8/ACoiXbkjxP+ZTUmoxcm+EPLza0RHMkmorLZZe9d3UbCMrW1l46+MNe44t7bwhaUpW1m1KtLh/BGMa1SpXrSrVZuU5c5bJvbttnJPXfwqW873GOJx4p7qrm4rXNeVavOU5y97OKTx5csqgnOSSWW+xeuytoSuakLu+TVNcxXvJ7NqMeloqmm0mbXZfy8vau1rnVasZ1oShQXOfeZW0bSLTTLeNKjTimlzLHLO5Z2tG2pqnShGKXuR2MIqmr119RP+H0DbdoxaWvMxzKn5ExJ8KCWGcKZiOEgAMgIy+SPF7gKiJe8hvjD7nV1G9oWVrOvXmoxijMRzLxe8UjmXgb+12GlabOMJfjpL2UYg062nqN9KpVz4ZSzKR6G99blreqesisU4ZjHHmsnf27bK3sste1PljdNZGg0czWe8qpMzr9Zx/bDv0KUKFKNOlHCRX5/EJjJ8oz6i+a3VaeeVqx4q468VhTUjGpTlCSTTXmeda6NbU5+smvFLyT7HpkM6tPuefBTprPENOXSY8k82hw1LK0nBwdGKysdi19Z0yVpUc6a/FcY5LwyscnW1ChC4s5wmk8LKJnZd8zYc8VvbmJR+47bjyY+ax3hcfSW6i9HjbZXijJsv2PYxT0hqY1KtQk+YrODK0exetRMTaJj7btotM4OPwkAGhKAAAAAAAAAl2BEuxiR5m4tPhqekV7WfHiia/atpDuZXdko+zTm4/0NkZ48Es9sMwlaUlPfNzbTeKU5ybXvK1vuKvNZ+5c+btxMMfaRc1Laq7C+xGonims+R7CzGeYvD96PP6hafVtr6tfW8c16VRqEctLw57nJo19R1GxhUpT8UorFT4S8ysZKzSe3lryU5jqhee1N432lVo0qs5VqPvk+yMu6Frdjq1uq1rVT96z2Zrz8MHf0XVbvSLuNa1qSwnzHPBKbfu98P8b+HnHmmO0ti/LsQ15FrbN3daa3SVGc4wuUuY+RdK59xcdPqKZq9VZdsTExzCXlrghZaJw+5Dwu5uJcdehTrQcZxUk1jDMf7x2VGrKd5Y5U3y4LsZEXDE4prDWTq0+pvhtzVwa3b8WqrxaGvNxb1qFWVKvBwkji7SWHiS8/cZh3btS11OhKdP8AF1ksrwruzFGoWFzp9xK3uoeGUX/Utej11NTXifL57uO15dFfmI7Li2fuutptaNvdy8VHt4mZW02+oXtvGtQkpRkso1+kvEi5tm7nr6RXjTqtyoS4eX9VHFuO2xaJvjSmy71OO0Y8s9mZ+6ISwdXTb6je20K9GalGSyjtZeCtWiazxK90yVvETVIC7Aw9gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFCxhlZQ+2WGJnhEpJRzIsjfW64WNN2lpJSrtc/BHPvrc8NNoStreSlXku3uRimvVnXqyq1ZuUpPOWTe27f6k9d/Cpb3vPpROPH5RWqTr1HWrPLbyRThKrVjCknKTeMIQjOc406ccuTwkZK2FtSNvBXt5DNaS4T7Im9VqqaXHwq+h0OTXZeXW2Ts6UZwvb+PxUTItKlClBQpxUUvJFVKEYQ8MeEiryKjqdTfPbqtL6NodBj0tIisd0LGcMrbwUYyslWMnMkEgdkQn7zIkAAUt88kY8xNpZyWtu7dtno9F04zU67XsxXJ7x4rXniHNn1OPBXqtL3NV1S10+1nXuKijGCy/eYu3BrN3ua5dOhOULRcccZPAvtWv9wajGFeo143hRT4/mXHbUI29GNKKXC74ODeNbG3U4r7pQ+PNbcLcR7XnQ0K2iuKk/Ej1IpQhGEUkorCwiUM8nz/V7lm1Xa8pjBpMeH2whEgEc6QAABw015PgIlYTSN2CenJWXjJHNZhydOKXqt4XEeUlS7f0/9zKcexizZ3ihu6tJf2Vz/kZTi8xR9Q02WcuKsy4tvrFKTX/KQAb0gAAAAAAAAES7Eh9jE+BxVPyc/kzA8LhU9716zk8xqtJozXuG9/B+k17rj2V5mDdHbvd0ynjipUciu7xeLZKUaM3mIej1It6ML+hiK8NallrHvMWWH/wTcC0xT/3evmq5Nvgy/wBXIqOpWMFjijgxhvKxd5pMpUFivBpqS44RXNV/HPNXituLzWXtrnt28gmm+O55W1dShqemRlGXidHFOUve0eqliXHY4bR0zw58lOi3Dls7mvZ1VWoTlTmnn2XjJlzp/vClqlvG1vJqN1HyfmjD3C+RXQq1betGrRk4STzlEhoNdfTW89nrHkmstllLMcr+pPddix9gbupanSVndTUbmK7eTRe8eUXnTamuenVDuraLRzCVjAeWuBF+QXDwdb0peGvaRb+7Nu22rWr9hKrFZi1xllxPl4Ia957x5bY7c1lz6jTUz0mtoYB1fS7rTLmVGvFrwvh+86LSfLfJnHc2iW+q2coSglUxwzDms6dU0y9nQqxksPhtdy2aDX1z16beXzzdtpvpL9VPD2Nm7lraVcxpVpuVCTSlnyXwMuafeUb22jWozUoyWUa++XzLr2PuSpptzG3rSzRk8cvsc25bdF49Snl2bLvM4rRiyT2ZiXYlPJwWdxTuaEakHmMllHPwVqYmJ4lfaXi8cwAAw9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJLnIT5wRPORwsBhGeOTwN3a5R0qwnUcvbfCWfM9DWNRo6fazrVZYSRhbceq1tW1Cdac26aeEvIktu0U578z4hX963SNPj6az3l1dSvK1/dTua78Um+PkdaKzJQXd9iW/Jdy8Ng7YqX1eN7eRfqF9Vdnks+fNTS41F02ny67M7+wdq+scdQu4v4RZkqlCNOKikkkvIoo040qcacEkkvI5F7kU7U6m2e8zZ9K0GgppMcVrHdVHsSRHsSc6RRldiSMIkARJZwSRIBjK5KW/8irujzdxX/4P0mvdf8uOVwZju15ckUrMytjf26/wbD6LaNSrTWH8DGkrDUdSqyuKjcnN5bk2erZ0JX99W1Kvl+OeY55+Z68UorEVhe4idw/UMaP+GHygI0V9dbqyT2eLo2j1bS59fWaylhJM9ph5BSdx3PLr7xfImNJpKaavTVCJAI11gAAAIAESUks9VniWJjs7O36ypa343HLbSMnUmnBfIxjpn/EaP7y/6mTaH5OPyPo+z2mdNDnxdrKwASjpAAAAAAhvyJAAjvnBPcpqSUINt4wjza0VjmRY3VrVadto0tPcsVK6yiw+mtlUr7koVZRzTiuSeo+sfhfW3DxLw0G4LHmXb0ssFZaTWvLleGTfsyfHBUcl51Gr6vqHLM9eRbfVWtCrrtNQlnwLDLRaThKL/aTR39xXUrrW7iT7KbwdDzIXWX5zzMNFrcX5WXo1SWhbvloknihcZrZfbLyXq8Z+BZvUu2nRtKer2+fpMJqCws8Fz6PdQvdMoV4NNuC8WHnk15I5rFnTnrFqRZ2kF8RzkPg53E5bK5qWlxC5pScZxeePMzXsPc0NZsYQrSSuYr2kYPfb4nobe1WvpOpwuKUny0pLywS+26+2nvET4bsWSay2K7jnJ5m3dVoatp1O6oyzlco9J5xll5xZIyVi0O6J5VMEeZJthlDSaLe3dt6hq9rjwKNWP1WvMuGL8hJZNuPJbHaLVaNRp6Z6TS0NfNVsqun3s7WvFqUXjOOGdbGezw17jMO+NuUtUs5VIwXr4JuDXmzEV3b1rS4lQrxcZxeGW/QayuopxPl813Xbr6PLzHhfPT3c7hOOn3s8eVNmTINTimnk13pynTqKcXia+qzK3TzcCv7T6LXklUpLCz5kVumg6J9SnhP7Du3V/wAOSe684/Wwispg+clRArjE8gADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkDCyAIkss4q9SFKDlJ4SRyyeOSyOo+vKzsZWtvPFeXu8kbsGGct4rDi1uqrpsU2lavUHXnqF7K0t5P1MeH8WWnjC+RU5SnJzk8uXLOxptpVv72FvRTcm1n5F0w4qaXE+YajNfW5+Y+3p7P0OprOoRUo/iY8t4My6bZ0rO2hRpxSUVg8/a2j0dK0+FKnFLjLfnk9qLyVXX6yc9/8L/s22102OJmO8pwQo4ZUCPToAAAAAES7EkS7GBHK5PC3tRdbbt3TTx4onvLtg83cNF19Jr04p5cfI83t01tP+GnNTrrwxlYx8FjRjjlR5OdeXxEabpL1ck017yT5frLTbNaZe8dYrWICB7wcz2EEgwAAAEBdiQAXbBDJ8jMeR39CoSuNRpxg4pwxLkyPSTUEvgWDtKLeptpN5iX+j6Jsk/8AxoaaR35S5JDKfYoqVIU05VJKC97Zx0Lq2rfka9Oo/wC68ktzH5buJ/DsZRCaI+aIbfdGeRWnkFMSoyBSsclRS1zlgSmsPBaHUjXqOn6PVtYyauascQwXJql9Q0+yqXVdpQgsswLunWK+t6rUqTk5U4zxSS9xC7trPSp018y1Zb9MOHQdPr6xrELeGXOo05SfYyhvO6p6JtJWNN+Gv6tJY8zg6Z7eWm6e9QvVFVJLxQfuRZW/9bnq2rzjCXsUZOHzIeONLp5tbzLT7Kcz9rcbcm5yftS5Ya8/MlkFctPM8uWZdbV7aF7p1WjUipLwt4fm8Fp9ML+ora6sLqeasKzUV7ki9e6afZrBYEMaP1JjS8Tjbzp5eOFnn/8Af5nRi/lSYd+n4tjtEr+75T7hLgnKklJdnyO5zS4JjvweefMeQAieBd/TrcktL1CNpdNu3n7MPg2ZopTjOClFpprujWlSlCSnH60eV8zMfS/XlqGmxtass16a55LVsuu/8dnXp8n9sr2bSJKEm+SstcOox5kS7EkSMimS8XDRj/qJtr1tKV9aRSlH2qi9/wAjIOeexx3FKNWm4SWU1yjfp89sN4tDg1+jrqcU0mGu+HF+Gaaa8jtabfVdPvKdzSk04PhZLg39oM9Ovnc0ofiqsm3jyLWWGsr+Rc8WSmqxPmefFk0WfjxwzptfVqWp6fTqxknPC8fzPYyjC+wdcnpmpRo1JfiZv2svsZitq0K9JVIPMZLKKnrtLODJx9PoO0bhGqwx+Yc3iRK5KI4KonCmUgAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gAKVl+ZE5eFNt8CO7EzEeXR1zUKVhY1K9V4SX+Zg/Wb+tqOoVK1SbftPw/IuzqbrXr6/0GlUzS/aw/MsZcLD7lp2jSRjr6lvt89/UO4TmyenWe0J/aSXmZP6b6ArWgr24p/jpdm/cWjsXRXqmoxlVg3Qi8v5mZ7elGlSjCKworBo3fWf8Ajq6v09tnVPrXj/SpccFUX5E4WRhFdXiI4AAGQAAAQ+xEWYFRHdEN+WBygJTXkUyw017ycdwkzFvHDCwd1Wbt751cYjUZ4zMhbh0+N5aSWPbS9lmP6kJU5ypyWJReGfPt40c4Ms2jxJH4U9kA0CFZAAAAAAgkAQT24XKGMhdjMd5Fw7Hz+EKnu8HP9TyOq3VG02tKGnadSnfajVfhUKPtOHxaR4e6d1f6JaTKrB/7xe/iKLX7Mn2Z6PRnYEbel/pTuGDr65dZc5T5Xh8uGX3aIvGnisNuGlYr12W1pundZd1wldVtTtrfT6q9mnJKMkj2LfYnUPTLKK0nWLeF0vrTk8p/IzLGEYpKKil8CcLsS8YK/cvU6i3iI7MK6Xv7dG0NaoaRvyjO8lczUKdxbw9iLb7tmZLSvRubeNehUjUpzWYyi8pnlbw0G117R69pWpxdVwapyxzFnkdNLlWtpLblRylXsFibbFOaW4nwX4vXmPK8YFREf8iJN912N7QqKZPDySpdy2N/a9HR9KnGEsXFSL8D9xo1GaMNJtLEzxHKzOqm5ZXFx+C7SbUFxV+J4vTrb89U1WFeqs21J+2n5ng0adzqmperTcrivLJmTTqFptba7rOKjUUE6izy2VTFP7rNOW/iHLX+duqXmdSNbpaVpq0q1eKs44jj9lGJ5NuTcnmUuWzua3qFbU9Rq3NWTcXLMc+46XCRG7hqpzX4jw1Zb9UgAI1pgLA6qUJWtShq9PKmqkYcfP5F/lsdTrX6XtaUHFyUKim18jfp5/nEOzRz/wAsV/K4NOrKvp1vUXnTjn+hzludObp3m3VNtfi5eDHuwXIuxjLHTeXjVV6csxCEGAaXOd+Gexs/VKmk63SqQk0qslGXyPH7sOTjyvrLsb9PlnFeLQzWeJ5bJ2NxC5t4VaclKMl3R2CxelOsxu9LVlN5qUlyXznJ9F0meMuKLQkqz1RykiQ7DGe51Q9Kc+ROMdyVFIkMPL1/Taeo2FS3mk/EjCWs2VSw1Crbyg4xjLEW13M/tLOCx+pOiK7s3eU45nSXZeZL7ZrJw36ZntKs79tsZ8fqVjvDFnPZcebMpdN9fV3a/RK8sTp+zHL5aMWtNNxkuVwzuaJey07UqV4nxF+RPa7TRqMXMKntetto88RLPyxLkqj2Ohot5C8sKdanNNyim8HfjjBTLV6Z4fTsOSMlItH2kAc5+BhtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADzjgBsClcHibv1SOl6XUrt8pYS8z2qjSg3kxL1K1eV1fK1p1M00sSS9526DT+tliPpD7xrI02CfzK07urK4ualebb8cskUYTrVYU4R8Um0sIoXC57F49NtHV5eK9qx8VOHCXxLZqMtdPh5h890mG2r1HE/a+tlaTDS9NjTSWZe0/5lxfA44RUIqKWEkcnkUrLknJabS+o6XBGDHFI+gAGt0gD7ERyBIbwCHjAE54yUrCWSKlSEINyajFd22Wbuje1lpzlRoy9dU7Zg84NlMVsk8Q5dTqseCObSu+tWp0o+Kc4wXvbOp+F7BtxjdUpNd0pdjEdHXtY1q6aq15epT+rjsjuws6FOTlHxKTeW/F3IvcdxxaGem3lzafV21M80jsytTvLWo8U7inL5SOwuV3MV2tSpbz8dGbi18T17HcV7SmnXk6kfciMx/qDDa3EpGOftfkllYfJau69HyvpVvD2l9ZLzPU0vW7W74c1B/FnqS8FWnw1JM7NRTDrsXZnyxW8rhrkFwbl0ipQqO4oxzB8vC7Fvsour0l9PfpkiQgIk42QBIAAQSAJivEyO5xXtX6PYV7jxKPqqbnl/BZPePnqh6rHM8LE1yynvHqfabYXMdPlG6bXZ9v/AOzZW3p+roU6a4UYKP8ARGCfR6pLXN1X+8I0n4aqlRU38H2yZ5R9I2zFOPBWJbc8dPFIMYWEQ8pYDeOEhzEkWhTOXgUpYba8l5mMenVrrS6p7mvr2nUhY18OgpLjv5GT/PkNLyil/I8Wp1TEvVb9MTH5VY9nghZSwhHOeSZdmenlw3FaFClKtVkowistswTvzWa2r6zUhOr4qFKWKeO2DIPVbXIWWm/QadTM66cXh8oxVolhPUdUoWfLc33Kvu+qnLkjBVzZrcz0wvfpToEalWWpXNNp03+LbODqhr/0q5Wn2s/xccxqJe8u3Xrmntra8aFOSjXjTxHHmYbuKsri4ncSz4pvMsnJrckabDGKvn7eMk9FemFCXGF2DxlZDy+B8GV7nlzciWAO4AHU1m2V3plejJZ/FyeP5HbKa2fo9X3uDWP5HvHPFoluwW6ckSsHo/cThbXVjJ/9vJ4MgYwYx6eSlbb3r2OWs+KWMGT2sNm7Ux/Ln8t+sr/Lq/KAAcziMY5Cz5juFywPe2Jq1TStep+GTUa7UJGeqT8UIyi0013NaaVR0K0KyfMH4kZ42Lf/AIQ29b13LMmuS17DqZ46Jdemt24e/LOSUQ+e3kTHOe5anUkAGRRj2vccd1ShWoyhNZi1yjkeck4MxPEvF6xasxLCe+NJemao5RXsVXn5Fv8AmkuxmffOj09Q0mq4081or2WYbqQdGtKjLiUXiXzLftmp9bH0y+a73oZ02fqjxPdf3S/WcOVjWm3Jv2eTJcO2TX3S7udjqNO5pZTi/Iznod3G7sKNVTUm4JvBD7tpfSydUeJWT9O6/wBXH0W8vRAyhlEOtIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABD95JDfHIYl4+59Qjp+lVa/mkYQu67ubqpXln2pNl+dVdTalGxpyzGa9pGPY48PPkWrZ9P0U6/y+efqLWzly9EfTkt6M7ivClBeJykuDOG1NMpadpdOnSj4fFFN/Mxx020p3epxvHHNKHDXxMu04+GCS8jh3jU9duiPpK/pvQ9FZy2SVrsUoqINboAAGQAAUvlnHWqQo05TnJKMVlt+RyTkoptvCRjLqXuqSctNsamH2nJPuvcbsOKck8Q4dbq66bH1S4N8bwrXF09O0qeYpuM5xefF8EWgtHuq1N15t5ay0+/vPR2zYxVH6VUSbl296PcfPGMIgty/UP7TJOLF9IfDoLa2PUy/bz9DtI2tmm0vHNe0d9heeFwQii6zWX1WSb2+0/gwVw06aiJyCMHG3quzyuGexpev3No4xquVSC4weL2+JJ1afV5MM81ljhfdHWbK9ouE5KKl5SPB17TaSi7m0alBd0uTw1j3nNSvLilBwhVlGLWMEll3Kmop05oY4lwY93DJxglvxPL7kEN257PYGkR2GTHLCSMk+RAkFgtXqhrK0nQ6VHu76qrdrPOJcf9S6lhe0+y5ZjrTrOW+Os34Jqub0+zhGvFvs5R5O7btP6+aKujT1iZ5lmjo1tmG1NjW2mwSXibq9v7XJesexx04KnRhTXChFRX8jkj2PpOOsUrEQ03t1WmUvgLkiXYR7Gx5SAAIl2OrqVzCysat1U+rTjlnal2Mf9WddlZ2UbOjLxOtlTS8ji1mojDjmZebW6Y5Y43XqUtT1itcN5puXsfAvTpRo0aUKuo3lPlc05PyRYWi2Ur/UqFmuVUljJlXdF5S29tRWMWvXOniOPMqujjrtbPf6cuPvM2lZHUfXHqmreoh9Sg/Dx2ZbHlwQ5ynN1J/Xm8thccETqs/rZJs0Xt1TyAA5nkAAAifFOXi59lkjzETwzE8SxdZf7l1TcYtRUqX9eTKTeUnnOTFe6/Ba9UKUm/D4qcfvMpQ/JQee8Uzs1MfxrKT19eMdZSADjRfHcAACSyse8yX0b1FznWspviC4MasuDYF/9B1+mk2vXSUWSO15vTzw24bcWZ5WOwSwUwl7KfcqTyz6FWeqOUgkAHsAABx1oeODj70Yc6g6XHTtU8cIcVm5NmZ32LT6g6WrzSqlWNPxVYL2SQ27Uelmjnwgt80fr4JmPMMPp8e5mQulmr+GMrKvNucpeyY8cZRm4TWJR4O/t29enavSueXh4LNrsMajD2Ufa9ROk1Mcs+LDQwdfTayuLKnWX7UUzsZwUq0cTx+H1HHfrrFo+1QAMNgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHOQJKfF7WMFRThZyBPiOvqFeNC1nUk8JI5nh89i1uouoRttBrU4zxUn9Xk26fHOTJFfy49bn9HDa3+GLdw3dS91WtUlLKjN4Og+ZRSXLeCPE3mb5b7s9balktQ1yjQfMXyy69sGDn8PmHfVamI/LKGwNMWn6VFY/KYkXNjHY4rKiqNvCCX1YpHOUrPknJkm0vqGiwRhwxRCRIBqdYAGBGecYGeSGyXgMT4W7vnWIaXpNSUniVROMfmYMrVatxWlUqSlOpN5bfmZF6g6hTude/B1Z5p0mpNN8Hlw0ywhdSr0YxlDK8OFjBty7jj2/DNrR5VXXae+uzcRPaJNHhOnptKE14ZY7Hd8if5YRDSPlWtzevntkj7WXTYvSxxT8Iz7hwTj3B4XL7I4+mW4UWyiM4SnKEZrxx7oxF1x3zdaDKjQ0m+l6yo2moceEw7S39u2F2rlavV75cc/8A7gkcO32yV6uUlg23Jmr1Q3CaafYpfLwY56N9QobotJ2l4vV3NLhSb+uzI+MN5OLNitit0y4suK2O3TJx5jgfNfIjBqaj5koAQKilkoHryI8uCcPyC4Wex1dWuHb6VdV4SUXClJxk32eDNa9UxD1WOZ4V6pP1OlXdV4XgoTly/wC6zxPRZtPwlbXG5p0n45TlR8b88NmtV11G3TUu7ujW1WtWtXOUVDL7ZNlfRG3TpN3tNbet5QheU5SqTgnz37lu2bRxhyc2lJ5tHfT4OqftniXPCJj2KeVyVR7FrhFDWUT2QBkU+J+4lPhZIffvknKffuYmeBw3txC2t516n1YLLMBbx1Geo67cVFJyo+L2F7jKfVDV1p2jOj+1cJxi8mGLahUuq8LeL/GTeEVXes85L+jVy57cz0wv3pLpUKlSrfXEPCqXMJM8fqPqz1PWJUVlQt5NLnuXtWlDb+xVDKhXdL5NsxJVqTr1ZVqr9qbyzh1l4w4IxV8vGSemsVhT8SMZ7hsJYIKXOAAAAAA8wSu6AxJ1Mpze/wC2qJNcRX8kzLFL83o/Zx+4xT1bqSpbstZx7+z95lW2y7O3k3lulH7ju1Px1S+v+CisAHD9ojjuEogADsaXP1Op21bOHCaZ1yG8LxLuuxsxW6bxLMTxLY3Rbn6XptKvnPiS5O9HsW506q+u2payby/DyXHFeZ9J0lurDWUlWeYhIAOl6AAAfY4LmmqlCcZc5Rzspl2wZieJ5eMlYtWYlgndthUsNZq+PtUk5R+R5T8n7nkyP1U0rx0VfRXFNc8GN/2S6bfm9fC+W7rpv22pll7ptqcr3SPDN8034UXa+xiHppqErfWI2XixCpyZfT4TRWNxw+lmmPyvex6n19PE/hUuwAOFNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUtc8FRT+0YYlTPhMxT1Vu/WX9GjCeUlyjKdzJQoyk35GCty3MrjWbnLb8M2kTGz4evLzP0rH6l1Pp4emPt5reF8PMv/pRp8Z+K9kvajLCLAaz4Y47szZsnT4WWj0lFY8UU2Su8Zpx4+mPtX/09pvWz9U/S4o9gQiSpcPo8HzABlkDAfYCJfI4Lyr6qhOp/ZTZzdmdHWudNrpd/Vs9Ujm0NOeZjHMsLbjv/pG6Liu4qXrPZz7n8D2dOpKjZQpqWfMtDVW46jNp4aZc+hV3XsYZl4pLuzg/VOnv6ETXwrG1Z4nUWi35ehnzGfgQQ28nzGZW1X/MJLs+UUhfMzFu7MTw1p9IXSriz1+N1Om40q024+4xank3Q3btzT9y6bO0vKUHNrEKjXMTD1z0E8d64w1Wai3nhdkTml1mPo4sntFuFMdOmy1eg1O4luaFe3pyqQpSzNL3G0jecSax70Wj082JY7QtXGnNVazx7eOS7X95G63NGS/ZGazNGXJMwPOQMvGMA43GAgkwBKI8+/B1r53Xs/Ro5XnjueqxzLMRzPDs1ZwpUpVKsvDFLLZgbrR1EUKk9J0S78afE6kH/VM97r3ue+sNvfRLWtK2unNJtPlp9zXOpOdSUqlRuVR8tvzZM6HSRMddk1t+h6467eHc0bS9R1rUY2enW8q9xUlmUYrnnzNtvRp6TXmzr+evX8pQr1qXhdOS7Jot30Otk0qlq923VNTcm6cVJdsGz+OC3aPTduuXnctZNrenXwhvJMewwvcSSfhDAfYB9jIozz2wJPCbKkuOe55m57l2miXVeMvDKFNtNGjNeKUmzE9u7E3VDVal/rM7Kb9m3fsnW6c6bK+1ynXUPFGjLM/kW9f3VS8ual1Wk3Ob+szJ2wrJaRtuvqc8r1kPEn7ymYp/caick/Tjr/O/Lx+rGqq4vKVlQlhUniSRYp29ZuXe6rcXLeVKWVydQj9bm9XLy1ZLc25EPiPIHG8AAAAAAF3AXcDEnWH9KLX/AO37zK9r+Z2/2UfuRh3rHUn/AKc2tPxPw+xwZitOLK3+yj9x36qOMVExuEcYKOQAHB9oj7AAIYCJLKZIfuEDMXSa48ekKlniK/oXyuEYx6M3Dn9Io5z4UZOXY+h7XfqwRCRxe2AAEm2AAAFPYqfYo5DDyN3WP0/SKtuu8kYOrQdK5qUX+xLwmwteHiptfAwjvKxdhrU1KOPWNyRP7Lm4t0Spn6n03MepDoaVcuyv6dynhppZM66TcfSLGlU85QTNf8eJ5fkzMXTi9d5o6zPPg9nubd6w9utz/pjU8X9P8rsAQK2vgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAygBD+CJIfL7mJHhbzuna6HcVYvDSMJVJurWnUfebyZT6n3kaenStm8OojFEOF8S1bLi6adb55+pc/Xl6Pw9Db1sr3WaNv72Z102l6qyp0v7MUjEnTe0dXXKddLMY8NmYqa8KSI7ec3Xk6fwmP0zp/Txdf5VIkJp9gQ61wAAARIkS7AUyafY6WsRc9PrRiuXBo73l2KKkPHHDXDM0nieWrNWbUmGu2swcNSqwkuUzm29dVaF34IcqbSaZ6nUeyla7lrzUGqcuz8jo7UUXfTckspcEju01tt82mOeyhaetse4TX/K6Gn28yPMqTKT4pl46p4fQK+BkrnuDp6pffQ4wjCKlUqZUUea16p4h7iJmeHcefLjBPK7POTx7fVrz6TCleWqoxl55PXbXGOUer06WZjgb594x5sd32Hlya+Hk8shcjv8AOwDy47glGYjkQ1xjzLT6k71sdpaROfrYSvHxGn5/M9TemuU9vaFWvpOMppNRTfwNRd0a3e69q9a7vK86ic24pvKSySWj0c3nqt4SWh0U5rcz4U7j13UNd1Cre3txUqeKTai32RcvSrpxrW+NUoVKFvUWnxqJzrL4eRb+ydv3O59yW+mWqlKbknJJfs55PoB062rYbS25b2FjTjH2E5NLHOOS16PTdfH4hK63VRpqenR3dm6BZ7a0K30uypxp04RWUl5+Z7ZSuZFRO1rFY4hWZmbTzIAD0wAACM/5mPer+o1Laxo29KbSqtxlj3GQW+ce4wd1NvZ3G5Li0lJuFJ8ckNvOf0sP+2rNbpqt3TrZ3V9RtIr8pLCMl7yunouz7fTU8SlDwstLpzYyvNdpVFyqMk2/cdnqfqH0vV/oueKDwV3BPo4Jv8Alz1/jSZWjDPhRI+QIWZ5lzgAMAAAAAAEryZAfCeXhJZyIZiOWGOqqhddQLZRfbwLj3pmY7VNWdBS7qnH7jDG7KsLjf8ASlTbl4WZppfm9H7Nfcd+r+OsJjcvgpCoAHB9oefIADDAQ1x3JHfJmPIyD0S/P7791feZZj2MP9GqkoancpdmuTMES+7NPOFIYfakAEy2gAAPsUrkqfKKVlMwJ8mYx6r2ebmndJcQWDJqz7i0epVq6uhVpqOZLsdugyenniUPvWH1dNMMRc9/LBf/AEpv40ZSsm+ZvxGP1nDhJco97YFdW+4acpSwsYyWfcaepgUXacno6qGb4vKDWWUUpJ04v4HJlFNl9QpPMcgGUDD0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEY5ySABTx3Kiio8RY45ebTxHLF3Vyv4r23hF9k8ljZRcnUO49drLinnwPDLbeE1x3Zddujo08Plm739TV2ZI6Q0YStK9bCyp8GRMcZLT6cWqt9Kz/bxIuztx5FV11+rPZ9A2fH6elqRZJCSxwSciVAAAAAAPsABY/U/RJahp/r6EM1KftSfwMT6XcytbuMk8JvEjYq6pQrU5UprMZLDMNdQ9tT0y9ld0IP1NSXZLsd+K0ZsU4bKru2jtjyxnpD0YSjUgpxeU/Mq4LY0TWPUQVCv9RcJ+4uGhcUK8VOlNPPPJ813XZc+nyzNa8wltFuOPLSIme7lTyzzNcp1PXW1eNPxRpy5fuPT4k8Jp/JiSTj4ZJNeaZCzjyYZ5tCTxZqzPNZePqF7b6hGFO28MqrXGfJvt/mepZwnC1pwqfXiiY0aEJeOnSgpeTSK+e7PF8kT2bb358DGPiEPma2tD96ZOOMvt5kVJRhFyafh82kclpp+p6o0rOivUP60nw0dODR5c0/xg5j7RSj62vGhTy6kuyLg0zbtSUJVbzMFFZxnyPX25tq20qCqSlKpVfLlLyLa6671p7M2XdXVFxldteGFPPdMtGk2WuKvXlesWOclohrV6SW8leb2haaZJVLOhTdOdNcRbXngw1ObzKbXLecI5dRvKuo6jXvK/ida5quSS55fkZy6DdELvXrijrW4YSo2q9qMfJryOiMc5LcRC29ePSYo5et6G+z6tfUJbtrUWqcVKmlJG2K7YwedoOjWGiWELHTbanb0YJcQWE/id/HvZN6fF6deFY1Wec9+pVFJfEkiJJ0cOaAABkDWQH24MDo6xX+i6bcV1w4Qbya+azdTvdUr3c226j5M19QdQVjoNaMsJ1YOKyYGefA228yZU98ydV4xuXUT4hkbpZRdhY6hqNRez4E45LK165+m6zcXT/blkyDaeGx6eqXixOtRf9TGEXle13IzV26MFcbVftWISvPkDKzhAiWkAAAAAAAAKarxQqSXOIMqOO6nGlZVpy7KnL7j1SObNuGOq8Qwpbzjd7/eYdpNNfJmboNergksYikYT2FB3e+ZyS5cpNYXxM24SSS8kdut7REJLc5/jEAAOBET5AAADz5BB8MQL56NtLVblP3YMwxMSdFoKWo3kmvqr/qZbj2L5steMKQw+xIAJptAAAAABnmbgtfpWm1aXvR6ZxXS8VCax5Hqlum0S06ikXxzEte7mPgva8f7M2jl0q4+jajTqcd0nk5tfo/R9WuE/2ptnQhxVg138SL1Xi+GHye/OLUW/22EsJeKzoy98EznafuPL25cRr6ZQaaeIJf5Hq/8AsUbJHFph9W014tjiYR8SU8kL6xUeHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcNzLw02/gcz7HU1SfgtZz9yPVI5tENOonpxzLBm5Kkquu3WecVGefJN4S75SO1q8vHq91Nec2UWFNVbunB85fYu2OOjTf8AT5Zmn1NX/wBs2bSp+r0e34w/Vps9juefoMPBptCOMYguD0vLgpeaebzL6do69OGII8EkRz5iXY1utIIj2JAAAAAAKZd2dTUrC3v7aVG4gpxaxyux3JfBENcZEWms8w8ZMcXr0zDDu79kXFhOVxp6lVorLl70WbGpXovCnOGPi0bI1KUKkWpxTT96La17ZumanmTh6pvzgsEhTU0vHTkjlWtZstq268M8MM0dQuqdSMvXTeHn6xdunX1K9oKcZJSX1kzn1Xp1dU5v6DJzj3XiZ5kdjbkpSfq6OF71PBwbptGl1uPivES5dJfW6W/8qzL1nzjH+QeF9Z4KLLbG6KfE6Kf/ANx71psypcpfT6k4Y59l/wDt/wDvJUL/AKXmLcRZYMOsy380eFOSjju35JcnsaVole+h42nGD+4ufRtvWenRajmqv76yezCEYJKEYxXuSOrB+nseOf5d3bSbW7y8bT9u2du1KS9Y/NSPXo0qVCPgpU4wXuSK19ZFWETeDS48McVhs7KVk1g9MPSdY1TcFhS06NWpB0sOCT8LZtCdW7sbO6mp3NrSrSXZzing95sXqV6W/T5vRv1tWug/Qe8d7R1vdlD1fhWadLumvibUWdtQs7anbW8I06cFhRisI5IwjGKjFeFLsl2QfLz5HnDgrijiHrPqb57c2lV4ec5Hh+JK7A6HOLsAAAAAABmJ7dxjnrZVcNOtYp958mL7GnGrf0KLWVKWEXr1dvHW1FWucxhLsWrtiPj3FYQx4s1Umii7jk9TWQ4cs83Xh1EqystuabaUm14l7Szgx/2yXn1TuI1L6lbxln1Xlksx9zk3Gf8AlmHnL7jyC7AEe1AAAAAACSAB5W7LlWuh1qmeWmuWeqWj1aruhtGcoNeLxpG7TxzkiHXoq9WeIWX0epeLd1W4wsPxZ58zMcvrMxX0UtnKlK5SWPE+TKjeXlm/Wzzfh07nMep0oABxIsAJ8gIHOXwCHnDwIGReilKcbu8nJcSivvMrRMedILfwWlSs19ZGREsI+g7TXpwQkcXtAASrYAAAAAIzl4Kay/FtfArSwUVOzQjy839ssL9QqXqdcSxxJNlurun7mXd1Xh4dbotLjwd/5lof5cF10F+vBD5ZulPT1MwzF09ruto8XlPDx3LqWc5LD6Tzb0iab/7Qvx/VRUtXHGSX0Pa79WCJVIERfOCTmhJAAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAPN3HLw6ZVeceyel5njbw/wCCV8e424fkq5dZ8Fv9MI6i1K+rSj5yZ2dvJPV6CksnTuH+OqfNnp7PhGruC3jJcNl2zdsE/wCny3T/AMtVH+2bNNio28Eu2Edt+84LaPhpJe5HMuUUfJ3l9WwRxSEoNZAPMNwlghS55JAAAPsABTyuxOM9zHIj9ocv4Er3DHPJliEPhYyEuETwQviYB8PCGCeGQx2O4skkDI5hniRc8hJZ7jDxknHHJjswhP2uxUQs5xjgkQyESJYSPQo5Twu5VnywSQ1yBIAAAAAAABEuxJTVkowbfZHm/tkYL6lzb3ZcRXPJx9P6Tqa/Tk45UHn5FHUGoqu7bvwtNLhHc6bRm72tOHaHdsoWXi2pmXBPvdHflaVTdFzF9k+Dwz0d0VPXbguZ4S58jzjh1durJMvF55kABzPAAAAAAAZxyR25Akxl1uvJKz+gRlhSw3z2MmpJRbbx5mFesNzG43XQprMlwvDg7dFXnJz+EttVOcvV+F59FrWVDaWZd/G8ZRe/c8PYtrK029TpyWPFiWD3DTqbc5Jly66/VnmQAGhxz4ACfICCJvEXglFVKHrasaS83g9Ujm0QfbNXS639VtuhVfeccsu9djwtkUPo+2rWm1hqPJ7kex9I0NOjBWEnSOKwkAHY9AAAAAAUz7FREuwjyxbwxd1Wpx+m06jXMYlhvmOTI/VWh4qardscGOUl4UXDae+B8y36ONUyT0mf/wAPqfvmQ0+DGnSj6sueMmS/2UV3ca9OaYXPY79em5FgkESOFNpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgDx93/8Fr/unsHjbxfh0Ou/7ptw/JVy6z4L/wCmDrj8tU+bPV2T+kVseVcflanzZ6uyGv8ASO2z2zyXbUfBP+ny7SR/8qv+2b6P1TkWf5FFL6pyLsUa3l9WxeyEoEJ479ycnmG0BDaJysZMgGMnHWr0qS9upGPzeDxa8VjvIq5HHvZ42p7l0vT4t1q8ZY8otMtq+6laUsxt4VcrzaOPLuGDH5tDxN6x9r98ST5aIdSC+tNJfFmItQ6i6jOTdpGCXllHjXm89cuVic4r5Mj8m+4q+Guc9YZ0de3XetBf/cin6Xa4/OKX+JGvlXWdRqpqVxLD9zOm7i5z+c1f8Ry2/UdYntV5nUxH02Mq6hZUlmVxTx+8U0NSsa2fBcU+P7yNc5VbiXe4q/4mI1a8U0riqv8A7jX/AP0ff2vP7mPw2Rd3bY/OKX+JFSuKEuFWh/VGt0a9zF5VzWz++zt0dY1CjhQuJtL3s2V/UVZ81ev3MfhsRGpTf1Zxf8yrKfbBga03jrNq805p/N5PX07qLqsZP6VGDXwR1Y99xW8vUZ6yzHEkx/YdS9KaUbmNVSfmkXJpm6NKv0vVV4xz2U2kSGLccGTxaGyMlZ8S9wHHSr0qqzTqRl8nk5DtreLRzEvYAMozyAIyiW0jIAJpgAARjnIEnBf5+h1cf2WczfBwX7zZVfkas3slifDX3dOVr9wst54Pc6bS9VT1Ga7xhlHh7nTWvXHh7ZPa6ec22pv/AMt/cUP/AM1nB/dK3tVqet1OvVxht9jqs5r388q/M4WR2X3S1z5AAa2AAAGAAHdYAQ7rkcnKKmFQqSfZRZr3qtzLV925jmXhreFe/h4M37xvfoGgVa6ePIw300tPwlvKUUl4XKU+fcSejr00tZYNtx9GG2SWdLGCp2NCKWPxayjmEV4Yxh/ZWAR155nlB5rdV5kAB5awAADuaFSlW1q0pxWfFUSZ1GXT0xsPp2u+JL8k1I69DTrzRD3jjmzNFjSjb2sKSXEVwdhckRSSxkmK5Z9GxV6axVJJABtAAAAAAIl2JIl2MwxPhj/qq39BwvMxlykl8DJvVX8yWPeYyTzDkt20fC+a/qD/AOyyF0p7SMlrsjGnSjlSMlJrBA7p88rb+n//AKqpAhPyJI2E8AAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4+7v+C1/kewefr8fFp1WL84mzD8kObWfBb/AEwLcc3FRPykehtOp6jXreaWcM6mq/8AEK67e0cmhVFT1ajKXZMu2X+WCf8AT5bh/jqo/wBs82kvHQi33aRzYwjp6TLxWlJ5zmOcndkUe8fyfVMFuccC5eSI85ZKfs5Ek/I8N6mUoxi3JpJebPL1PX9N0+lKpUuITx3UXlnPrFrVu7SVGlPwuXDZZlTp7TnNzlWm8vOHJkfqc2es9OOHiZn6h0de6kxk5U9LTi15zRY+vbz1S5j4Luc+efxeS+rvpqpL/d5Ri/izwtV6favY0nX8cKkF+zHllf1NddbmZ8NFvU8ysenqcLmvKE61RSSy1OXByutQePx9L/Ej1aGiaRcTdC+tq9CtL2fHLhHHqHS2hCMrqhX+k03zinLJE2wZL+XjorLzlcWz7XFJ/KSOTPieYtNfA8avta0oS4VeFSL4U/edStY7lpSxYXNKMfJTfc55xxHaWfSpP2uXDTILWndbh0/27yUa0Y9/BHlr+RNtvG3nNRq2FzDL+tjg8zjn6YnBP9q6AdGz1fTrqKcbmlBv9mUsM7sJRn9SUZr+68ni1Jjy1XxXp7oSAGeXgAA5Bkqc4tONSpHHuZD4Cz5nut7V8SzzL2tM3TrGm4+j1/FFeUuS8ND6kJOMdSTbf9lGNVjOOxD548juw7lmxTHdsrltVsNpWuafqNFVKNaKz5N8npRakuGmvga221xXt60alGrKLXlngvTQOod5bVIU9QanSSwsLksGl32t+13RTPE+WYE/ZHblnkaLr1hqlFTpVopv9lvDPYi+Cex5qZI5rLfExJheLPmSUxXOSo3Mg8wDIY4OvqC/3Orj3HYKaqUoOL7M15I5pMEteN0tLXriMV2Z7PT3831P7N/cefv6MaW7buEE0s8I5dlSnF3cFL68eUUK/wDHPaEfPa0vFvvzyr+8cLOxqMHDUKsJd0+Trsjsvua58gANbAAAAAACXbgd1gJ9/cuRBEc9lidY76FPQXZqeKknnHwPB6J6dm6lqPPGY5PM606h9J3FSpUpZgoqLWfMv3pJYfQttNyWZTlnOPeS0x6en/2sto9HRx/ld+echvkJBdue5Eq0AAAAAEnhNmTujenyoureYfhqx4MaUKbrV4UF3qPCM87IsHp+37ehJYklzwT2x4OvL1/h0aevM8vdXfLJXdhkr/Mu8O0ABkAAAADx5gHwih8ora4wUPhBi3hjfqtWkpRprtjJj3yL56r1vDqFKnjvEsXPs/yLhtUcYHzHfZ51TIfSem3F1fJNoyTnPBj7pIn+DZyxx4zISK5uFurNMrtslOnTRCF9YqKV9YqfY4kyApiVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsABCbZ1dUh6y1nH3o7Zw3CbptP3Hqk8WiWnUR1Y5hgLWV4dYuo47VGjhtJqncwm0+Gd3c9KVLXbry8VRnmvPHPOeC64p69N/0+WZ49PV8f5Z72/JS0u3a7Omj0UmeJs+r63SbfnOILJ7jeFkpmaOnJMPp2it1YYlK+AIj2JNbrMIJ5AMAUzSa5WV8SoiTwYmOY7jwdx7a0/WKEoVaajUx7MlxhmK71a1s3UnS8TlRz9Z8xaz2M4vGcnkbo0W21nTp0K0FKSTcGveRGt0EXr107S13pE948rBnb6TvC2lWtIepvvDmTfGSxdVsLnTL2dpcxfij+15M70/p21dfdJy8MoSzLHmi/NZs7Xdm2o6jbxSrxi2158FevgrmrMccWhzTXrj/LFb+KTXxRxXNtb3EHCpSg0+Pq4OepTnSnKnUi4yi8YZT3Ieeqk8Ndb3r4WzqOytHuZ+vhCpGsuViWFk816Zu7SubK8pyoLvF8vH/wC4L44D54ayeoyzHubaamY7W7rHtN8VLSaoapYXDn2lU8OIr4l02GsabfQUqV1SUm8eFy5Oe9sbS9pulcUYuDWHhYLP1XYVKM/XaJVlb1c5zKT7m2PTyeezor6Ofz2XxhtZXYPsY0huLc23bqNHVqVS7oQeHKEHjBeOg7m0vVot060aM/7E3ya76e0d48NWTSWrHNfD2n2yMeYWWs+Xkxk08OOY4GsvIT+BCSfwJMAuAuOwA5HNZXVzZVlXtqso1F254Mh7S6gzc42+qNyk+PF5GNiHysRyvid2l3DLgntPZ7plmrZOzvbe7pKpb1Yzi1nhnZWfgYA21ua/0StHwVHKiu8XyZf2xuex1u1jVpVIwm+HBvnJcNFutNRHE+Xbjyxd7zbxyTF5RT35Ko9iXiWyEkT7Ep5DMW7wywP1JjKG67mTXB0dq1FT1SFPxNetePmy5+r9l9Hvo3XheKrxks7RWo6zaybxifcoGuicep7o/J2u5tyUXR164g8Zzyecz1N1Nz1+4qtYUsM8tkfn98tc+QAGpgC7gAAAAKLmtGja1Jz7KL+4rLX6naj+D9sVpQf41vCRtw16rxDp0uPryxEML6vUq6puOXhbniv7OOeMmwujW9O20u3p04qK9Wm/ngwf0ysvwluun41mOHJme0lGMYL9lYO3XW4iKpbdr9Na4/wMBIEagAAAEM5XAXHIl2ePcZiB7+w9Nep65ScYtqjJSZnqnFRgljyLC6SaNG301alOOJ1l2L/L3s2m9LF1flIYa9NRrLQAJltAAZAAAA1kAAUVPqtlfZFFXik2/cI8vN/bLEXVWfi1yjjuqeP8y0pLK47nvb8reu1x8/V4PAWfWL4vBd9DTowQ+Vblk9TVSyl0mpuOjScly5l9Jcls7Boeo0mC9/KLneMYKfq56skvo2116cEQR7EhA54SIlgAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKJrKaKyl45HPDzaOezDvUu2jQ1iMkseN5+Zasln5l/9W7du6t6qXEVyWFnkuu2Wi+nh8t3mk49ZZlrphc+v0mSck3B4Lwz35MbdI7pQpVqDf1p5RkmOH8ir7hTpz2XzZcvXpapiSREk4UwAAyBEllcEgxwKVjOMDsVATHIx91X0CN3ZK+t6LdaLzOS9xbHTDWla6lOzuZ5oz9mMfczL2q0XXsK9Fd5waMA31rPRdyqnJ+1SqeJ/wBSs7ji9DPGSv258sdNotD3uqOjKxv1fwX4us8JIs7sjL+46Mdf2fG8WM04ORh+OUvaXOSF3PD02i8fbRmrxPKRnI82F25IppAgAOO6oUbmi6NenGUH3TRZW4Ng0atV3OizVtcd8v3l8jzybcea1XTh1V6f6YqsN1bh29eep1uhUuLam3HxQjxgyDoWvadrFBVLWtBTaz4M8nb1TT7TUreVC6pqVOXfBjfX9l6lol29S29cOMYrPq1yzqj080d+0u6Jw6iOJ7SyhJfyZJjzae/4yqrT9bpyo1s4c58JGQLatSuKaq0ZxnTf7SfBzZcNsflxZ9LfFPfwrAXfDHPbsjS5T4Pv7xz7wAHGODn0y9uNPu43FpUcJLuvecGceQ7Rye6ZLUnmrMTMSzHsXeNDVIK1upqnXiu8njJe0JJrKeUzWmhVq0asa1CbhOLymZT6e7yjdxjp+oVEq0e05P63wLZtm7df8Mnl2Ys3PaWROEG0ilNSjnILLE8+HQsPrFZzudLoThFtU5eJmJaNV0qsK0XlweeDYPdFsrnRLqm4+J+reDXyrSlRqypy4afKKdvmHoy+o49RHE8vW19qtZWt34cSqL2n9x47OWrXqVKNOlOblCn9Ve44iAy26rcueQAGtgARLQEAAMweRiHrZqkpanTsYTfgcOcdsoy3cVY0bapUlJRxF4bNctx3tXUtfrOpJySquEePLJIaCnM9UpvZsPN5vP0yJ0S03NpU1FrEoy8KyvIyZ5nh7I02OmaDRpwXhVSKlg9w59VfqyTLi3HLOTNMgAOdwAHcNrIBZz8D0tsabU1PWKNOEXOMZJyXuR5ry+F3fC+JlzpVoH0KyWo1YeGrVjhpok9s0s58sfhtxU6rL10y1pWdpChRj4YRXCO0F2Bf8VIpXphIAANgAAAAAABDWQJOG8ko28+f2Wcy7Hj7quvouk1ameyPeOvVaIc+pydGKZYV1mrKrqty5eVRpHUgm6kF5+JHJcTdW5q1W8uUmzsaHbK81SlSfvReYnowxy+UzWcuptx+Wb9BoqjptulHGYJ/5HfOOxj4LWjD3QSOco2SebTL6vp6RXHEQhc4JAPDeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh58iVnzAAFL4fKKimQFndTLT1uj1K8VmVNcGI4+1HnyM8bmtHd6VWpL9pGDb2HqburS7eCWCz7Ll5rNXz/9S4OnJ1/l73Tu7dHXqVF8KRmak8wTMBaRcfQ9So3Ee6eMGddKq+u0+jU/tQTOPesXReLflJ/pjUddJp+HdXYERZJCLaAAAAAAAApfLwYd6u6TK21SWpL6tbjsZjkWt1I0lanoknx+JTnj3kXumD1ME/mGvLXqqt/pbqMdQ0eppNRpqnDlP4lh7usfwfr9xbKOKcX7Jy7J1Oema7T8HsqpU8EvgXh1a06Na1oX1rT8TbzKUSu3j9xpu/mrnn+dP9MasCPCBX3KAAMgXxD+AAYQTx2X9QSInhmJmJWnu3ZFhrNKVS3jGhc8vxliaTrmu7PvfomoU6k7SMsY8mZmXHnk87XtGstZtZUbqipPHD93uOzDqO3TfvCT02t7dGXvBoGt2Wt2yq2tSLeOYp9j0eW+eyMJappmtbI1H1tlUq/RHLPiiuEs9mZH2bu6z12hGm5RpXCWHFy5l8TObTf3U8Gp0X9+PwuYB5XlkHEi57A5xywEkgHyJpynTqxq0Z+GpB5TRHPvGMLjueq2ms8wzEssdO94/T0rC/n+Pgvyjf1jIUcNZNaKFarbVo16E/BOLzkzL093RHVLKNvc1M14LmT/AGi3bRuXXHp3dmHL1dpXhUjGpGUJrMWsMwR1EsJWW5bicafhozl7PBnjOUWB1b0epd6fTuKMH+KzKTSOveMHrYez3mp1VYl7AJry5BRbRxPDg4AF8eAYYAAYAB90iUjMMx3Wr1O1RaftutGEvxz7JPyMR7DsPwtumlRqRTjLMpP4nv8AWXV1d6vTtqE34IQxPD4Z6vRHSvHTnqc44cHhImMcelg5WnDX9tpJt9yyfTiqVKFGP1YRUV/IqD+s8kkRaeZVe1ptPdAAMPI3xwOI9x8cYOxptnW1C9p21CDm5PDx5GzFSclorDMRzPD3NgaFPWdVTqxxRpYllrhmcbanChRjThHCSxg8nZ+iUtH0qnRwnU7uR7fh5L5teijT4+Z8y78dOmE+ecgjHxJJWG0ABkAAAAAAfzD7FGeQK/Msvqddqlo1SkpYlLsi8s4TMV9Vrty1OnQi8x8PJ3bdi9TPEIXfM/paWZWRl+DLLi6dUJVdw05eF+FJ8lu49l4MidJbKNS3nduOGpNL4ll3K/p4FH2bH62qhkaksRS+BWEsIFNl9RrHEcAAMMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEPLJIbzwjDEqK0U6bT5MGbvs3a6zW8XHrJNozpJeyzGPVSwl6+ndRWIxXJK7Tm9PLxP2rn6j0/q4Or8LDz2a8mZl2DqP03SYLxZcEomGljGPeXt0r1H1N07BvmbykTW74fUxdX4Vn9P6j0dR0z9srIkhfVJRUX0mAABkAAAAAQ3yzhu6ELi2qUZ8qawzlb57DnLZrvWLVmJYa/7y0+Wk7ir06SahF5gy/8AaV3T1/adXTZSUq8KWG/Mnq1ojutPhd21L24NyqSS8ixdgazPSdaior2K8vC2VG1Z0+pmtvEuX2X4nw8nVLOenajVsai9qm+TrF/9U9Ii5U9Utl4lU5m17veWBn3diH1uD0sk/hoyV6bAAON4AAAAAAfcB34MDg1KyttRs5Wl3SVWlLyfvMQbz2vf7YvVqOlTl6nOfZ8vh8jMy/ocV3b0by1lb3NNVISWMPyOrBnnHPE+Hfo9ZOKeJ7wszYG97XUqMbS+lGjXXGZPuy+GsdnlPsYU33tK60C+d/pym6GfE3FcRZdfTfetK/pQ0/UJ+GsuIzk+5vz6eLR10dmq0dclfVxMgduATjC75zymQR8whZjieJB5gBgxy0+TuaNqVfSr+lcUpNQjLMkvNHTx59w/aRtxZLY7RaGazMTy2E21q9HWNNp3VPClJcx9x2tYtVe6bWtcpesj4c+4xB0z1+ppmqK2rSc6dZ+GKb+qZoi1OCa7MvWh1UarBxPlIY7ddWvG4dOlperVrPlxg+Je887v37oyp1c0F1rWnqFpSxOnmVWS80YrT8STKjuWlnBln8OLLSayl8tMnggEc1wAAB5ZOprN9T0zTKt5UeIxTO4lyY+6yasrbTJaW5YdaOUb8GPrvEOzQ4Zy5YhiXVrieo6xXqwfjdSo/Dn3NmwGy9NWmaDRppLxVIKT/oYY6b6WtR3NRVSPiprv8zYCMfVwhTSworCO7XX4iKwmN5zRWsY6pzkBAiuVb55CcEErLlGMV4pSeEjNazaeIClGdSoqcIuTk8JIy9022vHT7ZX1zTxXmuzXY8rpzs6anHUdQg0/2acl/mZNSUIpR7Itmz7b0/8AJd2YcXHeVaWFgkLkFojw6QAGQAAAAAAAAZT28yp9ilBiezhuqip0pSbwsGDNzXk7zV60py8Xgm0jLe+L36FolapGXhaXBhOrL1tSdRttyeSw7Lg5/wCSVJ/U+q4mMUDz4opebSMz7EsfoOkRjjDmlIxPt+zeoarStl3byZz06iqFrSp/2YpHre83/jef0xpu/q/h2gAVxeQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKXy+CocZwBCwy3t9WMLvQK8VFeNLh+4uI4Lumq1CUGuGjbhv0Xi34cusxerhtX8w16lB0qs6cvrReDu6BfPTtXpXa7xeDs7u0+dhrVTxJpVG2jxn3z7mXWs+vg/2+XXidLqufw2E064+kWlKr/bimdmLecFn9M9UlfaX4KrxKD8KWS8MlK1GOceSavp2hzxmwxeDlPDZUU+ee5UaYdoADIAAA0mML3AGB1tSto3dlVtpdqkXFmANz6bV0jXK1tCTUaUswmvM2ILD6q6DG+0/6XRh4Z0vam0u5C7vpPUp1x5hqzU6o5dLZ+oUdxbbqaTcRzVp03HxPu2Y51qwnpmpVbOaaUHiLfmc219VraVqlKvFuFPxe3z5F9780u313RaWt2Phi4x8cvCvrEDeI1OHv7oc8/zr/mGMuVxgERy+X3XdE+fzIO1eJ4c/AADAAAAAAAAA47u3o3dvK3rwjUpyWMMwvv7alzt6+/CFg5eo8WcxWEn3M2LCODUrKhqFpK2uacakGuFLyZ1afPOOePpIaLWThtxPhY/TPecNRpR02/lisl7M2+WX/wD3lyjBG8dDvtq6u7u28caDllTXzzgyN043bT1myja1ni6j3Tfkb9Rgi0ddPDs1ujrePVx+F48t88IeQfL7/wAh8yOQfAEA+AJjOVKaqweJx5T9xm/pzq61LQ6UKlRzrQj7TZg98pcF3dNNXdhq6tnLEazUUiY2jV+jl4n7b8N+meGZb62p3VrUoVFmE44aMDbz0ero+s1oypuFCcvxXufyM/xeY5x5Ft790CnrOlyko5rU03D5lk3PR/ucXVHl05adUMFdlz3YK7ihVtrqdvXi1UpvDyUPuUW9JpPEuCY4APIHlhFScKVOU6kkkl5mvXUDVamq7gqyqSclRk4Qb9xl/qXqsNO23XiqnhuJL2F5swXp9vW1XUo0YvNWrLL95LaHH0xN5WbZ8Pp1nLLK/RrSPVadUu68HGp4vZfwMiN5fc6WhWUbDSbehFYkqa8XzO6sJHDqL9d5lDa7N6mWZPmiFx3KuRTjKpVVOnFzm3hI01pNp4hxRCIrxyUI/WbwviZC2BsqrVnDUdSg4rvGnJf5nc2Dsf1co6hqUPaa4pSXb3MyTTgoQUYrwpcItG17R/fkdeLD92TShGEFBeSwS1z2JkvMLOC1VrFY4h1JQIjnHITyz0JAAAiWeMEkSAhPgNlMpKKy3hI8PVtz6bY+KM7iHjXGD3TFbJP8Yc+bU48Mc3l7ql7yU2WBPqFSU2oUlKK8zltd/W9WolVgqcPOWTpnb9REc8OCN60kzxEr5y35BvCbPP0nV7LUYeK3rRn78HfnzB/I5bUmluJSFM1ctJtWWM+qupS9dTs4SzGS9pFhRWFg9ve9C8o63UldKTjKTcG/ceJ3lHHfOC5bfWuPBzD5nuuS+bU94Xp0v071179PxxD2TK/GFgtnYOlR0/SYvzqe0y5l5cFY1+b1c0z+F72bTehp4j8qgAcSYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiS80SAHkU8lQfYDHnVPSvW2/06PHq15Ixon7HYz9rdjTvdPqUKiypIwXqtrOz1GtQnHCUn4fkWjZtT1V9OXz79SaL08nqx9vY2FqctP1iEalRxoy7+4zLbzVWjGonlNZRr1GTpzjOP7LyZo2PqsNR0mDyswxFnNvOm6Z64dv6a13P/FaVxLsVFL7cFS7EAunPIAAAAAAAA/M4a9GNajOlUSlGSw0/M5ily96PF6xaOJGC+oeh1NL1epVVPwW1V+xhcHodOtfjRnLSb1qVCt7MFJ8IyVu7RqWsaVUpSgnUUfYyuzMEXtrW0vUpW83KFalLhlR1uC2jzddfEuS9Zx25h7m/tDlpupu4owaoVX7L8i2+e3vMk7e1O23Nok9Kv/D9IhHwwqS5bZYmuabW0m/qW1WL8EZYjL3kbrMETEZKNeSv90Oj2AI/awyMae6XwwOE+XyAAAAAAA+VgPL+AAHn7i0m31rTJ2dxGL4bi2vMwPeUNR2pry8LnSlGWePNZ7GxCLX6h7ao69pkqkYKFzTXiUo93jyO7S5+mem3hMbdrOifTv4l2tl7ittf02nLMYXEViUF957xrxtrV7zbGue1GSXi8E4y4ws9/vM+6Rf0NUsKd3bTU4yXOPJmNVp+ieqPDzuOj9O3XTxLteeCfgQ+HwOzOJEme69xzafWdtf29ynh055ycOfeU1U/DwbMNum8SzXy2L25eK90ehcJ58ce56DSa7lm9Kr53Oixt3/2US8uzPouiv6uGJSVZ5iJY56mbTjcwepWcMVI+1NJdzFs4yhNxmsSXdGy1SnGpBwlFSi+6ZijqJs+rbVZ6jp9N1ISfiqL+yQO77ZM/wDJjhozYvuGPyVyUrPiakmn5o8bemrQ0fQbi58aVVL2E13KxTHM26WnBinJeKwxT1Z1z8KazGhTknChmLS952ujuhu81T8JzXsUJY+BYtepUvr2dZpeOtPLS97M/wDT3R46Rt+GOHXSm1jtkl89vRxdK06y/wC000Y/yuJ9+OxDCTzwm2+Ei7NrbJv9VnGpd05UaP8Aa95HYNLkz24rCpxWbyt7StOvNUuI0bKk5tvD47GWdm7JtdMhCvdQVWtjPtLsz39B0Gy0ihGFCjHxL9vHJ7Bbtv2imL+V/Lsx4Yr3lEUopJLCXYct/AkE5FYjw3IfyDTfwJBngF2ABkCMol9ij+ZgV5OrqF3StKEq1WSjGKy2yu6rQt6Eqk5JRistmJd97mrahdOztZuNGD5af1jt0eltqLxEeEVum400mOZny5t2byr3lWVCwqOFOPHjj5ln1p1a0/HWqSqN+bZQuPZSJx7n2Lfp9Jjw1iIh841e4ZdReZtJFJZIcUVA6umHD1T5d3RtUu9KuoV6FSTjF8w8mZi2trNLV7KNWMl4kvbj7mYPLt6a6lK21WFnH6tV5ZC7ro6zj66x3WTYtxvTLGO09pXf1H0qFzpM7mMM1YL2THe0dOd9r1GjUj7C7mZdWpKvZTg1lNFtbA0b6JUu61emlP1r8Da8iK0+snFp5rKd1m3Vzaytojsu20pKjbQpRXEVhHNzjIRCy3yRUzzPKzUrFYiv4VgAw9gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYB9gKJLMcGNOqOjOEo6lSglGKxLBkznB52vWFPULCdvVXEkdWkzziyxZF7ppI1GCY+2BE2+/mXL0/wBXen6rGjObVGXf5nh6pa1bK+q0KkcNSfhXwOBT8DUoyxJNPJcMtK6nC+b4MltHqImfpsPRqRqU4zi8prJylodP9cWo2EaVdqNaPCWe6Lt8RSs2KcV5rL6jo9TGoxReFQIUuQnk1OtIAAAAAUvH9Cojw8YMSIbTRY/Uva9LU7L6ZbwUK9JOTcVzIvnCIqRjKLjKKafdM5dVpq56TWzzasWjiWt9ld3Ol30aizCrTece8yFVo2u89BVSHhje0o+0l7zg6l7RdGc9WsIOUX7VVf2fkWPomq3OkXkbu2nJYftQ9/zKhettLknHk9suTvSeJ8OC8t6lndTtK0XGpB45OJrKw+5kXUbSw3jpX02y8ML+kvagnjLMe3VGta3Ere5h4KkHhoj9Rpuiea+Gq9eFHu4AfHI4Xc43gAAAAAAAACXv5T8gBE8ETxLF3Vza3iX4WsqXtN+1GPZI8PphuitpV+rCvL8TN+GKk8YZmm7oU7m0qUKkVJTi1yYB31olbQtcn6mMo0M5hNLzJbTZIy06LLLoM1dTi9K7YKLjOEakJeKLWUw3hZLC6UbnjqNktMuKi9dRjnLeGy/sc5I/NinHbhCavTzgyTWVOUye48wjTE93LDI/RK6/H3tGcvJYMp+XbJhrpFVdHVK0cJ+PBmWPMS+bLk6tPEJDDPNFMimrThUpunUipRfdNdzkxhe8h8vhEvavVHEtrF+99h1J3ErvSqal4m24rjBqv1r1h1NVjplOp7VHMasU+EzczqtuantTZl9qjnFVaUG4Rb7nz33BqVTVtavNUllu5quePdlld1ehxUydVfKV2nR1m85Je70w0iWqblt6coSlRTxJpZWfibPaFszVbpUoQt3G2iksnZ9FzYNvom0Xf6hZ06la88NWnKay0jNtKnClFRpwUY+5I2V2muaYteXLuV4zZeOe0LS23sbTtMUalX8fPu1JdmXbSpwpQUKUVGK8kcuOCMIl8GlphjisOOKxHgb8vMkYB0wyAAyAAAAhtjLwAw0UyeHkqzwW7vLXKWlWEvFNKc01H5nvFjnJaKw59TqK4Mc3st/qRuP1FP6BbSzOWVP4GNXzy3y+7Oa9uat5czuKzzKTycPDLpodLGDHEfb5fueutqssz9DzjgduF3HlgeR3otIIAZG+D19lSa3LbNe88k9rYdF1Nz2+U8cvJx6+YjDMy79srNtRWIZqpRVShiXuOSFOMFiMUkRSjiCRWlko8z3l9Wx1jpjnyd/gF2x5k+H4ho8tyQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7AMCM+eSJLPBCfkwjEMTHLHXU7Q/EvwlRh7UFhpIx1jLcWufM2C1G2p3NtOlOKkpLzMJ7q0uppOqTpyi/DPLTLNtGs6o9OyhfqLbpx29WkeTauqz0nUoVm8wb8OGZssbmF1bQqU5J+KKfBr5yvn5GQOmevNT/BtzP4xbZndtF1R6lWP0/ufp29K8+WTEv6krvx2KYyjKPHYmGEVlfomJ7wqAAZAEAAAAESJKZpv5GJFFanTq03TqRU4tYaaymYn6h7NlZ1amo6dBypSblUjjiPyMtLHmU1acK1NwqRUovyaODWaKuopxMd3m9ItHDXXRNTutJvY3Nu2vC/ah2Ui9tSt9N3hpyubNqN/SjzFcZfxKeoOyalq56lpkPHTbcqsfd8ix9PvLmwuo16cpU5Qf1feVPJjvppnHkjs45iadpU3trXsa7oXMXGcXg4cYy2X1Ru9N3TQVvdKFK/S/FtdpfMtXXNHu9GuHTuYtwlzGUeVg4s2n4jqr4a7V+4ecsv4Esc9veDieAAAAAAAJeAwjs+C3OoOhUtc0dpxSnRTmmu7+BcYwmnGSymbMV5pbmG/T5rYrxMNa9MubrQ9ZhOSlTnSmvGvejYPbeq0tY0ijd05JuS5wYu6v7cdnefhalFqnWlhpLhHV6T7jem6n9Cr1H6ut7ME32ZKZqRnx9UeVk1eKuswRkr5hmwnyIXOGnlPnIIjjiVWtHE8Lw6Vr/4u/mZpTxEwv0qTesSa8nyZph2LtsXwu7B7U4KZYz7ir+ZaXVbctPa+zb7UXUUatOn7Cz3Jq1umOZdFKTe0VhrZ6XW+vwprFLQdPrfiaLcLiKfmYv6M7Zqbo33Yaf6rx2ni/GPHCLb3HqtXWdbu9WqNydxUcmvmbZ+iPshaPoNbV7ukvWXGJ0ZNdkyIpzny8rJlmNJpun7Zz0Wwp6ZpdtY00vBQgoI7iisZJT7EYfkTUViI7K1M8zzKY9iSEsEnpgAAAAAAABTJvJHwb7Ey7nBeXNO2oTqVJKMYrLZmKzaezxkvFI5l19Yv6VhZ1K1SSXhWeTC25dXq6vfyqzk/VN+yvcenvfcVTVLt0babVvB8NeZbK4fzLTtmg9OOu3l893zdpzX9Ok9oMeQ48h8EEscE4rAAT2DKCSCQwF/9KdMU3Uu6scThL2WWNYWtS/u4WtJNym/JGbts6dHTtOp0VFKSj7XHdkHvGpitPTjytH6d0U3zepPiHqr3FUSl/EqjjnBVOX0OEgAyyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHyBCw+cE/JBLAApkmWvvrQo6nYSlSgnWS4ZdE+5TKKlFprhmzDlnHeLQ5tVp66jHNJa8VacqVaVKonGUXjkUKs6FaFWE3CUWnmLL66kbflTqvUban7KWJJIsJ8PC+sXTS566nF3fMNbpb6LPxDMmydep6nZQhOa9alyi50vjwYE0LU6+k38LqlJ4bxJeWDNOg6nQ1KyhWpTTyufmVvctFOC/MeJXXZN0jUY+i094emsfEnsQnnhktcEUsZHhEkR7EmQAAAh5fYkAQlhEgAcc4QqRlCcVJPumu5j/emxIXbnd6bFKt3UeyMhZWRjPbsceq0mPUV4tDzasWju1ruaF1p95OjWU6NaEseJcf5lzaVuajcWv4P1uMXQa8PrMZkZP3HtbTdah+Pp+Ga848GI9y7U1DRq8/FT8dDPsY5eCq6rQZdLPMd4cl8dqd4cuqbabg7zR5ettHz7T9otySnGTjODjJPHKO5pmq3unVFKlObin+Tn2/oe1Uu9F1mKneKVK7wklBYiRtqUyeO0tUxErYfHKJ7cI9LVdGubNOpFxnSfbwvLPNWc4w18zkvSazw8zEwAA8MAAADsBzn4AefuPTaeq6RWtqkPE1FuHzNd9StrjR9WlRl7FWlLK+Bszxn5GKus+hYlDVaEfanL20l5ElosvE9Ep7aNVxb07eJXZ021uOsaHTjKadxTXt8l0J5eEYA6d69V0fWacE/xdaSjL4Iz5CrGrS9ZSacZLh5NWqwdN+3259z0vpZeqPEsg9FqMqmo3klj2Ussy0Y96NWjoWles19eK5MhcFy2fH0aeOWnDHFIFj3mnvpZdQFrGvR2/p9R+rtJOFwk+GzYjrVvCjtHZ93X9aoXc6b9Qm8ZZoNq97daxqtzqdeEqla4n4pOPPc263LPHTVN7Zhr1dd57PZ6YbbluneVjosac3SrTSk0uEfQnbOl09G0Gz0umklb01DKXfBgP0SNkw0vS62uatCnCtUanb54eH5mxCuref1a0H8pG3RaeaV6uGjc9bTJk6ertDl8sFUeFllEZJ9miptnZxMI+LRKpPJCWGI5xySZZAAAKZ9ioiWccAU/cT8ERnJxV69OhTc5ySSWWZiJmezxe8UjmZTdV4UKUqlSSiorLbMU773TVvaztLWWKCf1k+52d97rlcVJWdlP2V9Z5wWNzzzlFj2zbfGS6j73vXVzixyLj+ZJT9V8ElhiOFPmeZ5lJAJMsIJIABht+HMVlh48y4ti6HPVdRVWcH6im+cruc+ozxhpNpdWj01tRkilYXR000D1FNX9eHtS5jlGQopLyOCyoQtqMaUIpRisJHYKTqc85rzaX1Pb9HXTYorAADnd43gJ5IlyhHsBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIa5yEiQB1ry1p3FGVOaTUljkwzvDQKukX83GOaEnnJm9rJ5G4dKoanZToVo59z+J36HV2wX/AMITd9trqsXMeYYJT4ye/tDX6mkXsYVJN0ZPB5+u6VcaTfzoV4+znMXjjB56zjK7lstXHqsT57S+XQ5vxMNg9Pu6N5bxq0pJpnZyzEOxdzT0yrGzuZN0JP2X5pmWLavTuKUZ05KSazwyoazSW09+J8Po+17lTV44793NFlTI4wO6ONLcpbwCMkgAG8IiLyBIAAp8ISZUAGF3OKtQpV01UpxkseaOUpXHB4tSLRxIsLc/T+3vPHX09KNZvOHwjHWubc1TR66hcUXJvlSgs8Gwbwjgr21Gsn6ynCWfeskNqtox5O9e0tVsMW8NdrLUbuznlNtrjw1Cq8u6d3TdWpHFx/d7My/rGwtHvpSreCUaj9z4LL1TpzqdKpKdpODguy+BBZ9q1GP/ADDnthtCyPIHcvNMv7SpKFS2qvD7qJ1KkKkOZ05R+aIe2DJXzDRNZhAIbi/NEp57HjpljuBvgZWeO4z7zyC75OhuGwp6lpFxbzipScGo/M75MMRab5NlJ6Z5iWzDeaXizWLUrWtpeoVLdtqpTfddzNvSXWPw3pFLTlLxXFJYlnzZZnWjRvot9T1OnFfj5YkdPojrC03qDplCc/BC4rxjKXlgnqY/3Na8eVuz1rrNLFvuG9Wx7R2e3bWnKOJ+Hk9mrUp0acqlWSjFLLbPO1HVrHTbFVHVg4KPHhfcxxureVbUITt7RuNCXDfngvW3bbkvSK1hTNduuHR14meZY063Q1rqDuj6LCUIadp9Twpr9pN8/wCWP6nR0TYOh6dSjJwdWpy2n2WV2+PvLpisPxR49/xKiyabZMGOeq0cyqOt/U+qzR0VtxH+FcatSFKFKlUlSpwWIqHH3HPaale2k/HTuKj+cmdQnGUS37bHxx0oD93m6urqlfW2N8VY1FT1J+znhpGSbO5pXVCNajJSjJZRr3+0pdsGR+lmqznQqW1aeZeL2V8Cv7nt9aR10WzY94ve3p5JZFiSRHsSV9doQ1ljKzgkpw08swyqzzghshe86Oqalb2NCVSrUSwveeq0m88Q1Zc1cdeq0ue7uaNtRc6slGKWeWYs3tuupe15WllJqiu795093bpr6vUlb28nG2TyvJltYect5ZZdu2vp4vkUbeN8nJzjxSltt+JvLfvIXDbALBERHhU5mZ8nbnzBIYeQgldiHyAyM/BhYa+Ry2lvWu7iFvQWZTeEeb3iscy2Y6Te3TDn0XT62p38LalFtN+08djNO3NKpaXZQpRjFSx7TXmeZsnblLSrRTnFeumk5P4l0pJYTKhuOtnNbiPD6Jsm1Rp6Re0dzzKilPnCKiKWQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKO/BWRhAmOVv7r0G31aylGcfbXMWu+TDmp2VfT7uVGtFpJ8PBsG4potbeW2aGqW8qkIJVlymS23a+cNum3hWd62eNRWb0juw5FvGU+feXdsfdNTTq0bS7k5W7eIvPKZbF/aV7K5lQuIuMl2eDr/AA7P3lkzYceqxqVp9Rl0Wbnxw2GtK9O4oxq05KUWuGmcy4ZiLZG66mmzhY3cpSodo/AytY3dK6oxqUpqSa8mVHV6S+C3E+H0Xbtyx6ukT9uxnHckp8/cTznhnGlkgjn3oRznkCQAAAAB9iGkyRhZAjPkMp8MkeZgUvj5CSWOxV2BiY5HBK3oS+tRpvPfMUeLqW0tIvqjqVqHL93B7+X7gmzTk02PJHeGJiPtZV3060SacqVOcZv3y4PDuemlXxP6NUil8WZQb5w+xOF7zkvtWnv5h4nHSWIK3TTV28wrUjj/ANWut4x62j/UzF5ByUVy8Gj+h6aXicWOO8sPf6s9bx+Xo/1OWh011RLNSrTb+ZlC81SztoSlUrwTS82WTrm/6EfHRsoy9YuFJrg6sP6ZxZJ4rVwanWaXTxzaVq7+6Xafd7Ovnd1Iu9pUZOjHPDlgwLsjpjXo1qN9qkmvVzzFriaw329z4XPxM2atrV/qcs3lVv4Lseen5eRadB+mMOHibIDVfq3NXHOLT9oVutWdvC3VWo6dNYXik2caWO38yfgMFpx4q444rCnZc1ss82k9+MgDt3NjSEkZ7sl8r3ARldnku3pnCT1iE1nwplpPMvZiZO6X6VUt7OdevDmUsx+RF7plimGa/lObHgtk1FbR9L+j9UlFDb7FSylyU19PhJRnC5Zx17ilRg5VJqKXm2WLuve1O3jK3sm/Wt4z5G/Dpr5rcVhw6vX4tNXm0vf3JuSz0qi/FNSn5JMxRr+u3mr3DdWo1T8kuODoXt1cXdd1rio5zb95xY8mWnRbbTDETPlQNy3rJqbTET2EsdgvevMLgErEcIKZ5SuFggAyJAIfwAEkfcTGMqs1TpxcpS4SR5taKxzL1Ss3niCEJ1KihSi5Sk+yMobB2vC0pxvbiP4yXKT8jh2HtONGnC+voZqPmCfkX9GKgkkkisbluXXPRTwvGybL0cZcsd0pKPCROHnkqwRhZILnlcIjiOyF9YqGOQGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJJNckkT7DkmOVqbz21R1S3lUhFRrJZT95iW/s7ixuHQuYOLXZtdzYPGeGi3t17ctdWt2nBKp5NcEvt+42wz028KxvGy1zxN6eWFm8P4lw7V3NdaTWjTnNyts9n5Hma3pN1pF1Khcwbgn7M8cM6K+PYslqYtVT/ClUyZtDl7eYZ60bVbbUraNajNNNds8o9HKxnzMDaFrV5pFyqlGo3Tz7UfgZS23umy1GipTqxpSxypywyr6zbr4Z5jwvW2b3j1ERF/K58rCb7kx5Z16d5bTScK9OWfczljUg+0kRvTMeU7XLSfEuQFPiT8ycjhsi0SkDKBhkAyQ2BIIckR4l7zPDHVCoFEqsEsuSRxTvbWH1rinH5yRmKzPh4nLSPMubl+aIPLvde02hBy+l0pY8lItq/wB/WVGTjCEpY80baaXJfxDjzbjgxeZX08e861zeW9v+UrQh82Yt1Pfd/VT+hS9W/ijwL7WtTvvzqu5fLgkcOzZrd5Q2p/UuCvavllTWN36fYJ+2qr/uss7Wt+XVw39BTpx90iy5KWc+Jv5sIlsG0Yqd7eVd1X6g1GWeI8Oze391fS9ZXqycvmdXHu5fvJalnvwO3YlKY60jiIQeTNfJPNp5O5KxgjINjXwEggMA7PkkpfD58+xiZ4ZiOZVFOG5eFLMvLB3tN0u91CvClSoTal+3jhGQNrbHp2z9bfJVJd18Dg1Wvx4Y7+Urodpzame0dlu7O2pcX9xG4uYtUE+U1yzLVpbwtqEKVNKMYrCIt6NO2pqEEopLg6Wr6xZ2FGU6leHiSz4c8lX1Goyaq696LSYdvx8z5elKSSblg8PX9y2Wl0JTnNTa/Zi+Sx9f33XuPFTsE6a7ZZZ11Xr3VZ1a05Sk/ezu0m02v/K/hF7h+oq05ri8vd3Huu81WUoUZOnRb+r5lvZzLxTy5e8h89uGT5c9yxYNNTDHFYU3U6zJqLc3kWfMlLgpbfYlcdzocgCSAAJIABPySHkctrb17qrGlQhKc3xwjza8VjmXumObzxCilTqVqkadKLlJ8YXcyTsLacaCje3tNSl3gn5HY2XtKlaU4XV5BSrtJ/IvaEFFJRSRV9x3L1OaU8LzsuyenxlyR3RGKhHwpFXuXmGmieUiCmeZW6temOIT5pElK75KjL0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENZJAJjl424tFttXt3SuKak1zB+5mJtybcvdIrP2ZVKS7uK4SM3v6x172zoXdGVOtBSi+Gmd+j199PP8AhB7ntGPVxzHlr4sPmLKk3F+KMmvky894bLq2tWdzp8fxT58CXYsypCpRqOnVg4T9zLVp9Vj1Fe0qDq9Fm0l+Jh3bbWdQt14aNVxx2yd6juzW6cl/vLa8+Dw8NPuTnnser6PFk8w8Y9xzY/Erst9839N/jZOWPI79r1DlFP1tGb92CwxnyNM7Xgn6dNd71VfEsiLqNT/8PM5IdSbdLErWq2Y34HHuNc7Tp5+m2v6g1kfbI1TqRQb9i1qIp/1i02vzeZjvz7oZwZjadP8Ahif1Bq58yvq46g1Jt+qpyj8zz7nfGpTX4qbiWou/bBJ7jbMEfTVbetVP29qruvXKqad00n8Do19Uv60vFUrtvtlNnTzzhofI349Jix+IcuXX5snukeW85f8AUEkHRFYcvXaUkAHp5AAAJwiCcMCFw8dxxnhB8fAmlGdSXhpxc5Pjg82tFY7vVaWvPFe6HnAbSX/Q9rSts6nqFTHqpUY+9ovTQ9j2lu/Ff+GtLy+BH59yxYvE8pXS7Pnz+Y4Y+07Sb+/qJUaE1F/tY4L40DYcIpVNRcaqfOPcXdCppel0lDx0qUV2zweJre97CybjRXrn/dZEZdbqNRPTSOywYdt0ekjqy25lcen2Fnptv6uhCMIo6upa/YWMJOVxT8S/Z8RjTVt6aldzat5ypQfkW5cVqtxUdSvNyk3nlnrDtF7z1ZJY1P6hx446cML13BvytcqVLT1Km1x4n2ZZ19eXV7P1tzVdSp78nXzh4XBL9y4JvT6LFh9sKzq9yz6mf5yLsAnklnZCP5lABIAgnIMgBggwHn8B789h2eX/ACPb27ty91aqn4XCl/aa4ZozZ6Yo5tLo0+myZ7dNIdDSNMuNTuFQoReW+X7jK+1Nr0NKoxlUSqVscy953NtbfttKt0oxTqte1LHc9vBVdduNs08V8L9tOy009Ytk8iXkuCqP+ZTn4FUe5FLJEcJAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYWckOPuZUDA4501KOJJMtPdG0LXUYyqUYRp1u/iLwfYo+Zuw574rc1lyarR4tRXi8MC6zot7pdaUa1Kcor9vHB56aa47mftR021vqTp3FKM4vyaMe7m2LKk6lxYP2VzGnFFi0e71t/HIpO5fp6+Pm2PwsPyJ4fxOS6trm1k43VKVJ5x7S7nEsPlPBOUyVvHNVYyYbY54tB3yH24HZ9g/ge2swu/mBw+fNACSCQBA4ADIAAAzyGGk/MMGV7xlLuyfCksnYtLi0pJxr2vrHn62Txe/THPDbjx9c8TPDghCdSXhpxcm+yR6Fnouo3LWLepCLf1sFdPVrWimqNp4X8MLP8yqpuHUmsW9X1UPd3ZyXtmyeyOHdipp8XyTy9ey2dGM1Vu7yCguXFnuW1HbOnYnGdF1Iv8AtFhV9V1KsvDVuHJHSmvE8yfJzW0efLP/ACW7Oym4abDH/FXuyVe78s7VeqoW7n5ZRbup701G4f8Au05US1017h3NuPa8Fe/lpy71qbxx4h2r3UL6+ad1XlM6nhSfBVgHdTFWkcRCMyZ75J5mUeXPcLL7kpg2NJhEY5AAkgACSECUGUPhe8L49xjL74Yj7U/Co5k/Ixa0R3lmtZtPEGSuhSq3FT1dvTlUl7kj3dv7U1HUqqdWE7en3y13Mk7e2vY6XSTVKMqvnLBE6vdMeKOK95T237Hm1Exa3aFp7S2VOtThd364k/yclhoyLp9jQs7aNGjTUIR7JHYhFRiklwV90VnUavJnnm0r1ottw6WvFY7qCVH3slok5kkjD8mEsEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7FC5eCsYXuAp7dyGk45ayVtIYQY4eLrO37DUoN1aEXN+eOxjzcWx7qylKvaN1ot8QS7GXSmcFLhrJ2afW5cPaJ7IrWbRg1PeY7teLq3uLWp4Lik6b9z8jjXfOeGZ01bQdOv4SVa2g5P8Aaxyixtb2DUh461nWbS7QwT2n3elu1uyoaz9PZcUzaneFhx7sk799pGpWSk7i1lCEf2mjz/EnxnBL0zUv7ZV/JpsmP3RwkkfAg2tIB37BPPkOWADOA155DI8+QaRKXADCPIh+RUQY4ZTwRhpcMMkyIbHxaAHALD8ieBgYDABghZ8wJRBOURl57BkAy8YxgdhyJIDwuWzltqFxdT8FrRlVl7kjxfJWnunhspivk9scuIjlvC+s+xdGjbL1G9Wbnx26+KL50LaGm2cF6+hCvNftSRGajdcWPtHdM6PYs+eYmezHOjba1LUa6hKhOlFrPrGuDIG3dlWlhCMrmMa9TOfEy7KVCnSio04qKXY5V3wQGo3LLl7RPZb9FsWDB3tHMuKlShSioxikkchXhDC9xHTMzPdOVpFY4hTF5WGVDC9wMcPaE22SAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAKXjyZGE+6Ja54GHkw8zHLqXtjb3dJ061KM4vyaLc1jZOn3tPFGEaEvekXc1jsEsG/HqMmP2y5M2gw5/fDEes7FvLODdrKVw/dgt260fU7Pm4tZwXxM+yimuUde4sLe4X46lGa9zRJ4d4y0n+fdBan9NYrx/x9mvviiuCeJLgzZfbV0mtScY2lKDfmkW1ddPKM5uULmUV5JIkse947R3hB5v0zmxz2nljhr4ZI5Ls1LY2oUPzVSrcnlVNs67BPNlLj3HdTXYL/wByKy7Xqcc+146yngk7VbTr+hLFWhJHWmpReJRafyN8Z8c/bmnS5o81CCPF8x4ljOH/AEPUZaT4l5nDePMKiCPEn2yMr4/0PXXV59O34SCM/B/0IUufMxOSseZZjDefEKiUQm2+E3/I5aVvcVninScn7sHmc+OPt7jTZZ/tcf8AIjnPJ6tHb2tVY5p2cmn2Z3bTaGsVWlVtpRXmabazDX+5vpt+pt/YtxtLzGVjP+Zf9n079ZBOrcyi35YLg0rZOn2rXrYKsvijiybxip47pPD+ns+TjnsxLa29zdT8FvSlUfwPa07aWrXVZRrW86UX5mXLXQ9Otn4qNrTg/gjvwpRh2RG5t5tf2RwmtN+mK0+SeVgaV09pUakalxW9YvODXBdmm6Dp1i06FtCEl5pHq+EKL95GZdXlye6U9p9r0+D21QoxUeERjgqw8ktcYRy8pCKxH0jl/AR7hpr4kpNCGUgAMgAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAAAAADAAAACH/AFCWV2J4AY4hT4ceSKXBNYcUyry4IyYif8sTWJ7cOnX02zrNupQpyb96OtLb+mTfNnRb+R6v8ipcI2RltH20TpMU+YeJLbOlP/uVH/CcE9qaZJ4+j018kXDnD96Jzz2R7jU5I8S1W2/T281Ww9n6dnilH+g/0P07v6qP9C5mT2PX7zP+Wv8Apel/9VsQ2hpsZZ9TFv5HZhtnSk+bOk38j3Se/Bi2qyz5l6pt2nr4q8dbe0pf9yo/zic1LRdOp/UtaS/kei8ruEePWt+W6NJij6cdOjTpxxCKRyJLHb/InKCTNfPP23xSKxxEGF7icAB64AAAAAZAG0gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACM84JGFnIAAAAAA5yCHnyJXYAAAAAygAC5AAAAAABDfJIAAAAAAAAAAB9iFnHIDPOCQAAAAAABhEeFEgBgjHOSQAaIx8SQAwiGskgBgYQBjgQ+H7xjPwJA4FLWCV2JBk4ABlAAAAAAEeEkAA1lgAwAAMgA2gAAAAB5xwRHPmBIAAAAAAAAAAABgAAAAfbghZ8wJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU5zwvILkCoFGf6kr4mORUCnOc/AcvkcsJefIkpWfPyEVzljllUCHkLgycpI8KIXPcOWX8DHIqXCBR8uxX5YMgCO3GScc5AAAAAAABGUYEgpysiXvRlhUnyCM8ZZHflGOWVQI5wQ17zLHKoFLEu2QcqgUrnklYzgMpAIaywJAAAESzgp88MCsFHOcBYb8zHIrTyg3goWUyXn+RkVApzhhZ7mBUMohZXL7jL80OROV7wQ+xTz3YFYxyU5XkE+RAqAZCfODIkFLyn8BlPgCoFLbQbwkzAqBT/AHR8DLHKoFDzjLJa8k2YmeGUtZZJRl5Jbw+DIqBCeSQAAQAAAAAAAfYobfYCsFPYkMJBGHjuMMMpBSsE/MxyJBTJ+SRL4jwORIKVxyyoyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYDjqSp014pzjCPvbwcL1Cw/8bbf/AJEWT14nVh0+1GpSqzpTjQk4yhLDXBoPR1bWZQ8X4Yvs5efxzOLNrIwzxwkNJt9tTHMTw+lrv7D/AMbbf/kQV9YZ/Pbdt/8AmI+av4V1nPGsX/8A+ZnPY61q9G9pVpavfYhLL/GtmiNyr+HXOx3iPc+lKnT8PiU14X554OnqOs6Xp9CVW5vKMVFZa8ayag6p6Qeu2227PSdFUZunT8FWdX639TEmu7l17WLyd1d6jcRlN5cI1HhHq+4ViOzxi2i9p/l2bua71v2Po7l9KvJvw9/AslqXPpL7MjVao1KsoeT8JpzVqTqc1qs5/vPJRCmsN045Xnjk5ba+8+HbXaMde8y3FXpL7QfPjqf4Su39JbZvrcXFSrGPwizTr1NXP5rV58/AUygoP24eH5rB5/eZHv8ApmGW9mg9dth6w0ra7qJ5x7awZA0nXtJ1Ogq1pe0Gvc5rJ81ITlTeaVSVP914PR0jXtZ0u7jc2uo3Xij2i6jwbqbhMeYc+TZo/tl9LISjJeKLUl70T8jTHYHpFbl0uvTtNZhSnYrvNcyNnun3UXbm87KFxpl1FSfDjUai8/I78Wqpk8InPosuHzHZePDJXBTnz8ic84OlypAAAEZQygJfYpXb4EtplLklFtvCXdvsYmTycYKZ1KVNZqVIwX954Ma9UesG3Nm0Z0J1/W3jWIKHKyavdQet27d0zq2qqRt7TLVOVN4lg5cuspjd2n2/Lm+uIbg7j6hbY0GcoXl7BuPfwSTwWFqfpIbBt5zo0a9aVWPD9ng0wqXd9VcpVr64qyl38U2cChGcvZh6yfnhZZwW19p8JSmz0r3tLcRekvtHhOdTP7pL9JfaSkvbn4fP2TT+NrdzWVp9zL5Umw7S6iszsLmK+NNnj91lhtjbsEt1dK9IzYF3Wp0XcVo1Z++PGS/du7+21rzSsr6mm+3jkkfOlpU2uPVyX8mjnpXl/Ra9Rf3NN/3JtHuuvtHlrvs9Z9svppTrUaqzTqwmv7ssnLE0H2R1m3ftZwo29ZXFBfW9bLLNlel/Xbbm550NOvKzo6jNc5WI5O7FrKX89kXn27Li8RyzIDjoV6VemqlGpGpBrKcXlFTa7nXE8uDwqAI8SMiX2OGtWo0l4q1WnTj75NI5ZZ8jBPppXF1b9NbaVrc1beX0qOZU5NNr3cGvJfory94sfqXiv5ZsV/YLj6dbY+0Q+n6f/wCNt/8A8iPmpT1XWFD/AIve8r/msfhXWU1jWL7H2zI/+pR+Ez/RLdv5PpYr2yk1GN5btvslURyucIxzKSive2fNzb+4NTsNw6ff19VvZUbevGpNOq3wn8zK3UP0hNw6rWlY6MqcLBRSU8Yk35nuu4VmOWm+0Za26Y7tuda3Ho+kUHVu72il7lNZLB17r1sLR5+rubuo5N4XhWTSTUNZ1fULmde51K6k5PPh9Y8I6M5Sm81ajm/PxPJovuEz4h149lj+6W4tb0l9mesfqp1nH4xKf9pfaLXszqN/umncYeL8nTcs+5ZK3b1oxzK1qpe/wcGn95kb/wCmYY7NybP0ldjSbV1VrR92Il1aD1p2RrLgrW8kvF28XBoS4Rg0pQ8Oe2UV06tan+Rr1IL+7I9V19o8vF9ox29svpfYarpt7RhVt7yjJSWUlNHd4azlY+B829vbr1/Q7pXVnqNxKcHmMZzeDO3TP0k7mjOnb7vgo0Y+ypU45bXvZ2YtfW3aUfqNpyY+9e7a9cfINJng7S3Zo257CN3pd1CcJLKi5Lxf0PeXCO6totHMIy1ZrPEjfOGUyxHvhL3nh7w3Zou1tNqahqt1CFOHeKa8X9DXDqV6Sd1UrTt9owUqXbxVImjLqaY/Mt+HSZc3tjs2iutSsbWlKde7oQUVl+KaRj/X+tex9FqSheXk8xfPhWTSrcu8txbguXXu9RuKUpcuNOo0jwqtSrW5r1p1Gv7UsnDbcO/aErj2bt/KW5F/6S2yI1fDaVKso+9xOB+kvtFPDlUz+6adRjCfCim/gVeoqLta1H8oGn97kmezp/peGsd24kPSX2h6yLnOp4H345Lk0br5sDVKip213V8fuksGi0qShLFSk4fvLBMJOL/FTcH/AHWZrrr18sX2jHaOay+kuh7l0XWbZXFnfUXF9k5rJ68ZxmswlGS965PmfY6rq1lcRrW2pXUJReVH1jwZb2H6Qe6NFqUrPUlCpZQ7y7ywdOPXxPaXDm2i9Y5rPLdbLwVlgdN+qe2d50IqxulCsorxRqNRy/gX8pJrKeV7yQpkreOYlFZMdsc8WjhIITySnk9vAAAAAANZWCl48ip9ixOrm/rbY+jyuqqbquOY8cHi9opHMvVKTe3TC+G4x5bSXxOOV1aweJXFKPzmjS3cXpHbzvpSpWULeNCWcPs8Fjar1H3RqVZVqt7UhLGGozaRxW3CtZ7JPHtOW8cz2fQr6Zaf+Ko/40Pptp/4qj/jR86v9Ntyf/5Kv/jZC3vuTOfwlcfH22eP6lX8Nv8ARcn5fRiNzbS+rcUn8pIqU6cnmM4y+TPnppnUzdmnxapXk6nP7Uy5NN6/7809JUVQn7/HyZjcaz9PFtnyR4lvRHv8CeHwjUfb3pNa2q0VrdGiqeefBHyMw7N677K3DUp2sLipTuJd/GsL+p0U1dLfbjyaHNTvNWWO/fuSuEdayvrS8pqdtc0qyayvBNM7Hi950xMT3hyTHE90ghNMZMiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wGPuvX6vNS+wl9x8/bf8m/mz6Bdev1eal9hL7j5+2/5N/NkHr/csuz/ABq+PMlpprBDx2x3DzGOER6aRiLn2Oays7q9uY21nQnWqTeF4Y5wLK1r3t3Ss7SDnXqvEUllm5/o/wDSPTNtaRb6vf26nf14qfhms+F/zOnT6ecsuHW6yunr/liXpz6Omsanb0b7cPhhb1kpRjF4kl8UZh0n0dti2Fv4FC4lKWHJuWeTMSSjHEUkvchnt7iZx6THWO8K1l1+bJPMTwsKPSXaKto0Poa8MY+FPCyeBqfo+bFvqdSM6VePj59mWOTLssZ4zkj4f1Pc4Mf4ao1OaO/U1J6g+jZqFnGpX21KLpRWcTllmBdZ0rUdHvJ2l/bzo1INp+KOE8H0wfhlw1le5mMutfS7TN66PVrUaFOnqFODcJJYTOLPoYmOapLSbpasxW/hod3+R6W3tb1PQ9Qp32nXNSnKDT8KlhP+Rx6/pl1ousV9LvKUqVWlNxSksZSeDpdlnzIrm1JWHimWvLc7oR1tsd2UqWiaxNU9WjH63aLX/uZvi1hPunyfMzSr+40rUKWoWc3Tr0pKWU8djeH0feo8d67bo072pB6jTWJJeaXmS+j1XX/GyubjofSnrp4ZVIT8mHx2JXPJJIhEkRj2mS+Xz5B5aWDHIonKMU22opd2zXv0h+tlLRY1dv7crRnecwrTzlJfBntekv1NhtbQZaVp9WLu7lOnPD5ijTCvWq3NadxdVZVKkm23J5ZGazVcfxqmdt0HXPXfw5dRvbvUbmd3fV51as3l+KWUjrPOOOW/ImTioub8jLno9dLq29NXWoX1KUbC3kpZax4lnyIylLZbcJ7Nkpp6c/h4PTPpVuXe1zGdrQdK0g16yVSOMr4GyWzfR32npVKnVvYVal13lzlZMwaLpVjpGn0rGwoQpUqUfCsLDfzO81wveTOHR0pHdWNRuOTLPaeIWtY7B23Z0o06en0GorzginU+n22r+i6VWwpJNY9mCLqfuJWH7zp9HH+HJ+4yeeWD93ejntHUKNSvZKtTu8Pw+1xk136j9H9z7LVW6r0XXtM5j6peJpG+74fB17+ytb+2nb3dGFWE00/FHJz5dHS8dnZp9yy4p7zzD5ldvrJr3p90TF1KUozoVZUppppxeGZ89I3ozW0CtV3Jt+nnT3mVen3l4m/IwF8k0/NPyIXJjtitwsuDNj1FOYZz6Jddb3btzR03cdR1NMbUPEsuSfZG3+k39rqdhRvrOrGpRqxUotPPDPmY/Dw8cIz/AOjB1Tu9J1WG2tVuM6fPmMpvlM7tJqpiemyK3Hb4468bcDPuD55IpThVoxqweYyXiT+BUnkmYV5JgT02v1Z2/wDEoz2YE9Nr9Wdv/Eo0aj2S36b5atOYfVXyJzgiH1V8ipZWW8YK3byu9PbCHx7K5HCS4CTayejtrRrzX9ct9KsKUp1K01FtLKjnzYrWbTxDF7RSOZU6Do2pa5qNKx063qVKlWSipKOUvmbA7B9Gm4uY0626ppReG1SlhmaOjXTPTdkaDRjWo06uoyj+Nm0mk/gZFwuEuEvImNPooiObK3q90taenH4Yn0zoFsWxVP1VGs/AuPE0z27jpJtGtayt52i8MljKSyX7nD94yvI7YwY4+kbOpyz/AHMNa76Oux7+3fghXhVivxeJJIwx1F9HrX9FpTvtFUKlrTTlOLeZNG5qTXLfJTKMaicZxUk+6ayjVk0uO8dobsO4Zsc888vmPd29e0uZ29zRnSqxeGprGTifOE0jcn0i+ken63o1fXNLt1C/opyUYLCb+SNO7ihWtLipbV4uNWm/DNNY5IbPgnDKy6TV11Nf8vf2PvXXtoalTvdKuptwlzCcm448+DZyn6RGjVNjyvY+JapTppVIvt4scmoCxhjy8Em8PyzwMepvSODPoceWYmYXJv3e2ubz1Wd3qd1NUsvwQjJpY+KLbScYuOFhvOQ3hLgmEKsqkKVKDnOclFJLPLNU2teXRXHTFXsqoUqtevGlbUp1aknhRgsszJ059H/cWvqnfaoo0rGflnEjKHo29HbfSrOluPXqEal/USlSTWYqL96NhKdOnTgoU4RhFdlFYRI6bRc97ITW7pMT0Y2GNE9HLY1koVKsbidVd8y4yXXb9I9pUaHqo2mY+9pZL+iTHLefIkY0+OI8IedVmmfcxPq/QLYupxarUasc/wBlpGLt9ejTVo0p1Nr1FiKz+MfdG1GMkY9/Y8X0uO0eGzFrc2OeeXzV3Joeqbd1OpY6nbTpzg8eNxxF/wAzzW/E8JcM+gPVvpxo++NBq21e2hG5inKlOCSfi8ss0W3rtrU9p7huNF1OGKtJtqSXsteREanTTinssWi11dRHE+XR0rUL7SL+ndafc1KVWlLxRUZYi38Ta3oJ10p606WibjnGF5xCMlwmzUiL4+JXaV69pdwu7Sbp1qT8UWnjk8YNRbHZt1eipnr/AJfTmMlKClBqSfmnwyqDyYU9GTqZT3Zov4Ivqi+nWcF43L9r5Ga4tZ7YJ/FkjJXmFSzYpxWmsqgAbWoAAES7GM+uWwbvfOlK1tJQi1HHtMya+SMJHi9YvHEvVLzSeqGn69GbcaS9u3XykVv0ZtwYbVWj4vL2jbzjvyTHLOb9nR2RuGaPEtKLn0Z+oPr5OhXs/Vt8Zl2Ohd+jx1BtJeGo7abxn2eTeVZa8/6kOMJcySb+J5toaTHZsrueas8zL507g2DubQ/FG6sK1WUXh+rptotuvRuqGVc21Wjj+3HB9NKlnZ1Yv1lrQn7/ABU0yw979Ito7pU53lo6dRrj1fs8nNk2/iOay7cO8d+Lw0DXhlHPDRNNyh+RqTpS98HhmX+r/RDW9pTnqOm03W0xdoxWZIxDJOE3BpqS4a80R96WxzxKYxZseavNV6dPuqG6tlXEXp1269BvE1Wk5cG2/R3rDoW96cbOVZUdRhHM1NpJv4GicksYRz6fe3enXtK9sq06ValJSj4ZNJte83YNXbHPdy6rbqZq8x2l9NlLPxTKk14sGGPR06rU946TDS9UqxWrUYZqPPDRmV/5k5iyxkjmFXzYZxW6bKwAbWoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wGPuvX6vNS+wl9x8/bf8m/mz6Bdev1eal9hL7j5+2/5N/NkHr/AHLLs/xq8+Xm+wT5x5+YayU15qFJtL5kfEc9k1M8d2ePRG2TT1zcNXX7qnlafPMM9mbkxUYRwkkvcjF3o3aDQ0np7Y3tKCjO8pRlMykiw6THFccKZr805c0owhhEg63HwcDCGeQBHYhpftc5Jl2I7/A8zA1k9MTZNv8ARVu6hRxVppU2oLGTVxPxNNrDPop1T0Olr2z7uzqwU4qDmk17kfO++iqeo3VKKwqdaUcfJkJrsXTbmFn2nPN8fTP041hSa8i+eiG8LrZu9aFzRqNQuZKlKL7cljfErt6ipXlCvnHq5qWfkceO81tEpPPijJSay+mdjcxubOjXhJSVSCllfFHYz4fkywOgervWunVneOfj48OfkX/5cllxzNqRKkZa9F5qLueZufU4aPoF7qM5KPqKUprPwR6ax/MwT6X+6a+ibPt7WzrJTuZ+rqRT5w0eM1opSZe9PjnJkirVrqTuaruzeF5rFWUnGpLCT7LBbnln+hFOOE0nw+eSrs2Vy9uq3K64qRjrEPR2tpFXX9xWOkUotu6qqDa8j6EdNdtUdq7TstJpwhGdGCUnFdzVH0QdAo63u27vKscuzakn/M3Tj5Evt+KIjqlXd3zza/TBhE4AJNDIwieECGssA0iMN8eRMl7JC4wjEjpa1pttqum1rG8pqpTnFrDPn71e2pc7S3jc2lxHwxr1JTpfu+R9D85fBq76Z+hxq3dvrfg/I0vC2kcGuxROPqSe1Z5pl6fprFjD4OS2qzt7qjcU5Si6c1LK78MoT4Tj7gs+FrghIniVrmOqG/XQHeX+mWxqF9Jr1lHFLHnwZDb5yarehlrXq689D9rEvFPvwbVNFi02Trpypetxellmonl8mBvTa/Vnb/xKM9QZgX02v1Z2/wDEr7j1qPZLxpvlq05h9VfIlLlt9iIfVXyDyVufK719sEpeGLlz2Nr/AERNiUaOlvdFzQjL6THEPEs4aNXNDt1e7gsLKSzGvWjDHzPob0w0aGg7NstNhHChHP8AVHfoMUWvzKH3fPNccVhdC4WCPCiQTcRwrKPCiEkpFQMiGlnIxh+WSSmXv9xiRElGcZRmk0/J9jSr0qdjw25umOpWdF+qvZOpUcVwjdX/AKmKPSi0ajfdLtRvnSU7ihBOD80cmqxxfHy7dBmnHmj/AC0ZeG17iW8vGCilzTXiTUl7yptr5FfnsuUT25M45Mt+jBs3/SPe9K/u6XrLCkva480YjSTkl2y8G53og6EtL2NXqTh+MqVfEn8Dr0ePrujtzz+nimPyzdb0adCjChSiowhFRil7kcqSRT2ZUWCP8Kj58oaQwskgyGAABTLjg1+9LbYcdV2/HWdOoqN3Tl460sfso2CeP5njb1s4Xu1NStppP1lvOKz5ZRoz0i9Jhv02WcWSLQ+bEX3T+snhkv3s9HcmmrSNfutPT4hNs8/3pFcvXieF1x26qxK4+mO47nbG87C8pVfBbusnWWe6zyfQrbOrW+uaJb6latulWimmfM2ss03j6yXBvZ6MGsfT+m9jZybc7eHLZJaDJ36UHvGH++GWH2C7AEwr4AABCjzkkAMIAACGkSAGBhAGBwXttQu7epb3FOM6c4uMk1ng0+9JTpD/AKL1Z7j0Kk5WFSWJUksyTfmbjyPH3bpdtq23ryzuqUakZUZeFNdnjg59Rhrkq6tJqbYLxMeHzYXPbheYaw8s9feOkVdC3FdafVj4WqkpRT92TyHnPJXbRxPC50v1ViXu7B3Bebb3VZ6hbVXTh62PrsPGY55PoTsvXbXcm37bVrN5pVIpZ+OD5r1E/BLD7o3L9ELXvpGyKOhuTlK2Tly8kjt+WYt0oTd8EdMX+2dwQ+Ce6JpXQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD7AY+69fq81L7CX3Hz9t/yb+bPoF16/V5qX2EvuPn7b/k382Qev9yy7P8AGrfbJz6dThVvqNOosxlJZOA7Olf8TofvHFj90JXN7JfQ3pTShR6e6PTgsRhbxSX8i6l2LZ6YfoHpP2EfuLmLNj9sKRk90gAPbwJYAAES7Ed+CoGGOHW1KKen3MfJ0pL/ACPm/vO0VlurUKcXlSryf+Z9ItR/MLj7OX3Hzn6j/pfefbS+8jNxjtCc2af5W/6W9jPBFVYpyS9zJKan1JfIh4WWfw3e9ED9Ttp9rIzH5GHPRA/U3afayMxMs2D4qqLqvnseaNK/S31mrdb8r6TKeYUJKSj7jdGvLwUpTXksmgfpF3Ernq/qdaWeexy6+3FeHdtNOrLysDzIk8RbJeM57FNT6kvkQcLXLaz0K9PjQttSu4wcZVoLLfZ8mysexgj0RF//ABLP/lozuuEWLS9scKXrZ5zSnyIjl9yc9viMnU5AAAChlb7FOePiAXu8zBfpgepfT+unUj63KxHz7mdF72av+mhq1GlcW+lOf4ypT8SRy6yeMXd2bfHOeGsFFP1cc+4lLxciOUknzwS1xmLwV2VzjtDMvod3NaPVn6MpfinbyeP5G7Dzng029DfT4y6gPUXFtqjKOfLsbk85J7QfEqW6zH7iSPcwN6bX6s7f+JX3GeuM4MC+mz+rK3/iV9xvzz/CXJpflhpzD6q+RK78kQ+qvkSVq3ld6e2Hr7FSe/tBXk7yH3n0jtUo21KKXaEfuPm5sT9YGg/xkPvPpLbfkKf7i+4mdu9qs7xP/JEK1nzJAJNDgAAeZD7EgCFks3rPQlX6danShHLcO38y8y3OpH6HX32bNWb2S24Plr/t86dSg4alcU5YzGbXBwrhcHc3B+kN/wDas6a7lav5XfF7UJJ1KSf/ADI/efQjovaQtNjWSpL69KMn/Q+e6/K0vtI/efRHpL+g2nfYR+4kNuj+SG3r2wu7jhskiXYkmYVwABkAABS++TgvYRq2VanNcSi0zsP/AKHFcfm9T5Hm3eJZr5fPnrhb0rTqhqNCkvYRZfnxwi+evf619T+RYxWs3vldtN8VVNRey15s269DW8qVtKvLabTVKCx/U1Gn9U2v9Cv8z1H9xfedGh+SHJu3wy2SABPqmAoXDbQbXGAK8r3goYyORWMr3lOG0dO81PTbNP6Xe0aOO/jlgxM8eSImfDvAtLUeoW0rNvOuWU2ll+Gqi09U667UsqU6kZqt4ZYxCS5NU58dfMt1dNlt4hlh9hHsYKvfSV2tbUHV+g1548o9zypelZtddtFvWsnn91i/LZ+yz/8Aq2Kb44KXFSWJc57mu/8AtV7Yxn8CXxH+1Ztfw5Wi3vfBidThn7I0Oo/9WIfSwtoW3V+4hSp+Gm6KfbgxSmlwzIXXDfGl7+3E9a060qW0nFRaqd+DHj8iD1E1m/NVq0Nb1xRF/JJP+TNj/Ql1F1dx6nYc/iqCf+ZrizPvoOfp3rX8MvvNuh+SHPuvwtwlyuSSI9iSwQqYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYB9gMfdev1eal9hL7j5+2/5N/Nn0C69fq81L7CX3Hz9t/wAm/myD1/uWXZ/jVnZ0r/idD946x2dK/wCJ0P3jix+6Erl9kvoj0w/QPSfsI/cXMWz0w/QPSfsI/cXMWbH7YUjJ7pAAe3gAAAAAcGo/mFx9nL7j5z9R/wBL7z7aX3n0Y1H8wuPs5fcfOfqP+l959tL7yM3HxCa2b3WW8U1PqS+RUU1PqS+RDQs0+W73ogfqbtPtZGYmYd9ED9Tdp9rIzE/Is+n+KFF1Xz2cV3+bVP3T5/8AX3P+tfUl5Lk+gF3+bVP3T5/9fX/819SOHcPCS2f3SsX6y47kVfybK+zeCir+TZDR5WefDcv0RcraeP7iM7JZME+iK87Uz/cX/QzsuFlli0vshS9b80pwCMjxHU5EghSQ8QEvsUfAqb47HFXq06FGVatNQpxWXJ9kYmYhjiZlx391QsbSpc3NWNKnCLblJ4SNA+u27nvHe9a5cnKNrOVKDzw0Zg9JrrFQr2tXa+g1fG58Tq03xFo1mk225yfik+ZP3sh9bqIt/GFj2vRzWPUsjOFnAxhpZ9qTwkHxy3kyB0N6fXm+t0Uc0ZRsqcvFKs17OU+xH46Te3EJjNljFTqlsP6IW1paZst6jeUJQup1HhyWPZM7ps6ej6db6ZptGytoRhClBR4XfHmdxJ47ljw4+ivClZ8k5bzaUp5eTAvptfqzt/4lGe0sdjAnptfqzt/4lGM/sl60vyw05h9RfIkpp/UXyKit28rvT2w9fYn6wNB/jIfefSW2/IU/3F9x82tifrA0H+Mh959Jbb8hT/cX3Ezt3tVnePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83xy24Plr/t879wfpDf/AGrOmu53NwfpDf8A2rOmu5Wb+5d8XtRH8rS+0j959Eekv6Dad9hH7j53R/K0vtI/efRHpL+g2nfYR+4kdu9yG3vxC7pdiSJdiSYhXAAGQAAEP/ocVx+b1Pkcr/6HFcfm9T5HmfEs18vn917/AFr6n8ixi+evf619T+RYxWs3vldtN8UIn9U2v9Cv8z1H9xfeaoT+qbX+hX+Z6j+4vvN+h+SHJuvw2bJAAsCpqWueCCXyzzdxa1YaBptS/wBQrwpU6az7TxkxaYiOZIrM9od+c4wg5zfhiu7Zj/fnVzau1recpXdK8rQ70qU14kzX3rD191fVrqrp+2a07O3i3GUlypr3owTdVat1d1Lu4qSnXqPM3nuyMz66K9qpnSbVN46rs8bz9JHWdQ9YtvwqWSy1Fy5MW671D3hrSk9S1N1FLvjgtZNpYfmdnSdO1PV7hUNLsqt3JvGKayR85smSfKZrpcGGPDqyU5VHKVaq/E8v233KH4Y8Oq/5yMy7I9Hzc+5Lf1lzXlpq7+GpEzDtf0cNCsqUFq6pXkljxP3m2umy37tGTXafH2hp3RaqS8MM1H7kdu30zUq8W6Gn1pQ96ib42XRbp3aNSpaDSjPHLTPbs+nu1LSj6qhpdKMM5xg3xt8/lxzvMfUPnstH1lrL0y492PCStF1hvwrTLhLvzE+h8tkbbbTenU8r4Ey2Vtt4zp1Pv7jP9O/yRvU/h857q1ubWXguaE6Uv7Mlg4X5YM0+lfpllpW9JUrGiqUHBcIws/IjsuP07cJnT5/Xp1JZn30HP071r+GX3mAmZ99Bz9O9a/hl950aL5Ycm6fA3Cj2JIj2JLBCpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gH2Ax916/V5qX2EvuPn7b/AJN/Nn0C69fq81L7CX3Hz9t/yb+bIPX+5Zdn+NWdnSv+J0P3jrHZ0r/idD944sfuhK5fZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf9L7z7aX3n0Y1H8wuPs5fcfOfqP+l959tL7yM3HxCa2b3WW8U1PqS+RUU1PqS+RDQs0+W73ogfqbtPtZGYn5GHfRA/U3afayMxMs+n+KFF1Xz2cV5+bVP3T5/wDX1f8AzY1L5I+gF5+bVP3T5/8AX79bGpfJHDuHhJbP7pWPLuUVfybK33ZRV/Jsho8rPPhuV6In6J//APNf9DOz7IwV6InG08f3EZ07Fi0vshStb80pwHhLglduDpalqdhp0PHfXMKCx3k8HTMxHlyxEy7fYnHGWjGu7+su0NCoTnQ1G3va0O9OE+TAnUL0jtX1jNDQaFTTsLHrE8nNk1dKfbsw6HNl8Q2g3fvfb22bKpW1DUaEKsFxSlLEpGrfWDr9qW4lU03b0athbrMZSzxP4mHNf1/WdwXCra1fVLua7Ns83suOF7yMza21+0JvS7XTH/K/eUznOpXnXqzcqs3mcn5spbUMyb/kdrS9Ov8AVa6t9NtZ3VZvCUUZ06Rej5qWsyp6ruCUrWlB4dtUj9b4nNjw3yS782pxYK95Y36V9ONb3zrFKhbUKlKyypTucezheRvJ0+2dpWztCpadptvCniK9ZJL60vNnd2ptzSds6XHT9JtIW9JfW8Pmz13w8ImdPpa4o/yrGs11tRPH0qisIkLsDtcAYE9Nr9Wdv/Eoz2YE9Nr9Wdv/ABKNGo9kt+m+WrTmH1V8iSIfVXyJK1byu9PEPX2J+sDQf4yH3n0ltvyFP9xfcfNrYn6wNB/jIfefSW2/IU/3F9xNbd7VZ3j5YcgAJJDgAAAAAW51I/Q6++zZcZbnUj9Dr77NmvN8ctuD5a/7fO/cH6Q3/wBqzprudzcH6Q3/ANqzpruVm/uXfF7UR/K0vtI/efRHpL+g2nfYR+4+d0fytL7SP3n0R6S/oNp32EfuJHbvcht78Qu6XYkiXYkmIVwABkAABD/6HFcfm9T5HK/+hxXH5vU+R5nxLNfL5/de/wBa+p/IsYvnr3+tfU/kWMVrN75XbTfFCJ/VNr/Qr/MtR/cRqhP6ptf6Ff5nqP7i+836H5Icm6/DZskACfVN0Ne1K10fS6+o3dSMKNKPik2zSTrx1Yv956tW06xqypabSk4SSfFRGTPTA35XtoW+39OuH4Kyca8Yv7zV2MEoJZwQ+t1EzPTVYdr0ccepeERioRSXbyZLaXOcsN548kXP0x2lebx3Za6VQpyjRnL26uMqJHUrN54hNZLxjr1S9bpR0y1vfWqU4QpVLazz7ddx4RuR076Y7b2dZ0la2VN3cV7VXHd+89zZG27Ha+gW+mWdGMHCCVSSX1ml3Pcy+zJ3T6WuOOZVTWa++a0xE8QJYXCSx7kTkn5diEkmdkI7/apAL5gyyPsU+ZU+xT+0JPtpr6Yv6cy/ciYKfkZ29MX9OZfuRMEvuiu6v5JW/bPghLM++g5+netfwy+8wEzPvoOfp3rX8MvvPWi+WHndPgbhR7EkR7ElghUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD7AY+69fq81L7CX3Hz9t/yb+bPoF16/V5qX2EvuPn7b/k382Qev9yy7P8as7Olf8TofvHWOzpX/ABOh+8cWP3Qlcvsl9EemH6B6T9hH7i5i2emH6B6T9hH7i5izY/bCkZPdIAD28AAAAADg1H8wuPs5fcfOfqP+l959tL7z6Maj+YXH2cvuPnP1H/S+8+2l95Gbj4hNbN7rLeRTU+pL5FaKKn1JfIhoWafLd70QP1N2n2sjMT8jDvogfqbtPtZGYmWfT/FCi6r57OK7/Nqn7p8/+v362NS/kfQC7/Nqn7p8/wDr9+tjUv5HDuHhJ7N7pWO+5TPLjJJdyX3YXGWnkhlm4bOejz1A2ztXanq9Q1GlTq+DHgk0me/uT0l9L09uNlpyvF5OLNQJxg0nNchTpR4UsN/BnbTV3rXiEXk2zFe/VMs7bq9I/XtWjKOl0qunNrCaZjTWOoG89Xc3qGuV6sH5Nnkaboesam0tPsKlxns0i6dE6S791KvCNTQbilRf7bR4m2XJPZsjHpsMcTwsWoo1Kkq025VJctt9yPHHxKOeX2Nidr+jFe3nhrajqk7fzcXHsZf2f0L2lotKKvrOjfzj2lKJspo8l57tOTc8OOOK+WnOhbI3Zrbi9N0evXpyf14rJmXZHo1ahfqje6tqEraPeVCcf8jajRtE0rR6XqtNs6dvH3RR6HdHbi0FY7yi8+7Zb9q9lk7J6ZbV2vSpytNMo/SoL8sly2XslhYXZDjzeCqLXkjupjrTwjb5LXnm0pSSDSAPbwAAAYE9Nr9Wdv8AxKM9mBPTa/Vnb/xKNGo9kt+m+WrTmH1V8iSIfVXyJK1byu9PEPX2J+sDQf4yH3n0ltvyFP8AcX3Hza2J+sDQf4yH3n0ltvyFP9xfcTW3e1Wd4+WHIACSQ4AAAAAFudSP0Ovvs2XGW51I/Q6++zZrzfHLbg+Wv+3zv3B+kN/9qzprudzcH6Q3/wBqzpruVm/uXfF7UR/K0vtI/efRHpL+g2nfYR+4+d0fytL7SP3n0R6S/oNp32EfuJHbvcht78Qu6XYkiXYkmIVwABkAABD/AOhxXH5vU+Ryv/ocVx+b1PkeZ8SzXy+f3Xv9a+p/IsYvnr3+tfU/kWMVrN75XbTfFCJ/VNrvQs/MtR/cRqjP6ptf6Ff5nqP7i+836H5Icm6/DZsgk+OTg1O6hY2NW7n9WnFyZ2OxbXU+vOjsPVa0OHGg2icvPESqtI5tEND+reqXGq9RNXrVasp01XfgT7ItV89zua5UlW1q6qzeZSm22dMrWWebyvGnrFccQN4NtfQ22xGy0K81G7pKVWpUUqcmuyNR6v1Vx+0vvPoP0PsI2XT7S5xgo+uoRm/6HZoKc35lGbvl6cfTC+v2iUveRnD5Kic+1YRHsS1lAGQAABlP7RUyn9oT4Ptpr6Yv6cy/ciYKl3RnX0xf05l+5EwVLuiu6v5JW/bPghLM++g5+netfwy+8wEzPvoOfp3rX8MvvPWi+WHndPgbhR7EkR7Ek/CpAAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2AfYDH3Xr9XmpfYS+4+ftv+TfzZ9AuvX6vNS+wl9x8/bf8AJv5sg9f7ll2f41Z2dK/4nQ/eOsdnSv8AidD944sfuhK5fZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf8AS+8+2l959GNR/MLj7OX3Hzn6j/pfefbS+8jNx8Qmtm91lvooqfUl8itFFT6kvkQ0LNPlu96IH6m7T7WRmJ+Rh30QP1N2n2sjMT8iz6f4qqLqvns4rz82qfunz/6/L/5r6k/kfQOtHx05Q/tLGTQX0kLSVl1f1Ok23HybXc4twjtykdntEX4Y+b5bKZfVclx8Cc+YaXk85IVaJZ06BdJtI3nafTrm+XjglKVJxzg2D0Po1smwglcaRbXUvfKJiL0JdXVa61bT5xUPVQSi/wC0zaSJO6XFS1InhU9fnyRlmOXh6btDbenYVjpFvQx28MT2qdKNKKhCKjFeSK8vOCTtilY8QjpvafMqXlLhEpcEg9R2eVPhYw8fEqAEJccoL5EgwIWfMkAyAAAGBPTa/Vnb/wASjPZgT02v1Z2/8SjRqPZLfpvlq05h9VfIkiH1V8iStW8rvTxD19ifrA0H+Mh959Jbb8hT/cX3Hza2J+sDQf4yH3n0ltvyFP8AcX3E1t3tVnePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83xy24Plr/ALfO/cH6Q3/2rOmu53NwfpDf/as6a7lZv7l3xe1EfytL7SP3n0R6S/oNp32EfuPndH8rS+0j959Eekv6Dad9hH7iR273Ibe/ELul2JIl2JJiFcAAZAAAQ/8AocVx+b1Pkcr/AOhxXH5vU+R5nxLNfL5/de/1r6n8ixi+evf619T+RYxWs3vldtN8UIn9U2v9Cv8AM9R/cX3mqE/qm1/oV/meo/uL7zfofkhybr8NmyLfBZnWlVX0v1z1KbqfR34fmXljOC3epVCdzsjVKFNe1Oi0sE3kj+Mqtin+cPnJU9Z66frc+s8Tzkg7u4aE7bXruhPiVOeGjpFav7pXjFP8IUVfqx/ej959F+k1SFTpzoXgkn4bSCfzwfOmSyvk0/8AM3v9G7XbfWNiW9KjJP6LBU5Je8kNvt/LpQ+845msWZQfKK1yih55fkVR7dyaVuEgAMgAAMp/aKmU/tCfB9tNfTF/TmX7kTBUu6M6+mL+nMv3ImCpd0V3V/JK37Z8EJZn30HP071r+GX3mAmZ99Bz9O9a/hl9560Xyw87p8DcKPYkiPYkn4VIABkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD8wMfdev1eal9hL7j5+2/5N/Nn0C69fq81L7CX3Hz9t/yb+bIPX+5Zdn+NWdnSv+J0P3jrHZ0r/idD944sfuhK5vZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf9L7z7aX3n0Y1H8wuPs5fcfOfqP+l979tL7yM3HxCa2b3WW+iip9SXyKimp9SXyIaFmny3e9ED9Tdp9rIzEzDvogfqctF/5sjMTLPp/ihRdV89kp+Rqd6Ze1fodxR3FRpuc7qooyaXY2wfDLX6mbXt917WurCpSjUq+rl6nK/axweNTj66TEeXvR5vSyxb6fOnCxx5DHHi7Hqbv0G+2tuG40fUacqdWnJ913R5fLb9xXbVms8SuePJF45hevRfd1XaW87Os5unaV6qVeS8om/2ianaavplHULKoqtCtHMZLzPmXKLa74M8+jz1kqbbrU9D1qp4rGWIxlJ/U+KO/RamKT0yh900U3/nX6bkNERz5nT0nVLLVbGle2FeFWhVj4otPujt+ImYtExzCuTExPEqgRkZ/oemOUgjxfAN8gSCMv3BPKAkAAAAAMCem1+rO3/iUZ7MCem1+rO3/iUaNR7Jb9N8tWnMPqr5EkQ+ovkSVq3ld6eIevsT9YGg/wAZD7z6S235Cn+4vuPm1sT9YGg/xkPvPpLbfkKf7i+4mtu9qs7x8sOQAEkhwAAAAALc6kfodffZsuMtzqR+h199mzVm9ktuD5a/7fO/cH6Q3/2rOmu53NwfpDqH2rOmu5Wr+5d8XtRH8rS+0j959Eekv6Dad9hH7j53L8rS+0j959Eekv6Dad9hH7iR273Ibe/bC7pdiR3QJiFcAAZAAAQ/+hxXH5vU+Ryvv/I47lYt6nyPM+JZr5fP3r3+tfU/kWMXz17/AFr6n8ixitZvfK7ab4oRP6ptd6Fn5lqP7iNUZ/VNr/Qr/M9R/cX3m/Q/JDk3X4bNkF2RRXp069KVKovFCaw0zlGET894VPu+fnXvbtzoXUTUasqThQuazdPjCwWE+xun6UXTuO6Nvfhe0TV1Ywcoxivrml1WlVt6s6FzBwrQeJR9zK9q8M0ut+26mMuKI+4Uy8vIzz6I+/KOgarU23dzSje1PFGT8jAz4WWclnXr2l1Tureo6VeDThOL5NWHJOO3Lo1OCM1JrL6cQqRqxU4NSg+U15lcTXzoH1w03VNMpaLuKtG2vaSVOnznxr3sz/QrUq1KNWlUjOEllNPyLDhzVyV5hTs+C2G3FocoIT4GWbmlIIzwFL38ASyn9oly47EZWVjuYk+2mvpi/pzL9yJgqXdGdvTEWd9Nf3ImCX5Fe1fySt+2/BCWZ99Bz9O9a/hl95gNmfPQc/TvWv4ZfeetF8sPO6fA3Cj2JIj2JJ+FSAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wJY+69fq81L7CX3Hz8t/wAm/mz6B9e+OnepZ/5EvuPn5Q/J/wA2Qev9yy7PP/G5Ds6V/wATofvHWOzpX/E6H7xxY/dCVyz/AAl9EemH6B6T9hH7i5i2emH6B6T9hH7i5izY/bCkZPdIwmgQlhnt4SAAAAA4NR/MLj7OX3Hzm6jv/wDmF6v/ADZP/M+jOo/mFx9nL7j5zdR8f6YXvv8AWy+8i9x8Qmtm91v+lvlNT6kvkVPBTU/Jy+RDwsszHLd70QP1OWj/APNkZi8zDvogfqbtPtZGYmWfT/FVRtV81hhe/JHdjjHxNstEdmJ+u/Sew3zpc7q1pRp6nSTlCUUk6j9zZpZuXQtW21qlXTdYtpUbiDw1jj+p9LFwseZaG/unugbxs50b62p06kk060Yrxf1I/U6OMnevlK6LcbYf428Pnes+b4JeG0/d2Znjf/o463pdSrPbXiu7ePOZyw8GHdf21rmgVPU6lY1IyTx7MGyJvgvRYMWrxZY7SuPYPVTc+zaila3FW7pRx4aVSTcV/I2C2V6SWi3lGEtyulYya9pR8jUNZXLhKMvc44IxCXtSUW37zZj1OTG1ZtDhzPoRpXVXZWp01UtNVhOD83wXDb7k0evTVSnd03F++SPm7Tu7qjHwUbqpSXkoywdiOua7GHq4a1eRS7Lxs6o3CyPts1PqX0rpXVGrBVIVabTWV7SKvWU859ZT/wASPmx/pNuhJf8A8jv1j/zGS907pfE9yX/w/Gs2xr44aJ2i/Pl9J1WpeVWn/iK4PPZpr3o+aq3Tu11aX/x7U5pTSXhmz6AdKKtevsrT6txUqTnKhFtz79jowaj1J44cmp0c4I5mV2AA63EAAAYE9Nr9Wdv/ABKM9mBPTa/Vnb/xKNGo9kt+m+WrTmH1F8iSmD9hfIqK3byu1JjiHr7E/WBoP8ZD7z6S235Cn+4vuPm1sR//ADA0H+Mh959Jbb8hT/cX3Ezt/tVrePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83sn/Tbg+Sv+4fO/cH6Q6h9qzprudzcH6Q3/ANqzpJ8lZv7l2xz/ABFzVpfaR+8+iPSX9BtO+wj9x87lxVpfax+8+iPSX9BtP+wj9xI7d7kPvXthd0uxJD7EkxCuAAMgAAI8/wCRxXH5vU+Ryvv/ACOK4/N6nyPM+JZr5fP7r3+tfU/kWMXz18/WvqfyLGK1m98rtpvihE/qm13oV/mWo/uL7zVCf1e5tf6Ff5nqP7i+836H5Icm6/DZsmACwQqbjr04VYOnVhGcJLDi1lM1X9IPodcQvLjce26cq0ajdSvT8ofI2qy8t+RTUp061KVOpFThLhxa4ZozYa5a8S36fUXwW6qvmNWp1KFedvcU5U6tN4lFrzKPPLeMG8fVLoht3dsJ3NCCs7pLKVKKXifxNcN69C96aA517Sz9fZQ5cs8/0IXLpL08LNp9yxZfPaWLaVSpQrxr0JulVXaUe5k7px1s3PtOcaFSUtQo571pN4Rja+sryyrOhcWtaNRd/YZ1m32lGUX8Vg00vfHPZ1ZceLNHEt0doekVtK/tl+G7qFnWf7KRf2m9Stn6hbK4tdTjOm33Png1B91HJ2qN/fUIqNC9q08eSkdtNwyR2lGZNnxT3iX0ihr2lTUfDeUva7e0uTvxrUpYaq08Pt7SPmstf3BlZ1u8TXKxUfByPc+6k01uPUOO2arN0bh+XNbaJ/tl9J/W0/KrT/xIh1qWE1Up/wCJHzZlufdMnl7j1D/8j/8Acf6U7rkk3uPUOO34xmf6hV4/pGT8sw+mHiW9nKLjJeFdnkwT5I7F5fahfVXW1C+rXdR+dSWTrt+/GSMz3678wndJi9HH0yqkZ89B39O9a/hl95gLJn30HOd961/DL7zdovlhzbp8Etwo9iSI9iSfVMABkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwH2AtrqLt+W5NsXWmQfNam4/1NbY+jJeRjj1k85/tG2vD5T7BvzOe+mpknmXTh1eTDHFWpv+zNeL/tJ/1Oaw9Gu6oXtOu6k/ZeeWbWchNmuNFj5bZ3LPMcS8zaumvSdvWenPvQpqJ6pS2/IqXY6qxxHDhm3VPIAD0AAAB8gAcdzD1tvUp/2ouP9TWPdXo7XWq63XvYzmlUm5cP3m0BTn4mnLhrl9zfh1F8HerUz/Znu/8AmT/qRL0ZbuSa9ZP/ABG2ucPzDa7Gn9ljdP8AU86yOi20amx9j0NCqycpU5OWfmXq/gT8wuVzwdNaxWIhw2tNp6pTHsSQu3BJ7eTCGOAAIklJYfKfkeXqGgaLfRautMtqrfnKmmz1Q+55msT9MxaY8SxPuboXtDWqkpyjK2beX6uKLL1P0XNsuSna393nzWTYrlvtwH3NNtPS306KavLXxLVjVPRhpRcZWVxVk/NOR0/9ma87+OefmbZ594T58zX+yxt39Tzw1Po+jNcSl+OqzS+Ej3bD0W9DqODvdQuof2vCzZPLyS1xyxGjxxLFtxzz9sV7Q6G7R29cU60IO7cOyrRTTMn2tGlb0Y0benGnTgsKMVwkVoqj2OimOtPEOW+W1/dKQFnPINjWAACJdjHnXjYlTf21aWkU5NOFVVOPgZDl2I8855PF6xaOJeqXmluqGpf+zLdxSSqT/nIl+jNeL/tJ/wCI2zeUMtdzmnRY3bG554hq5tr0cbnTdx6fqTnP/dq8ajTl7nk2hpxcKcI+6KRVlsJcYN2PDXF7XNmz3zTzZUADc0gAAAABjnJ5m6dPeq6JcWK71Y4R6YayjFoiY4lmJms8w1S1L0bLq51K5uvHNetqOS9o6/8AszXj71J/4jbTnyIWcnJOjxzLtjcs8RxDU2Ho0XaqQl62fsyT+t7jZnZukvRdAttPk3mlTUf6Htf1IecfE249PTFPMNObV5M8cXO/HJUU8cJoqN7nAAAAAFMl5lFWKlSlDP1lg5Hw+SF3fYxJy1u6j9Arnce77rWIzklWx2Zbq9Ga7x+Unn5m2aJXmcs6PHM8y7qbjmrHTDUuXoy3bWPWT/xIzH0I6c1NhUbqFSTfropcv3GUOSpHrHpaUnmHjLrsuavTYAB0uQGECG/cYB5KK1KnWp+CtCM4vvGSyjk8iJf5CYFu6zsvbeqUJU6+lWsXL9tU1kx3r3o8bP1WE4yq1qDk85ppLBmXj3kN9zVbDS3020z5K+Ja33Xot7ejPFvqF24/Fnh3noxzhWata1SVP3tm1qfxYyaZ0eOZdMbjnr9tTP8AZmu/+ZP+pP8AszXn/Mn/AFNsssnkfscbP9TztTP9ma87esn/AIh/szXn/Mn/AFNs+RyP2WJn+p52pn+zNef8yf8AVD/ZmvP+ZP8AxI2z5Iffux+xxsf1TO1MfozXf/Mnj5mSegPSSt0+16+v6k5yVxTUOXnBmrPHcJvOD3XS0pPMNeXXZctemypAA6IcgADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gAKeAO3KD5QYMAj5EGP+jn/KSrOEQu+PeRgcirKxkZWCn5dyZdviBOUMop7lpb36gaBs+5o2+sVZRnWx4FHHJi14rHMvVazaey78oZR17GvTvLOjd0n+LrQU4P4Psc2OOTMTyxPbyqyguOxT2+QT5yzLCc88iTRHmUXFSNChOvN4jTi5S+SPMzx9ERz9uR57kFobS6h7e3RrFfStLqylcUc+LPbgu/PuRit4t4e5rNfKpNJDxIpZC47Hrn/Dx/2ryhlFAHJyr8SCaZSl78k4wwJT7lPAkQORUx28xHh8nE7u19b6tV6XrP7PiWTEzEERM+HK+fMLuRgnHGWZ5Bv+hKawU45+BK88dgy6Oqazp+mOKvK8afi7ZZ3aNWFWnGpB5jJZT+BgT0qqteFtaOhWnTl6+n9V4zyZo2nKUttaZ4nl/RaeW/P2Uaa5Jm/DdbHEUiz1coZRHlwRjy8zc0JlLgPnlEJe8wh1h6n7j2tviy0fTYUHbVq0IScllpN8mrJkrjjmzdiw2y24qzgufPsTnPxOC1qettqNSXedOMn82jl5xybPpp+zu8k9nwR2DMivKIyi2N/b20bZdrQuNZnKMK8vDDwrzPV29q1rruj0NUsW3b11mDfc8xeOeHqazFep6XiQysZKWvcM4PTCrKCkmQ0E03zwxyJ8SGSJN/yIXwHdjn/KckPvlkSlGCcqklGK7tvCOOhcW9wpO3rU6qTw/BJPBjmCIlzL4MhcBLIx7jPIZWCrxFLRKfPIgl513rmnWuoxsK1eMbiSyot+R6Skmk0+GsmufUitcL0ibSnGtONP6PH2VLjubDWmXaUW/7C+404ss2tMT9OjNi6KVtH25soNpFK5ROMLg3ctCfPPkQ8EZaHDHLCcE5Kccc9wuB/wBH/aU0uxGeS3t77v0jZ9lTu9XnKNOb4x3OS13VplztP/SenJ/QPB48+eDx6kcvcUtxy99SROS09i780Pecar0epKSo/X8RjTSeqm5LrrFd7Uq0qH0Glceri0ucZPM56w9xhtPLO3iQckilcDu8m2J5alWU1ghtYwiMYC4fKDHlK95DayPkMCThPHfI7+ZDTC4XJkVZ94yilcB8mBVlYGUilcclNWpTpR8dapGnH3yeEY57sw5M8kSwcdKrTqw8VGpGcX5xeUV9lhozEsccD55Ko9iklPC5DKoAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMADo6xfUdK0yvqNz4nSoQc5474RYdj1l2leWtavSnUSpLLjLiT+SLs3+n/odqeFl+okaxej/tGy3VvDVp37m42kvEoqWEziz5clZ4o7dNhxWrNsn0zhtnrNtLXtS+gW8qtCrnH45eFFO5etG0tB1eOm3frqk3Lw+OnzH+phv0mdm6btm+0ivo/rKFW7k1NxeO2PcXhcdNtBfRmWqVYVKl9O18bqSeX4jTGfPzMfcOmdLpuK2+rM4aHqtprGnUr6yqRnSqx8UcPOCyNz9YNs7f1CpZXNG6q1ab8M3ThlJlkeiHqN3cWWrWFeq5wtZKME3nCyZB1na+zLG4vLvUK1CFW5zKoqs1n+WTd617YuurmnBjpmmlo5epsfe+jbutZ19NqNeF8wm/a/oeb1H6n6FsW8t7TVqF1VqV1mPqoZRgLppe0tM68LTtKuHKyuLh8Rfs9+DZrcO19I12qq+o28asqa4yvIzTLe1e3ljLix0ycT4Y1q+kZsmlKEaltfw8WEvFDB4nVnXem2vysNW3FC+Tkouh6ttZy+MlodR9E0vdPVPT9ubct0qEeLiajwpJnL6Sek0dFtNI0+ml+Jp04t/JnL6uW8zFvDt9DT0iJr5lsDc7k0nbOx7XV6yqfg+NGCppLMsY4yeBPrPtL8Fyv4SqzhHvBLMjzeo+F0KtU+f91pv/Ix56NOw9M3Dpd3q+oudSUKzpqPi9nHyNs5cscVo58eHDMTbIzJsTqltreF39E02dSnV/s1eGXbrGp2ulWU7y8qwp0oJtuTxk1a35pVvsTrjZUNEc6dOtTjJxzxlnv+k5uK6u6+mbSp1JKFf1cp+DvzgRqbRExPmHqdHSbVmvtlf1l132bdajUsqSuFKnnM2sRePiezt/qRtzdle80uy9a3GhJ1G+3hxz/1LRrdGNuQ6ftKnNXEbb1zkny34cmPvRlSjqOswXaFOpBN+5ZRrtqM1ZiLeJbK6XT3pa1PML36OPp9T6i39Da6vI6j4ZOq6rbi+ecF+bh6n7d0HcL0O/dSNysZkvq8mEvR2/XTqb/8uf3nT9JCjO56k0bSk/DOvONNvOD3GW1K/wAWn0qZMkRbwzvpfVLbepazdaXaSnUrW1P1lSS5WDxtQ657SsrpUKlveP2seOMPZX8yvpf0n0PbemzupKc7y7peGvNvyaOrvbbexdJ2pfWcri3VVUZeFOovHnBmcmeKdUsxi0s5OmImWR9ta7Ybg0ynqGnVVOnUWUs8o7uo3dOysat5VTcKUXKSS54Nc/RG1SvPXtX0lVXUtaEM0uc+ZsfXowuLedGoswmsNHRivOSvP25M2OuO/H0svZvU7b26tYudL05Vo17b66qLB2uovUDRNiULarrCqtXDxBQWWYDs5f6LekFcWlOMoUby5UYJLvye36RVda7vvbuifXUa3haXY5/3Num35h2fs6ResT4mGeNI1+y1PbtHXaTdO1qw8a8fDSLKuutO0rbWvwXP17qeLw+sS9hfzLY656rW2v0/s9uWtSNF3NLwZ7YLe/0Q2oui07v8IWz1apbKTl65eLxf1M2z37dLxj0+LvN/+mdNe3Zpuk7XqbhqeOtaxh4sUuZNGq22up1Kh1Prbi1CV7U06VdzpUYttqLfmjKfo06lLcG07/Rb9q4pWcVT59pPuY26eaNY3fXPULGrRjKhSu5RjBrjGTVlvktMTDdp6YaRaLNiafUnRJbLut2To3FOxt8OalHEuT0Ng710neekT1PSVUVGHfxrktbrzYW2n9G9Yo21JQgkuIr4o8P0VVjYN0044a48PyZ0Vy39WKT+HPODHOGckfnhd22Oqu3Nxbnr7esY11eUajpy8S4yu5fvbsao9DljrjqfGP8Ae6n3m1svM96fJbJEzLXq8NcNqxX7YA9LDLtbSKXLrU/vM17S/RrS/wCEp/8ApRhT0sX/ALpar/zqf3matpZ/0Z0zP/haf3IxT5GMnxQ4d5bl0/aujz1XUlN0Id/D3Orsfe2j7w25V13SvWfRabkn41h8dy2PSN/VzcfNlvei5+p68x/zKn3GJzW9WafT1TBWdPXJ9zK89odUdu7m3XX23YRrq8oRcpeNcYRg70k/xfVLTqs+IRuKcm/dyjn6BRx171J4S/FT+9nF6TlFXPUWytpY8FarCEucd3g5c2S2TD1T55SGnw1w6npjxwyxqfWfaOh1bawuXWqT9VBesprMM495fu3NdsNe0inqdhUUqM1x7zGmr9Jds0entdeqqSqUrV1Yyk8vPhLU9EzULmpTutLqVHKhSclFN/Fm+mXLExF/w5MmHBNJtj+pZH3h1d21tjUalhfUbqpVp/W9VDKR7Oxd+aHvCj49LqOMksuE+6Olr+2dmRvbjUNXrW8K1xHwz9bNJ/5mAdq3dtoPXK4tdu1m9PqzjGOJ5i+ecGL58lLRE+JZx6bFlpM1jvDLfpGT2bCx0xbwjcypTqeGiqL8/iXv02jpcNm2MNG8f0BQ/E+PvgxF6YyUtK2/nyuMmUukD/8Al9pmFher7HvHbnUTDXlpEaSLKOpXUTQ9gqyesxrNXcnGDprOPme/pGt2ep6DR1q3f+61oeOLfuMZ+lBoK1jZk7jDbtIOaPO2XuBQ9HmTjVSqWlo1lPnzFs1q3tE/RXT1tjpMeZ8r+2t1G0DcevXujWMqiubOXhn4lhN/AdROo2gbHqW1PWfWuVz+TVNZNY+jGr3Fl1IsaleNSK1WtmMscMvrre47m6s6BpEX4owm0/caY1dppzPl0W0ERl6Y8M53W7tIttr09w16vq7SpT9ZGMniTXyLU0brRtPU9UhYU43FGc3iM6ixFmJuplzS1zfmg7Oq3X0ewtvxVZ+Lwxwvee91o2ltez6dyvdJ1K0+l6fCMafq60fE+V7vMzOpyT3ie0MRpMUcRaO8rz67dQLHb22naeGvO4vIeKjUpLhfzMUdAOqOm7XstQt9bjf3Ne7uPHBxTnhPyZcNleW+5+h1W6voxqVrOlGCk1lo4fRQ2/puraFqta+oQqunc+GDcefI8RfLfJEx4bJx4ceG1beYZU3n1U27tOjZVdTjXSvIRnTUVyk+x7ut7q03SdrR3Jc+N2cqaqLC5w1kwJ6W1OFLUdNowXsw8GF7uUZC6lLPQi3T/wDDU/uN9c9+bRP05rabHFaTH9y8One99H31pNXUtH9YqNKo6cvGsPKLn8zCHogNPYd74Vj/AHqWTOCOjT3m9ItLl1eOMeW1K+Ia4dSuPSOtG/O2j95sTZc2dH9xfca7dSf/AKj7T+Gj95sTZcWdD9xGnT/LZ0av4aLG3P1X23t3d1PbOoRrq8qNKLS9nnsXbresWmkaNPVLpv1EKfrH78Yya++lDoittwabuPHhf0qnFyx8S4+u+5fD0n0+vQmnK58NJqL5eYnj9xaOrn6bP2tLTTp+/LJOw976NvTTvp2kyn6tSccT75TPK1rqrtvSd4R2tcRryv5SUfZjmOWYe9F7Uq9hq99o1eMoTo0XWw+O/JO2rFbr9IHULtx8UaCU0+/Zr3HmuqtMR+ZZto61tb8QzDvHqlt/a967O+pXFWrFJtU45wmdrYvUbb+75Tp6dOdOcFlwq8Mp17a+0/wlV1bVatGnWqwUZqpNJPHzNctRv7HROtttS27XzbV7mMZeGfGMr3Hq2bJW3Ez2eaYMN6TMRPLNvpCrZz0O1nvH6V9Hg26aoNp/5HPo9bbMuijrW0a/+j/0Z5i37fg8y1/S152hat98P7jm0D/6Xai//wBKR5tbm0vNY4pH+3e9HdbHdC7q7NjdpT5q+vbeflkxFS1S20n0gNW1C6f4qlc+Jpd+5fXog/8ACbvt28vmY4r6HT1z0ib21uJNW8rrFRJ8tZNd5maxw34umMk9XhsPtDq9tbcury0uzdWnWjLwr1nCbLu3Zr9jtrQLnW9Qcna20fFPwLLwa1dddsWXT/cej6toiqUoKXiqPPyMndRr96n6PNfUJvLr2sZvJtx5r9Mxby05sGLqiaeJXn0/3zo299PqX2jes9VT+t41g8vQOq229b3VX21Zxr/TqNR05eKPs5XxLI9EzK2hcvHeKwWN0kUf9fGp4X/e5Hv1rdnj0ac2/wANrZZUXJvsuSwtG6sbZ1XeUtrW3r1fqTj7SwuC/GsqS9+Uav7rs6e0+vtjdxj6tV8yk155PWbLbHES86bBXLMx9s+783ppGzdLeo6s6jpqSjiCy+Tvbb3BY6/pEdSsW3QlHxc9+2TAXpP6rWvnZ6PbPx/SKKq+Fcnu+jpr8V0zv5XEn4qDlT58sLBqjVT6kV+m+dFxh6/tfe2+qm3Ne3hU2vZKs72Cbba9njvyVb26o7b2peqyvZVLis1lxo+1gwR0mf4LWt7xkvFONarSjNeWc+Z7HQjQtB193+5twajQ+k1K06cYVqq4T+DPFdVktHH22ZNHipPV5qzjsre+i7ttvW6bUaf9ib9r+hiT0ouoFK3so7YsFdUtRjUU5VI5jHw/MteFxZ7F66Rt9GvYVrOtTTxCeY5l8i7vSxsLN7Js9XVBfSqlWKc0ucMWy5L45/LFMOHHmjn2qeifVjRbTbNPSLmlf1bmlmc5yi2v6mRdk9UNu7u3FX0LTFWV1Rh45+OPGC0ejO3tNh0vqXqoQdd05e14Vxx//ZY/o1+H/XNrPHKpSXBnFkyxxEsZ8eG3Vav0zp1H33o+w9Pt73WY1ZU69RU4erWXk9ja2t2m4tHparY+L1FX6vi7mHPTFUXtPSlJZ/3teRf/AENWOnVh8jfTLac3R9Oe2CsaeMv2voEeQR1uPlIADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2AA8Df0nHZ2qPzVCX3GCfRI/Srcny/wCqM9b5hOe09SjTpupJ0JYiu74MHeinp+o2m6NyVLzTri1pz/JupBrxc+RxZY/nDrxT/wAVlfpgfne2vtJfei/67cehsZeStEyx/S2sdQvLnbkrGxr3ShUl4vVxz4eV3L8r29xLojG39RUVf6J4fV49rJq4n1MjpmY9LF/v/wDWKfRe1KOj6Zu7Uqi9ijNt/wBTp7P0q/6vbr1O+1i8qfg20q4jCnJptPJ6fo37cv7zSd2aZqFjXtI3MsR9bFpS5PF2vPdXS/cup6Xa6bcXNC8qPw1IU8xWPiaO8Yo6vDpmec9px+Xl7M0aw0P0h7CxsPWepp1XFeN5eEzZDqrueO1dn3moRknXjxCCfLya8bK0fcq656bq2pWFd0rio6nrPA8Q+DPX6/7g1vUt4W1vZaLf1rG2bjV8NNtSa9x7reK1n/LTbFbJljn6X/6Pezp2dldbj1OCld6jU9fSbXMUyyfS/eNTsOVz4F/mVad1j3DZWdtZ0tsamoUvDTWKL7HH6TFvqus0dGu7XTLqvOtSpymoQbcW35nqt62pxDzfFemXqt9r/wCo/wCom2/haf8A6Tx/Q7knsTUP4ts97qLaXc+iNvbUrWrUrq2pp04x9rKXuPL9EiyvLLY9/RvbKtazd22o1Y4bWDZWJ64c9p/4p/3/APqxPSDbfXnSs/8AJgdfrn4rTq/ot7Ui/VOhTivdng9Pr/p+pXHXDS7i1025r0o0YeKrCL8K/mXh122Fd7i21ZalpsWtQtqcJcrL4RotSeu8u2l69GOJ/wAsn3tRPZlWomsOxbXP901w9G151nX/AJVv+py6bvXqFqG3rjQY2Vxb1rek1OrUpYTilzyzg9GJSnqGrxUW6jpVPFhd5YeTxlydd6xDZhwTixXmZ8uT0dcf66tU9/qpfecfpApz6t6aovwt3NPn+Z6PQDTNSt+smqXVxptzb0JU5JTnBqL5ODrzp2q1+rWm1bXTLivRVzBupCLcVybuOzj5/wCRmTqput7T2M7uGfW1KHhpv44ML7J2A957TvN5bmua9WVWnKVOMKjSTXvRmfqxtWpunY30Oml62lRUop+/BhDaWuby0TbVfZENMuklCUI1PU5jyec3mOpt0nPTPRxy7vok0KVrv3X7ah+ThTxF/wAzZ9Pg1r9FbRtZ0nfmux1W0rU26axUlDEZcmyeHhYa+J1aXtVx63mcndrp6R1jDQt6be3FCC5ufFUaPD2BXqb46s1dSlF1KVpVU488L/8AcGUfSV0qhfbLq3NVxU7aDlDPvLT9EDb9a00+81W4pezdRTpya78nLNJjPER4l31yROlm0+YdL0yLedaroUlJxp5fix5FW0uiOm6xtmx1CVe6zXp+LCrPw/0Mp9ZdkU947Zq28Ir6XCD9TJvhMxBtrfO99jWMNuahpV1eRtl6ujOlRbWEzOWlYv8Aya9PkyTi4xsudK+nlnsO0u6do2/pHMsv4GD+muF6QmpJNfnsvvNidhavf63oyu7+3nRnKH1ZRwzXLfOh7j2H1RlufTrGvdUq9Z1GqMPE+TZkiKxEx4asPVe1onyzf6Ref9UesfurP9S1/RV9Wtg3bg+3f3dmXRc07vqH0xuLO5t521a5ppuNRYZg/Zd1vjZNS/2xY2VdxqzajVVLMUjze3TljJ9cNmKnVhnFz35djoco/wCuzUnn2vpk/wCmWbVy8zVvoVomt6d1SdxqljcKVxUlOVXwYiss2la7m3ReyWrcuPUrx+Gv3pY/mtp9tD7zNm08vbWmZ/8AC0//AEown6WP5ra/bQ+8zbtT9G9M/hKf/pR6p8jRk+OFjekWm+nNxhNlvei61/qdvMdlUqfcZK6h6F/pBtq40/GXKLa+eDWzaF7vrZdK82paWNxK2qzniapcYf8AI1ZpnHmm7q00epp6448xL0vR/al141JxaaVKZT6SMfF1U0rHlc03/mjl9HLQdd0vrHe1tUs68Y1Ldy9a4NRbZy+kVpeq3fU7TKtpp1zXpxuabc4QbSWV5miKz6H/AG65tWNXz/hn/cP6B3n8A/8A0mvHox3P0CnrV/nPqKdSol8smxW4Kc5bHu6cYSlN2LSily34exr96N2ianUpa1Y3mn3ForinUpxlUi13b+B054nmOPwj9PMdMxP5dHadnedZN6XVbU7qorCi8+CnUcfM8q00S02515ejaf4/o1CpDHjl4pP+Z3dAtt2dJt3XlChY17undZhTnSg5JNvuzg03TdzVurtvr2rWNepK4rRzOMHiPPmcUxz08+UpX+M2mOOnhfPpif8ACdA+3/8AYyj0j42Bpq/uGNfS5sb+80rQY2NjXunGv7Spxz4exk3pNQq0NhabTrU505xprMZLDR3Y4n9zz/hGZpidHEf5c/UnT/wnsrVLNL2qlFxXwNVdB1atZaDq+zvWL1ri6cIvnJuXWpQrUZ0prMZLDRqHqO0NUh6Q0ZR025en1Lte2ovw4z3Zr1lJ6o4+27br16bdX09ndGhz29p+xdSoU1TlQj4q8vdwcvSl1N29Ua2rzTqKyq5TXZZMp9dtvTuOn1xKxoSq1LSl+LhBcv5Fp+iXty703SL281C0rUKtw1Lw1YtM0ehPqRDojVV9CbT5Y63voy1jrjT0u8c6dC6rv2ovwvGfJmRl6P2mVI8XVzOD5cZVm0/6nd679P8AU73ULXdG28U7qy9qa85P4Fu6b1Y3lb2MdPq6LfSuoYj6z1Lw/wDI9TjpW89bxXLlvjj0/pd+49oW2zekuq2FovDCok3l5PD9DjL27rOU8fSjJF3a3m7unc7S7g6dxcUsyUljnBgjpnqO7Onm5rrQFpl1Vta9w36yNPMcZ9+DdPGO1Zjw54i2Wlony9X0vM/hPT8d8x+9F+9S5+HoRbtvH+7U+W/7p0evuzrzde1qOq2lNu7pwjLwY58jGOo6v1A3NsqW2K1hXpQox8CbotZSXyNNp9O1uft0Yq+rSkR/b5ZG9EJY2HeJf+KkZuXkYY9ErT7/AE/Yl3b6ja1betG6axUjhv4mZ0d+jiYxViUbr551Fphrj1I/+o+0/ho/ebE2f5lR+zX3Gu3Uj/6j7T+Gj95sVZfmVH7Nfca9P8lm3VfFRiz0k9IeqbJg4RfioVfWdvcYSstSqbt0XRdEhUc3b3sXOOfJG128dPpaltu+oVKblmhPwpe/DNZvRr2pqVv1Ov8A8J6dcU7eHilTnUg0u/BzanHPqRx9uvR5axitM/Tt7yctm9TdVvLbw0berYRhzFd/CXB6N9Fwt9Q3hXhJupTllvzSKvSu25fXNpaXdhZVrmVWqqbVGOZJfHHkX10b23Us+ldLSbik6NWpTcZKSw1k8Uw2jL2+nvLqKTgj/LEilqXV3qZe6XO6nT0yzficYSaeC192ba0va/WPSbDTFV8ELuH5SWX3XmXH9B3L0r6iXl7p9hXu7e89j8XDxefc8PW9P3Xq3VLSNwXmn3E7etdReFTfsYa7mO3V/lmIv0fXDKHpafoha/J/cc+3ln0Xp+J97KWf6nB6WTb2haYynjt/I7e16Fav6McqFKlKrVlZyShFct+43eZcUeyP9vF9EBY0q7x7v+paGguK9JC+TaTd3x8S9/RJ0/UbLSrpX9jXtZNcKpBrzMa67ou6LfrRrG4NN065ULS48al6t+38veebdqxLbSOrJMMg+l3KE7Swts/jKnEUz2dzUpUvRhjSmn4o2UU1gsS2st2dUt66fW1yyrW9pYT59ZT8PiRn7dO1YansOvtm3xCM6Xq457HrH/yRMw8Za+l00ljL0TZp7QuV/ZRY/SPH+vXU2n/3uRxbRqb12Bfaht2xsa9T108U6qp5isHa6MaLr9j1TV3qtjWcrio5zq+DEV8zXW/Noq32wzWs358tqcGvXpU6c6GoWW46cGp22I+JGwreMpmOvSD0SrrPTm9oW1GVW44cFFZZ26mk2xcQ4dHkjHmi0sSbYrUt59S9Eu1+Nt6WnShU93ix/kW5U1GrtC21jSJy8KuLybjFccNl+eiXtq8stJvLnULKvbV6dVwiqqw2seRavpDbO1at1Lsqem2Vepb1MSnUhDMeWRs47Rj6vtMRmpObojwuC02+9L6EX0YUvbuK/rlxzyy2uinS+y3ptmvfV7qvTqxruPhhVccJfA2UtdAta+zaGl1KeFK1UWv73hNfray3n0j3FXVvQq3unVpuajRg5YybcmGK2i1vDnw6ibUnHTzyvbQ+hGmadqVK9c6k502mnOeXwU+lpBUem9lTzxG5hE73TrqFuTcG41b3Wl3VtaSjnNSm1z/Q9j0gNr3O69kOyto5q05etS+KRviKenPQ5rTk9WPUdTo5LPSGco8p0pfcYx9G6WOtGsJtL8VL+fc9DoXuLcVpSns/UdJvIUVmKqSptR93c8ndmibn6ddRquu6JZ1a9CukmqcPF37mrr8W/DfGGebVn7heXpiNLaelLP8A3uJfvQ79XVhn3GBOpdTfW99Jtby7tK30OE1JUfV+2mjP3RKlXpdPLGncUKlGos5hNYaPeC3XnmzxqaenpYpz35XuPMldin9okkSqQADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADSfciMIx+rGK+SJBjgUzhCePFGMsdsonwRxjwrHuJA4FMadOH1YRj8lgh0qbeXTi372it8oLsOBQqVNPKhFP5B0aTeXSg3+6isDiDlx+oo/wDJp/4UVOnB94RePgVAcHKHGLWHFNfIRjGP1YpfJEgcCmUIN+Jwi2vPHJbe+92WG0tMV7fwcqTko4Rcx4m6NtaRuazdpq9B1qX9nODxkiZjivl7xzWLc28MVb260aAtu16Wl0Y169xTcPDTw2so4PRa2tc2em1teuqU6M7ipJqnNYaTZeendG9hWFyq9vpbU4vKzPPJftnbUbWjGjQhGFOKwkkctNPkm/Vkl2ZNTiik0xR5cvgguVGKfvSDhCT5jFtebRUEkjt4cCEljDRT6mknn1UM/IrD7DiBSoQjnwwis+5FFSapUpVJPiKyzk/Z5OOpCNanKnNezJcoxPbwf7a1dZd2Xm+N22+ytEo1XThV9XdTSzHDM89PtAp7a2tZaTDGaEMNo4dF2Tt7SNYudWsrTw3VxzUnLnJcsFwc+LDMWm1nVmz1tSKU8KmslDo0m8ulB/OKKwdPDlQkksJJL4ESp05fWhGXzWSoDgQoxSwkkvgil0qTeXThn91FYHApVOEeVCK+SJlnBJEvmY47DX70sfzS19/rqf3ma9q/o1pf8JT/APSiyes/TzUN8UqMLK8pWypzjNua74Zf+jWsrHSLOylLxToUYU3L3tLBopSfUmXRe0TSIh3sZ7lDpUm8unDPv8KKwdExy51KpwTyoRT96QcIN5cIt+9oqA4DC8ymMIR+rCK+SKgOBS6VNvLpxb+KI9VTzn1cc/IrA4OVMoQksTipL4rJKSUcJJEgzwCXBT4IeLxeCOffgqA4ENJrDSaEYxisRio/JEgxwIaTWGk0U+po5z6qnn91FYHECFFJYSSXyI9VTzn1cM+/BUBxAhxi+6TKVSpL/s4f4UVvPkBwKYwhFYjGMfksEef8ysoxzyZjtLFu8NcepTX+0daJJ5+jRy/5mxVl+Z0f3EYu3Z0z1TV+q9Dd9vqFKnbU6Kg6Tjy2n3yZUoR8FKEO/hikzlwUmuS0y69Rki+OlY+la5WCFThF5jCKfvSKgdLlRKEZfWipfNBKK4SS+RIHApnTpzeZU4yfxRxXDo0qM6sqcMQWXwc0uxx1qUKtCVKpzGaw17zzarMT3ax+kFuaW9db0/auiUKkqtGtitJLKwzPXTHRqmh7KsNMrpOdKHtLBTpuxds6bq9TVbSwUbqo8yk+clzw7YNGLFaLTNnTmzUtWK0hMYRisRio/JEerp/2I8/AqB08OVTGnCP1YRXyRUAOBQ6VJvxOnFv34JVOC5UIr5IqA4AhpPukyQZFKhBdopfJCUISeZQi38UVAxwGEUyp05fWhGXzRUBwKY06cfq04x+SJaT7pEgzwKVSpxeVTgn70hKnCT9qEZfNFQMcHKhUqf8Ay4/0RUopLCSS9yJA4AAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACHHzRIAjDCWCQAAAAAAClReSoAQ4+4RWCQY4AAGQAAAAACJLKJAFKjxyx4Soht+QEgAAAAAAAAAAAAAAAAAAAAAAAAAAQ0SH24Ap8PxJSwSgYAAGQAIb44Akp8PPwKl2AEeFBLBOQYAAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIl3RIADzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDWSQAXCISwSAAAANZCWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k='))
ON DUPLICATE KEY UPDATE ImageData = FROM_BASE64('/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASwBLADASIAAhEBAxEB/8QAHQABAAEEAwEAAAAAAAAAAAAAAAECBgcIAwQFCf/EAFEQAAIBAwMCAgYECwQHBgYCAwABAgMEEQUGIQcxEkEIEyJRYXEUMnOxFSMzNDY3QnJ0gZFSYpKhFhcYJDVTwUNEVGOy0SUnOIKT8CbhVWSD/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAUGAQMEAgf/xAAxEQEAAgEDAwQBAwQCAgMBAAAAAQIDBAUREiExEzIzQVEGFCIVQmFxI4FDUiQ0wRb/2gAMAwEAAhEDEQA/ANywAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYpXuY5FQI5TwQu5hjlUCkhteTMnMKwcfjjFZlJHVr6lZ0c+srwjj3s9VrNvENd81Ke6XeB4dbcmlU/8AvtLPzOnX3fptPOK8JfJm2umy28Q5r7jp6ebLoyveCya2+7KDfhj4sfE68+odtFcW8n/NGyNBqJ8VaJ3rSR5sv7K94yvejHEupVLOPoM3/MLqVRx+Y1F/Q9f03Vf+rx/XdF/7Mjgx/b9Rbao/at5Q+Zzx3/aOeHDj35PM7fqY81eq73o7eLL5BaVPelhLw+KSin25O9R3Ppc0s3lJfDxHi2ly18w3U3PT38We+Dy6GtadV+pdU5fJndp16VVZhUT/AJmmaWr5h1U1GO/iXOChP4k58snmG3mFTeAU4I48u4OVYIbQ4aMcspBS1l5XBUZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJPAEgjPBPkY8AQhkhzSXODLzzEKn2KW8Hlalr2n2alGrc04yXk2WfqvUKEJSp29DxrspJnTh0ebL7YR+p3TT4PdLINSvCnzKSSR511r2mW0vDVuqcZe5sxFqW59WvJvw3E4QfkeTWrVa9Tx1pucvfklcOyzb3yr+o/U/T8cMo6tvy0tm1Sp+sx7mW/fb+uKzaoUpU+Mdyysc4xlE5S88Eli2rDj8oPPvuozeHs1t0a3VyleTUW+x0Kuo31Zt1q8pZ+J1PHzwdilZXlZJ0qEp59yOv0dPjjxDh/carLPmXBJOTy2+fiU+BfE9OOhazLCVhVafwO9b7S1So03RnBefBqnU6arbGj1mRb/hJwl5l30tiX03iVRxz54Ox/q7ufEv97/yMf1HTx9vf9H1dvpZHPvGPeX5DpxcS73vh/kVPprXSb/CGfhg8zuum/L1Gxa2Y56Vg4XyIa+BfK6d3KeHd5fyOKv0/vILMLhy+GDP9S08/bz/AEfWV+ll+Feb/wAx4fNNl0XGy9RpRTUJTfuwebX29rEJPw2dRpfDuev3ems8zoNZR51C5uKMvxVRrB3qWvaxSwqd3KODgq6XqVL8pa1I/wAjq1Yzp8TTj8zZFMGSPpptk1WKe8yuex3tqNvFKtOVVnvWHUKnOUY1baUc+eTHCkmT3Xfg0Zdtw5PDrwbzqcXmWa7HdmlVqalO6p02/Js9e3vLevFSpVIyT80zX3CTyehaa3qlrhW91OMF5Jkdm2TjvSUzpv1RbxeGeotPzKuU/gYo0rf1xbRUK9KVZ+/Jd2kbw0+8pp1qsaM/7MnyRWbQZsXmFg029afN9910/Ik4KFxSrQU6c1JPs8nMpLBxTHCVretu8SkEeLkKXvD2kFLkT4kBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARIls461SMIOUnhLuOOXmbRWOZVLtk46taFKLlKWEi2dd3hYafGahUjUqRXEV5mPtb3ZqOpT/FzlQh/ZT7khptuy5vrshNbveDT9onuyFru8NPsYtU6sas1+ymWLrG9NQvZNW7lQXwZbE5OpNzqPxSfmRnHyLBp9rxYu9u6n6zfc+o7Vnhy3Ne4up+O4qym/iziikuGctra3N3Lw29OUnnHBc2jbJvr7H0lSoLHfB031GDTx+HFi0mp1c/labaUsPsdy10y/ukvo9CVVPzSMo6TsqxtIpV4Rrv3yRcVlptnarFGjGHyRF5t6iPZHKd0v6Ztb5OzFGmbL1G7jivGVD5ouHTOn1Ok/FXuPW/DBkJJL9lHV1C9t7Kk6tepGnBebIy+5Z8s9uybx7HptNXm3d5FptDSKUV4rWE2vPB6VDR7C3WKVCEf5Hg3e+NKp/kbiFT5HYsN4aTctRd1CMn5Nmm8aiY6plvxX0NZ6awuGFvCPCjgrUI+4pt60K9NVISUovs0zkbZyzNue6VpTHMc1hHhXwJwGviOF5nnls6YT8iFwx8SfL4mOzPdGA0n5BMcIzyx0whwi/IolSg+6RyYyvcO3HczFpeZxVnzDqVdPtaq/GUoyXxR0bjbWkXCfjtKbz8D2ckfI9xlyR4lptpMFvNVl6nsSyrrFu1S+Rb17sC5oQk6Nd1P7qRlX+RLS9x1Y9xzY/vlH5tk0+X64YHvNA1a1k/HZ1HBeeDzJKVObjNOLXdNGw1ahSqxcZwTT7ni6htjTLlPFrTjJ+eCTw73M++EFqf0vEd8c8sJYWOO4WU00sSXZl/at0+nTjKtb1nJ+UUi0r/RtSsptVreXhXZ4JXHrcGeOIlX8226rTTzMcObTdw6pZVFi5nKmv2cl66DvyjWlGneRVJdvE2Yz5ScXwycLHJ5zbfhzR2jh7027ajTW88s/WOpWd7BTt60ai+B3O64MA6dqt9p9SMratOME/qJ8F97d37Go1RvoqlhfWbIHU7Tkxd694W7Q/qHFm7ZO0siLtkhc+R1NOvqF7TU6FSM170zu5IqazE8SsVMtbxzBF5RJEe3bBJhsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFMs57kNvjkl8ywyOz95hhKzkN4y8nDc3FK3pSqVJJJLLLB3TviEPFb6dJVJPhyXkdODTXzTxWHBrNwxaWvNpXXru4LHTKcvXVoxnj2YvzMa7k3jfajL1Vu5UKafdPuW9e3lxe1nUuKkqjb832OvnDx3RZdJtePFxa/eVG3Dfc2oma07QqnJ1JOU25yfeTfLIfHLfB2tO0+7v6qp2tFz5w+C+dvbCWY172bb7+Bo6s+tw6eOJcWl27Uay3MQsiw0rUL+SVrbSqRfmkXroWwsONa8qSb/sMv3T9OtbOCjRowhj3I7qSXkV/Vbtkydq9oW7Q/p3FiiLX7y83TtF0+zjH1VrTjJeaXc9GMIpYjhIlJ5JSwRVr2vPeVixYMeKOKwnCKZdyplFWXhi37keYbbTxHLpazf0dOsp3Feooxiu7MJbm3HeateTaqyVDOFFPho9zqdr8ry7+g29Rukvre7JZCxjgndDpYivVZRd63O18nRSeyMImLcZeKLcWvNMAkppWY44V2MlonmJXbs3d91p9xCjdVZVKTajh+RmGyuad1QjWpSUotZ4NcfvMo9KdddWm9LqvxTgvEnkidfpeI64WrY9zt1+leWRcZZVhFK55Kl2IZcoAAGQAAA0AAwiML3EkS7GJESb7IjvxkZxH4lr1N3UrTUp2mpwVvHxYjLvle80Zc9MUx1MTMR5XSu3I/kdezvLa8oqpQqxnF9uTsLg2UyReOYkglhvB17mytriLVejGa+KOcmP8AkbK2mvh4vjrf3Rys/cOy7G+jJ28Vby/uosLWtq6lp8nKFCVSkv2jNj5OOvQpVqbhUipJ90SOm3PLhn8oXW7FgzxzHaWvLTjLw4zjuQ1nnGTL+vbNsr+LdKKoS98UY91zbGoaZOWKUp0V+2WHTblizdp8qdrNm1GmnmI7OnpWtX+mzjK3uJuCf1M8GRts70trxRp3co0aj4Sb7mKc+0447CLalmMmn70Z1O34s8cx5eNFu2fSW4nw2HpVY1IKUZJp9jky/eYZ21u290yrGFeUq9N8ZlLsjKOia1Z6nSUqFVSeMtFZ1WhyYJ7x2XnQbvi1VYiJ7vVWSopTz2ZUjiTETzAAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB5xwAAXbkEN4ZEvj2AnxLJOVjJRkNpLkccsTPHlLay2eVrms22mW8qlaoovHC97PN3Zua30qnKEZKVbHETFOs6td6pX9ZcTkln6ueCU0O3WzTzPhXN13qmnia0nu9Xc+6rvVKkqVOTp0v7r7luNc57DhLsdzR9LvNUufVW1KUl+0/cWauPFpaKRfLm1uT88unFSnNU4Ry28L4l37Y2XcXzjXvPFSguUv7Rdm1tnWun01VrRVSpJc+LyLuo0404qMYpRS4RCa3dptzXGs+1/p7ji+Z5+laPaWNGMaVGKaXdLlnpKOFgqRDeGQV72tPMrdiwUxRxWOEOIeSrugeW5TynyTlZEuxSBXnnB4G89WWlaPVrrDl2SbPbnNRj4n5Iw51O1v6dqX0ahUbpwWJR8snTpcXXfv4RW66uMGGePMrSuqzuLqpWk8ucm2ceEdmx0+4u3mnB+HOMnsR23Tccu4ln+R26je9JpZ6Lz3Uqm26jUc3iPK3gehqek17PM45lTXmedn4Hfpdfg1NOuk9nHn0mXDbptCc/A9Tat/U0/WaVSDx45KLZ5WfgyqnPw1ITT5i8m7JNMlZiJ5YwTfFkrbjhsfazVW3hNPvFM50W7sO9+naBRq+Jv9nn4Fxx7FXyV6bTD6fpcnqY4sAA8OgAAAAABjPcAxwKWnn4Ftb527S1bTqk6VNfSor2Glyy5yJLPBpz4K5azWWJiJjiWvVvqmraNeyoq5qpUpYcM4TL62x1FhUlGlqsFRiljx+86/VnQPDJarb0lGnBfjMebMYXlxSt4xq1+KT7y9xTsufNos3TE9nJzeluIbKadqVpqFH1ttVjOPvTO8sJGumj61f6bUp17avOVPhqGeGjJm1d/wBveqNDUPDSq9l8Sa0e8Y8v8b9pbq5ontPlf2OMonBx0asKtOM4TTjJZRyc4+BN1tFo5huGvezgubWjXg41YKUX5M5srHHIZ7rMx4eL0reOLQsXdOyqF14q1ovVz8oxXDMcalp93ptV07qi4POEbAPtyjzNZ0a01Ki4VqUcv9rHKJbR7pfFPFu8K3uWwUzRNqeWCJceR2tP1C7sK0attVlDwvLin3Pd3PtK60urKdupVqHfL8i2GpJ4ksFkplxaqn5UrLhz6HJ37MtbT3hb6hThTuWqdd8YLwhNSjlPJrtSnOjUVSlJxkuzRf2zN5uHgs9QljsoyfmQWu2uafyx+Fr2nf4txTKyamsckppnBb14VoKcGmmcscZIKYmJ4lbqXi8cwqBEu6J7h7AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAApy8/ACoiXbkjxP+ZTUmoxcm+EPLza0RHMkmorLZZe9d3UbCMrW1l46+MNe44t7bwhaUpW1m1KtLh/BGMa1SpXrSrVZuU5c5bJvbttnJPXfwqW873GOJx4p7qrm4rXNeVavOU5y97OKTx5csqgnOSSWW+xeuytoSuakLu+TVNcxXvJ7NqMeloqmm0mbXZfy8vau1rnVasZ1oShQXOfeZW0bSLTTLeNKjTimlzLHLO5Z2tG2pqnShGKXuR2MIqmr119RP+H0DbdoxaWvMxzKn5ExJ8KCWGcKZiOEgAMgIy+SPF7gKiJe8hvjD7nV1G9oWVrOvXmoxijMRzLxe8UjmXgb+12GlabOMJfjpL2UYg062nqN9KpVz4ZSzKR6G99blreqesisU4ZjHHmsnf27bK3sste1PljdNZGg0czWe8qpMzr9Zx/bDv0KUKFKNOlHCRX5/EJjJ8oz6i+a3VaeeVqx4q468VhTUjGpTlCSTTXmeda6NbU5+smvFLyT7HpkM6tPuefBTprPENOXSY8k82hw1LK0nBwdGKysdi19Z0yVpUc6a/FcY5LwyscnW1ChC4s5wmk8LKJnZd8zYc8VvbmJR+47bjyY+ax3hcfSW6i9HjbZXijJsv2PYxT0hqY1KtQk+YrODK0exetRMTaJj7btotM4OPwkAGhKAAAAAAAAAl2BEuxiR5m4tPhqekV7WfHiia/atpDuZXdko+zTm4/0NkZ48Es9sMwlaUlPfNzbTeKU5ybXvK1vuKvNZ+5c+btxMMfaRc1Laq7C+xGonims+R7CzGeYvD96PP6hafVtr6tfW8c16VRqEctLw57nJo19R1GxhUpT8UorFT4S8ysZKzSe3lryU5jqhee1N432lVo0qs5VqPvk+yMu6Frdjq1uq1rVT96z2Zrz8MHf0XVbvSLuNa1qSwnzHPBKbfu98P8b+HnHmmO0ti/LsQ15FrbN3daa3SVGc4wuUuY+RdK59xcdPqKZq9VZdsTExzCXlrghZaJw+5Dwu5uJcdehTrQcZxUk1jDMf7x2VGrKd5Y5U3y4LsZEXDE4prDWTq0+pvhtzVwa3b8WqrxaGvNxb1qFWVKvBwkji7SWHiS8/cZh3btS11OhKdP8AF1ksrwruzFGoWFzp9xK3uoeGUX/Utej11NTXifL57uO15dFfmI7Li2fuutptaNvdy8VHt4mZW02+oXtvGtQkpRkso1+kvEi5tm7nr6RXjTqtyoS4eX9VHFuO2xaJvjSmy71OO0Y8s9mZ+6ISwdXTb6je20K9GalGSyjtZeCtWiazxK90yVvETVIC7Aw9gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFCxhlZQ+2WGJnhEpJRzIsjfW64WNN2lpJSrtc/BHPvrc8NNoStreSlXku3uRimvVnXqyq1ZuUpPOWTe27f6k9d/Cpb3vPpROPH5RWqTr1HWrPLbyRThKrVjCknKTeMIQjOc406ccuTwkZK2FtSNvBXt5DNaS4T7Im9VqqaXHwq+h0OTXZeXW2Ts6UZwvb+PxUTItKlClBQpxUUvJFVKEYQ8MeEiryKjqdTfPbqtL6NodBj0tIisd0LGcMrbwUYyslWMnMkEgdkQn7zIkAAUt88kY8xNpZyWtu7dtno9F04zU67XsxXJ7x4rXniHNn1OPBXqtL3NV1S10+1nXuKijGCy/eYu3BrN3ua5dOhOULRcccZPAvtWv9wajGFeo143hRT4/mXHbUI29GNKKXC74ODeNbG3U4r7pQ+PNbcLcR7XnQ0K2iuKk/Ej1IpQhGEUkorCwiUM8nz/V7lm1Xa8pjBpMeH2whEgEc6QAABw015PgIlYTSN2CenJWXjJHNZhydOKXqt4XEeUlS7f0/9zKcexizZ3ihu6tJf2Vz/kZTi8xR9Q02WcuKsy4tvrFKTX/KQAb0gAAAAAAAAES7Eh9jE+BxVPyc/kzA8LhU9716zk8xqtJozXuG9/B+k17rj2V5mDdHbvd0ynjipUciu7xeLZKUaM3mIej1It6ML+hiK8NallrHvMWWH/wTcC0xT/3evmq5Nvgy/wBXIqOpWMFjijgxhvKxd5pMpUFivBpqS44RXNV/HPNXituLzWXtrnt28gmm+O55W1dShqemRlGXidHFOUve0eqliXHY4bR0zw58lOi3Dls7mvZ1VWoTlTmnn2XjJlzp/vClqlvG1vJqN1HyfmjD3C+RXQq1betGrRk4STzlEhoNdfTW89nrHkmstllLMcr+pPddix9gbupanSVndTUbmK7eTRe8eUXnTamuenVDuraLRzCVjAeWuBF+QXDwdb0peGvaRb+7Nu22rWr9hKrFZi1xllxPl4Ia957x5bY7c1lz6jTUz0mtoYB1fS7rTLmVGvFrwvh+86LSfLfJnHc2iW+q2coSglUxwzDms6dU0y9nQqxksPhtdy2aDX1z16beXzzdtpvpL9VPD2Nm7lraVcxpVpuVCTSlnyXwMuafeUb22jWozUoyWUa++XzLr2PuSpptzG3rSzRk8cvsc25bdF49Snl2bLvM4rRiyT2ZiXYlPJwWdxTuaEakHmMllHPwVqYmJ4lfaXi8cwAAw9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJLnIT5wRPORwsBhGeOTwN3a5R0qwnUcvbfCWfM9DWNRo6fazrVZYSRhbceq1tW1Cdac26aeEvIktu0U578z4hX963SNPj6az3l1dSvK1/dTua78Um+PkdaKzJQXd9iW/Jdy8Ng7YqX1eN7eRfqF9Vdnks+fNTS41F02ny67M7+wdq+scdQu4v4RZkqlCNOKikkkvIoo040qcacEkkvI5F7kU7U6m2e8zZ9K0GgppMcVrHdVHsSRHsSc6RRldiSMIkARJZwSRIBjK5KW/8irujzdxX/4P0mvdf8uOVwZju15ckUrMytjf26/wbD6LaNSrTWH8DGkrDUdSqyuKjcnN5bk2erZ0JX99W1Kvl+OeY55+Z68UorEVhe4idw/UMaP+GHygI0V9dbqyT2eLo2j1bS59fWaylhJM9ph5BSdx3PLr7xfImNJpKaavTVCJAI11gAAAIAESUks9VniWJjs7O36ypa343HLbSMnUmnBfIxjpn/EaP7y/6mTaH5OPyPo+z2mdNDnxdrKwASjpAAAAAAhvyJAAjvnBPcpqSUINt4wjza0VjmRY3VrVadto0tPcsVK6yiw+mtlUr7koVZRzTiuSeo+sfhfW3DxLw0G4LHmXb0ssFZaTWvLleGTfsyfHBUcl51Gr6vqHLM9eRbfVWtCrrtNQlnwLDLRaThKL/aTR39xXUrrW7iT7KbwdDzIXWX5zzMNFrcX5WXo1SWhbvloknihcZrZfbLyXq8Z+BZvUu2nRtKer2+fpMJqCws8Fz6PdQvdMoV4NNuC8WHnk15I5rFnTnrFqRZ2kF8RzkPg53E5bK5qWlxC5pScZxeePMzXsPc0NZsYQrSSuYr2kYPfb4nobe1WvpOpwuKUny0pLywS+26+2nvET4bsWSay2K7jnJ5m3dVoatp1O6oyzlco9J5xll5xZIyVi0O6J5VMEeZJthlDSaLe3dt6hq9rjwKNWP1WvMuGL8hJZNuPJbHaLVaNRp6Z6TS0NfNVsqun3s7WvFqUXjOOGdbGezw17jMO+NuUtUs5VIwXr4JuDXmzEV3b1rS4lQrxcZxeGW/QayuopxPl813Xbr6PLzHhfPT3c7hOOn3s8eVNmTINTimnk13pynTqKcXia+qzK3TzcCv7T6LXklUpLCz5kVumg6J9SnhP7Du3V/wAOSe684/Wwispg+clRArjE8gADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkDCyAIkss4q9SFKDlJ4SRyyeOSyOo+vKzsZWtvPFeXu8kbsGGct4rDi1uqrpsU2lavUHXnqF7K0t5P1MeH8WWnjC+RU5SnJzk8uXLOxptpVv72FvRTcm1n5F0w4qaXE+YajNfW5+Y+3p7P0OprOoRUo/iY8t4My6bZ0rO2hRpxSUVg8/a2j0dK0+FKnFLjLfnk9qLyVXX6yc9/8L/s22102OJmO8pwQo4ZUCPToAAAAAES7EkS7GBHK5PC3tRdbbt3TTx4onvLtg83cNF19Jr04p5cfI83t01tP+GnNTrrwxlYx8FjRjjlR5OdeXxEabpL1ck017yT5frLTbNaZe8dYrWICB7wcz2EEgwAAAEBdiQAXbBDJ8jMeR39CoSuNRpxg4pwxLkyPSTUEvgWDtKLeptpN5iX+j6Jsk/8AxoaaR35S5JDKfYoqVIU05VJKC97Zx0Lq2rfka9Oo/wC68ktzH5buJ/DsZRCaI+aIbfdGeRWnkFMSoyBSsclRS1zlgSmsPBaHUjXqOn6PVtYyauascQwXJql9Q0+yqXVdpQgsswLunWK+t6rUqTk5U4zxSS9xC7trPSp018y1Zb9MOHQdPr6xrELeGXOo05SfYyhvO6p6JtJWNN+Gv6tJY8zg6Z7eWm6e9QvVFVJLxQfuRZW/9bnq2rzjCXsUZOHzIeONLp5tbzLT7Kcz9rcbcm5yftS5Ya8/MlkFctPM8uWZdbV7aF7p1WjUipLwt4fm8Fp9ML+ora6sLqeasKzUV7ki9e6afZrBYEMaP1JjS8Tjbzp5eOFnn/8Af5nRi/lSYd+n4tjtEr+75T7hLgnKklJdnyO5zS4JjvweefMeQAieBd/TrcktL1CNpdNu3n7MPg2ZopTjOClFpprujWlSlCSnH60eV8zMfS/XlqGmxtass16a55LVsuu/8dnXp8n9sr2bSJKEm+SstcOox5kS7EkSMimS8XDRj/qJtr1tKV9aRSlH2qi9/wAjIOeexx3FKNWm4SWU1yjfp89sN4tDg1+jrqcU0mGu+HF+Gaaa8jtabfVdPvKdzSk04PhZLg39oM9Ovnc0ofiqsm3jyLWWGsr+Rc8WSmqxPmefFk0WfjxwzptfVqWp6fTqxknPC8fzPYyjC+wdcnpmpRo1JfiZv2svsZitq0K9JVIPMZLKKnrtLODJx9PoO0bhGqwx+Yc3iRK5KI4KonCmUgAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gAKVl+ZE5eFNt8CO7EzEeXR1zUKVhY1K9V4SX+Zg/Wb+tqOoVK1SbftPw/IuzqbrXr6/0GlUzS/aw/MsZcLD7lp2jSRjr6lvt89/UO4TmyenWe0J/aSXmZP6b6ArWgr24p/jpdm/cWjsXRXqmoxlVg3Qi8v5mZ7elGlSjCKworBo3fWf8Ajq6v09tnVPrXj/SpccFUX5E4WRhFdXiI4AAGQAAAQ+xEWYFRHdEN+WBygJTXkUyw017ycdwkzFvHDCwd1Wbt751cYjUZ4zMhbh0+N5aSWPbS9lmP6kJU5ypyWJReGfPt40c4Ms2jxJH4U9kA0CFZAAAAAAgkAQT24XKGMhdjMd5Fw7Hz+EKnu8HP9TyOq3VG02tKGnadSnfajVfhUKPtOHxaR4e6d1f6JaTKrB/7xe/iKLX7Mn2Z6PRnYEbel/pTuGDr65dZc5T5Xh8uGX3aIvGnisNuGlYr12W1pundZd1wldVtTtrfT6q9mnJKMkj2LfYnUPTLKK0nWLeF0vrTk8p/IzLGEYpKKil8CcLsS8YK/cvU6i3iI7MK6Xv7dG0NaoaRvyjO8lczUKdxbw9iLb7tmZLSvRubeNehUjUpzWYyi8pnlbw0G117R69pWpxdVwapyxzFnkdNLlWtpLblRylXsFibbFOaW4nwX4vXmPK8YFREf8iJN912N7QqKZPDySpdy2N/a9HR9KnGEsXFSL8D9xo1GaMNJtLEzxHKzOqm5ZXFx+C7SbUFxV+J4vTrb89U1WFeqs21J+2n5ng0adzqmperTcrivLJmTTqFptba7rOKjUUE6izy2VTFP7rNOW/iHLX+duqXmdSNbpaVpq0q1eKs44jj9lGJ5NuTcnmUuWzua3qFbU9Rq3NWTcXLMc+46XCRG7hqpzX4jw1Zb9UgAI1pgLA6qUJWtShq9PKmqkYcfP5F/lsdTrX6XtaUHFyUKim18jfp5/nEOzRz/wAsV/K4NOrKvp1vUXnTjn+hzludObp3m3VNtfi5eDHuwXIuxjLHTeXjVV6csxCEGAaXOd+Gexs/VKmk63SqQk0qslGXyPH7sOTjyvrLsb9PlnFeLQzWeJ5bJ2NxC5t4VaclKMl3R2CxelOsxu9LVlN5qUlyXznJ9F0meMuKLQkqz1RykiQ7DGe51Q9Kc+ROMdyVFIkMPL1/Taeo2FS3mk/EjCWs2VSw1Crbyg4xjLEW13M/tLOCx+pOiK7s3eU45nSXZeZL7ZrJw36ZntKs79tsZ8fqVjvDFnPZcebMpdN9fV3a/RK8sTp+zHL5aMWtNNxkuVwzuaJey07UqV4nxF+RPa7TRqMXMKntetto88RLPyxLkqj2Ohot5C8sKdanNNyim8HfjjBTLV6Z4fTsOSMlItH2kAc5+BhtAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADzjgBsClcHibv1SOl6XUrt8pYS8z2qjSg3kxL1K1eV1fK1p1M00sSS9526DT+tliPpD7xrI02CfzK07urK4ualebb8cskUYTrVYU4R8Um0sIoXC57F49NtHV5eK9qx8VOHCXxLZqMtdPh5h890mG2r1HE/a+tlaTDS9NjTSWZe0/5lxfA44RUIqKWEkcnkUrLknJabS+o6XBGDHFI+gAGt0gD7ERyBIbwCHjAE54yUrCWSKlSEINyajFd22Wbuje1lpzlRoy9dU7Zg84NlMVsk8Q5dTqseCObSu+tWp0o+Kc4wXvbOp+F7BtxjdUpNd0pdjEdHXtY1q6aq15epT+rjsjuws6FOTlHxKTeW/F3IvcdxxaGem3lzafV21M80jsytTvLWo8U7inL5SOwuV3MV2tSpbz8dGbi18T17HcV7SmnXk6kfciMx/qDDa3EpGOftfkllYfJau69HyvpVvD2l9ZLzPU0vW7W74c1B/FnqS8FWnw1JM7NRTDrsXZnyxW8rhrkFwbl0ipQqO4oxzB8vC7Fvsour0l9PfpkiQgIk42QBIAAQSAJivEyO5xXtX6PYV7jxKPqqbnl/BZPePnqh6rHM8LE1yynvHqfabYXMdPlG6bXZ9v/AOzZW3p+roU6a4UYKP8ARGCfR6pLXN1X+8I0n4aqlRU38H2yZ5R9I2zFOPBWJbc8dPFIMYWEQ8pYDeOEhzEkWhTOXgUpYba8l5mMenVrrS6p7mvr2nUhY18OgpLjv5GT/PkNLyil/I8Wp1TEvVb9MTH5VY9nghZSwhHOeSZdmenlw3FaFClKtVkowistswTvzWa2r6zUhOr4qFKWKeO2DIPVbXIWWm/QadTM66cXh8oxVolhPUdUoWfLc33Kvu+qnLkjBVzZrcz0wvfpToEalWWpXNNp03+LbODqhr/0q5Wn2s/xccxqJe8u3Xrmntra8aFOSjXjTxHHmYbuKsri4ncSz4pvMsnJrckabDGKvn7eMk9FemFCXGF2DxlZDy+B8GV7nlzciWAO4AHU1m2V3plejJZ/FyeP5HbKa2fo9X3uDWP5HvHPFoluwW6ckSsHo/cThbXVjJ/9vJ4MgYwYx6eSlbb3r2OWs+KWMGT2sNm7Ux/Ln8t+sr/Lq/KAAcziMY5Cz5juFywPe2Jq1TStep+GTUa7UJGeqT8UIyi0013NaaVR0K0KyfMH4kZ42Lf/AIQ29b13LMmuS17DqZ46Jdemt24e/LOSUQ+e3kTHOe5anUkAGRRj2vccd1ShWoyhNZi1yjkeck4MxPEvF6xasxLCe+NJemao5RXsVXn5Fv8AmkuxmffOj09Q0mq4081or2WYbqQdGtKjLiUXiXzLftmp9bH0y+a73oZ02fqjxPdf3S/WcOVjWm3Jv2eTJcO2TX3S7udjqNO5pZTi/Iznod3G7sKNVTUm4JvBD7tpfSydUeJWT9O6/wBXH0W8vRAyhlEOtIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABD95JDfHIYl4+59Qjp+lVa/mkYQu67ubqpXln2pNl+dVdTalGxpyzGa9pGPY48PPkWrZ9P0U6/y+efqLWzly9EfTkt6M7ivClBeJykuDOG1NMpadpdOnSj4fFFN/Mxx020p3epxvHHNKHDXxMu04+GCS8jh3jU9duiPpK/pvQ9FZy2SVrsUoqINboAAGQAAUvlnHWqQo05TnJKMVlt+RyTkoptvCRjLqXuqSctNsamH2nJPuvcbsOKck8Q4dbq66bH1S4N8bwrXF09O0qeYpuM5xefF8EWgtHuq1N15t5ay0+/vPR2zYxVH6VUSbl296PcfPGMIgty/UP7TJOLF9IfDoLa2PUy/bz9DtI2tmm0vHNe0d9heeFwQii6zWX1WSb2+0/gwVw06aiJyCMHG3quzyuGexpev3No4xquVSC4weL2+JJ1afV5MM81ljhfdHWbK9ouE5KKl5SPB17TaSi7m0alBd0uTw1j3nNSvLilBwhVlGLWMEll3Kmop05oY4lwY93DJxglvxPL7kEN257PYGkR2GTHLCSMk+RAkFgtXqhrK0nQ6VHu76qrdrPOJcf9S6lhe0+y5ZjrTrOW+Os34Jqub0+zhGvFvs5R5O7btP6+aKujT1iZ5lmjo1tmG1NjW2mwSXibq9v7XJesexx04KnRhTXChFRX8jkj2PpOOsUrEQ03t1WmUvgLkiXYR7Gx5SAAIl2OrqVzCysat1U+rTjlnal2Mf9WddlZ2UbOjLxOtlTS8ji1mojDjmZebW6Y5Y43XqUtT1itcN5puXsfAvTpRo0aUKuo3lPlc05PyRYWi2Ur/UqFmuVUljJlXdF5S29tRWMWvXOniOPMqujjrtbPf6cuPvM2lZHUfXHqmreoh9Sg/Dx2ZbHlwQ5ynN1J/Xm8thccETqs/rZJs0Xt1TyAA5nkAAAifFOXi59lkjzETwzE8SxdZf7l1TcYtRUqX9eTKTeUnnOTFe6/Ba9UKUm/D4qcfvMpQ/JQee8Uzs1MfxrKT19eMdZSADjRfHcAACSyse8yX0b1FznWspviC4MasuDYF/9B1+mk2vXSUWSO15vTzw24bcWZ5WOwSwUwl7KfcqTyz6FWeqOUgkAHsAABx1oeODj70Yc6g6XHTtU8cIcVm5NmZ32LT6g6WrzSqlWNPxVYL2SQ27Uelmjnwgt80fr4JmPMMPp8e5mQulmr+GMrKvNucpeyY8cZRm4TWJR4O/t29enavSueXh4LNrsMajD2Ufa9ROk1Mcs+LDQwdfTayuLKnWX7UUzsZwUq0cTx+H1HHfrrFo+1QAMNgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABHOQJKfF7WMFRThZyBPiOvqFeNC1nUk8JI5nh89i1uouoRttBrU4zxUn9Xk26fHOTJFfy49bn9HDa3+GLdw3dS91WtUlLKjN4Og+ZRSXLeCPE3mb5b7s9balktQ1yjQfMXyy69sGDn8PmHfVamI/LKGwNMWn6VFY/KYkXNjHY4rKiqNvCCX1YpHOUrPknJkm0vqGiwRhwxRCRIBqdYAGBGecYGeSGyXgMT4W7vnWIaXpNSUniVROMfmYMrVatxWlUqSlOpN5bfmZF6g6hTude/B1Z5p0mpNN8Hlw0ywhdSr0YxlDK8OFjBty7jj2/DNrR5VXXae+uzcRPaJNHhOnptKE14ZY7Hd8if5YRDSPlWtzevntkj7WXTYvSxxT8Iz7hwTj3B4XL7I4+mW4UWyiM4SnKEZrxx7oxF1x3zdaDKjQ0m+l6yo2moceEw7S39u2F2rlavV75cc/8A7gkcO32yV6uUlg23Jmr1Q3CaafYpfLwY56N9QobotJ2l4vV3NLhSb+uzI+MN5OLNitit0y4suK2O3TJx5jgfNfIjBqaj5koAQKilkoHryI8uCcPyC4Wex1dWuHb6VdV4SUXClJxk32eDNa9UxD1WOZ4V6pP1OlXdV4XgoTly/wC6zxPRZtPwlbXG5p0n45TlR8b88NmtV11G3TUu7ujW1WtWtXOUVDL7ZNlfRG3TpN3tNbet5QheU5SqTgnz37lu2bRxhyc2lJ5tHfT4OqftniXPCJj2KeVyVR7FrhFDWUT2QBkU+J+4lPhZIffvknKffuYmeBw3txC2t516n1YLLMBbx1Geo67cVFJyo+L2F7jKfVDV1p2jOj+1cJxi8mGLahUuq8LeL/GTeEVXes85L+jVy57cz0wv3pLpUKlSrfXEPCqXMJM8fqPqz1PWJUVlQt5NLnuXtWlDb+xVDKhXdL5NsxJVqTr1ZVqr9qbyzh1l4w4IxV8vGSemsVhT8SMZ7hsJYIKXOAAAAAA8wSu6AxJ1Mpze/wC2qJNcRX8kzLFL83o/Zx+4xT1bqSpbstZx7+z95lW2y7O3k3lulH7ju1Px1S+v+CisAHD9ojjuEogADsaXP1Op21bOHCaZ1yG8LxLuuxsxW6bxLMTxLY3Rbn6XptKvnPiS5O9HsW506q+u2payby/DyXHFeZ9J0lurDWUlWeYhIAOl6AAAfY4LmmqlCcZc5Rzspl2wZieJ5eMlYtWYlgndthUsNZq+PtUk5R+R5T8n7nkyP1U0rx0VfRXFNc8GN/2S6bfm9fC+W7rpv22pll7ptqcr3SPDN8034UXa+xiHppqErfWI2XixCpyZfT4TRWNxw+lmmPyvex6n19PE/hUuwAOFNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUtc8FRT+0YYlTPhMxT1Vu/WX9GjCeUlyjKdzJQoyk35GCty3MrjWbnLb8M2kTGz4evLzP0rH6l1Pp4emPt5reF8PMv/pRp8Z+K9kvajLCLAaz4Y47szZsnT4WWj0lFY8UU2Su8Zpx4+mPtX/09pvWz9U/S4o9gQiSpcPo8HzABlkDAfYCJfI4Lyr6qhOp/ZTZzdmdHWudNrpd/Vs9Ujm0NOeZjHMsLbjv/pG6Liu4qXrPZz7n8D2dOpKjZQpqWfMtDVW46jNp4aZc+hV3XsYZl4pLuzg/VOnv6ETXwrG1Z4nUWi35ehnzGfgQQ28nzGZW1X/MJLs+UUhfMzFu7MTw1p9IXSriz1+N1Om40q024+4xank3Q3btzT9y6bO0vKUHNrEKjXMTD1z0E8d64w1Wai3nhdkTml1mPo4sntFuFMdOmy1eg1O4luaFe3pyqQpSzNL3G0jecSax70Wj082JY7QtXGnNVazx7eOS7X95G63NGS/ZGazNGXJMwPOQMvGMA43GAgkwBKI8+/B1r53Xs/Ro5XnjueqxzLMRzPDs1ZwpUpVKsvDFLLZgbrR1EUKk9J0S78afE6kH/VM97r3ue+sNvfRLWtK2unNJtPlp9zXOpOdSUqlRuVR8tvzZM6HSRMddk1t+h6467eHc0bS9R1rUY2enW8q9xUlmUYrnnzNtvRp6TXmzr+evX8pQr1qXhdOS7Jot30Otk0qlq923VNTcm6cVJdsGz+OC3aPTduuXnctZNrenXwhvJMewwvcSSfhDAfYB9jIozz2wJPCbKkuOe55m57l2miXVeMvDKFNtNGjNeKUmzE9u7E3VDVal/rM7Kb9m3fsnW6c6bK+1ynXUPFGjLM/kW9f3VS8ual1Wk3Ob+szJ2wrJaRtuvqc8r1kPEn7ymYp/caick/Tjr/O/Lx+rGqq4vKVlQlhUniSRYp29ZuXe6rcXLeVKWVydQj9bm9XLy1ZLc25EPiPIHG8AAAAAAF3AXcDEnWH9KLX/AO37zK9r+Z2/2UfuRh3rHUn/AKc2tPxPw+xwZitOLK3+yj9x36qOMVExuEcYKOQAHB9oj7AAIYCJLKZIfuEDMXSa48ekKlniK/oXyuEYx6M3Dn9Io5z4UZOXY+h7XfqwRCRxe2AAEm2AAAFPYqfYo5DDyN3WP0/SKtuu8kYOrQdK5qUX+xLwmwteHiptfAwjvKxdhrU1KOPWNyRP7Lm4t0Spn6n03MepDoaVcuyv6dynhppZM66TcfSLGlU85QTNf8eJ5fkzMXTi9d5o6zPPg9nubd6w9utz/pjU8X9P8rsAQK2vgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAygBD+CJIfL7mJHhbzuna6HcVYvDSMJVJurWnUfebyZT6n3kaenStm8OojFEOF8S1bLi6adb55+pc/Xl6Pw9Db1sr3WaNv72Z102l6qyp0v7MUjEnTe0dXXKddLMY8NmYqa8KSI7ec3Xk6fwmP0zp/Txdf5VIkJp9gQ61wAAARIkS7AUyafY6WsRc9PrRiuXBo73l2KKkPHHDXDM0nieWrNWbUmGu2swcNSqwkuUzm29dVaF34IcqbSaZ6nUeyla7lrzUGqcuz8jo7UUXfTckspcEju01tt82mOeyhaetse4TX/K6Gn28yPMqTKT4pl46p4fQK+BkrnuDp6pffQ4wjCKlUqZUUea16p4h7iJmeHcefLjBPK7POTx7fVrz6TCleWqoxl55PXbXGOUer06WZjgb594x5sd32Hlya+Hk8shcjv8AOwDy47glGYjkQ1xjzLT6k71sdpaROfrYSvHxGn5/M9TemuU9vaFWvpOMppNRTfwNRd0a3e69q9a7vK86ic24pvKSySWj0c3nqt4SWh0U5rcz4U7j13UNd1Cre3txUqeKTai32RcvSrpxrW+NUoVKFvUWnxqJzrL4eRb+ydv3O59yW+mWqlKbknJJfs55PoB062rYbS25b2FjTjH2E5NLHOOS16PTdfH4hK63VRpqenR3dm6BZ7a0K30uypxp04RWUl5+Z7ZSuZFRO1rFY4hWZmbTzIAD0wAACM/5mPer+o1Laxo29KbSqtxlj3GQW+ce4wd1NvZ3G5Li0lJuFJ8ckNvOf0sP+2rNbpqt3TrZ3V9RtIr8pLCMl7yunouz7fTU8SlDwstLpzYyvNdpVFyqMk2/cdnqfqH0vV/oueKDwV3BPo4Jv8Alz1/jSZWjDPhRI+QIWZ5lzgAMAAAAAAEryZAfCeXhJZyIZiOWGOqqhddQLZRfbwLj3pmY7VNWdBS7qnH7jDG7KsLjf8ASlTbl4WZppfm9H7Nfcd+r+OsJjcvgpCoAHB9oefIADDAQ1x3JHfJmPIyD0S/P7791feZZj2MP9GqkoancpdmuTMES+7NPOFIYfakAEy2gAAPsUrkqfKKVlMwJ8mYx6r2ebmndJcQWDJqz7i0epVq6uhVpqOZLsdugyenniUPvWH1dNMMRc9/LBf/AEpv40ZSsm+ZvxGP1nDhJco97YFdW+4acpSwsYyWfcaepgUXacno6qGb4vKDWWUUpJ04v4HJlFNl9QpPMcgGUDD0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEY5ySABTx3Kiio8RY45ebTxHLF3Vyv4r23hF9k8ljZRcnUO49drLinnwPDLbeE1x3Zddujo08Plm739TV2ZI6Q0YStK9bCyp8GRMcZLT6cWqt9Kz/bxIuztx5FV11+rPZ9A2fH6elqRZJCSxwSciVAAAAAAPsABY/U/RJahp/r6EM1KftSfwMT6XcytbuMk8JvEjYq6pQrU5UprMZLDMNdQ9tT0y9ld0IP1NSXZLsd+K0ZsU4bKru2jtjyxnpD0YSjUgpxeU/Mq4LY0TWPUQVCv9RcJ+4uGhcUK8VOlNPPPJ813XZc+nyzNa8wltFuOPLSIme7lTyzzNcp1PXW1eNPxRpy5fuPT4k8Jp/JiSTj4ZJNeaZCzjyYZ5tCTxZqzPNZePqF7b6hGFO28MqrXGfJvt/mepZwnC1pwqfXiiY0aEJeOnSgpeTSK+e7PF8kT2bb358DGPiEPma2tD96ZOOMvt5kVJRhFyafh82kclpp+p6o0rOivUP60nw0dODR5c0/xg5j7RSj62vGhTy6kuyLg0zbtSUJVbzMFFZxnyPX25tq20qCqSlKpVfLlLyLa6671p7M2XdXVFxldteGFPPdMtGk2WuKvXlesWOclohrV6SW8leb2haaZJVLOhTdOdNcRbXngw1ObzKbXLecI5dRvKuo6jXvK/ida5quSS55fkZy6DdELvXrijrW4YSo2q9qMfJryOiMc5LcRC29ePSYo5et6G+z6tfUJbtrUWqcVKmlJG2K7YwedoOjWGiWELHTbanb0YJcQWE/id/HvZN6fF6deFY1Wec9+pVFJfEkiJJ0cOaAABkDWQH24MDo6xX+i6bcV1w4Qbya+azdTvdUr3c226j5M19QdQVjoNaMsJ1YOKyYGefA228yZU98ydV4xuXUT4hkbpZRdhY6hqNRez4E45LK165+m6zcXT/blkyDaeGx6eqXixOtRf9TGEXle13IzV26MFcbVftWISvPkDKzhAiWkAAAAAAAAKarxQqSXOIMqOO6nGlZVpy7KnL7j1SObNuGOq8Qwpbzjd7/eYdpNNfJmboNergksYikYT2FB3e+ZyS5cpNYXxM24SSS8kdut7REJLc5/jEAAOBET5AAADz5BB8MQL56NtLVblP3YMwxMSdFoKWo3kmvqr/qZbj2L5steMKQw+xIAJptAAAAABnmbgtfpWm1aXvR6ZxXS8VCax5Hqlum0S06ikXxzEte7mPgva8f7M2jl0q4+jajTqcd0nk5tfo/R9WuE/2ptnQhxVg138SL1Xi+GHye/OLUW/22EsJeKzoy98EznafuPL25cRr6ZQaaeIJf5Hq/8AsUbJHFph9W014tjiYR8SU8kL6xUeHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcNzLw02/gcz7HU1SfgtZz9yPVI5tENOonpxzLBm5Kkquu3WecVGefJN4S75SO1q8vHq91Nec2UWFNVbunB85fYu2OOjTf8AT5Zmn1NX/wBs2bSp+r0e34w/Vps9juefoMPBptCOMYguD0vLgpeaebzL6do69OGII8EkRz5iXY1utIIj2JAAAAAAKZd2dTUrC3v7aVG4gpxaxyux3JfBENcZEWms8w8ZMcXr0zDDu79kXFhOVxp6lVorLl70WbGpXovCnOGPi0bI1KUKkWpxTT96La17ZumanmTh6pvzgsEhTU0vHTkjlWtZstq268M8MM0dQuqdSMvXTeHn6xdunX1K9oKcZJSX1kzn1Xp1dU5v6DJzj3XiZ5kdjbkpSfq6OF71PBwbptGl1uPivES5dJfW6W/8qzL1nzjH+QeF9Z4KLLbG6KfE6Kf/ANx71psypcpfT6k4Y59l/wDt/wDvJUL/AKXmLcRZYMOsy380eFOSjju35JcnsaVole+h42nGD+4ufRtvWenRajmqv76yezCEYJKEYxXuSOrB+nseOf5d3bSbW7y8bT9u2du1KS9Y/NSPXo0qVCPgpU4wXuSK19ZFWETeDS48McVhs7KVk1g9MPSdY1TcFhS06NWpB0sOCT8LZtCdW7sbO6mp3NrSrSXZzing95sXqV6W/T5vRv1tWug/Qe8d7R1vdlD1fhWadLumvibUWdtQs7anbW8I06cFhRisI5IwjGKjFeFLsl2QfLz5HnDgrijiHrPqb57c2lV4ec5Hh+JK7A6HOLsAAAAAABmJ7dxjnrZVcNOtYp958mL7GnGrf0KLWVKWEXr1dvHW1FWucxhLsWrtiPj3FYQx4s1Umii7jk9TWQ4cs83Xh1EqystuabaUm14l7Szgx/2yXn1TuI1L6lbxln1Xlksx9zk3Gf8AlmHnL7jyC7AEe1AAAAAACSAB5W7LlWuh1qmeWmuWeqWj1aruhtGcoNeLxpG7TxzkiHXoq9WeIWX0epeLd1W4wsPxZ58zMcvrMxX0UtnKlK5SWPE+TKjeXlm/Wzzfh07nMep0oABxIsAJ8gIHOXwCHnDwIGReilKcbu8nJcSivvMrRMedILfwWlSs19ZGREsI+g7TXpwQkcXtAASrYAAAAAIzl4Kay/FtfArSwUVOzQjy839ssL9QqXqdcSxxJNlurun7mXd1Xh4dbotLjwd/5lof5cF10F+vBD5ZulPT1MwzF09ruto8XlPDx3LqWc5LD6Tzb0iab/7Qvx/VRUtXHGSX0Pa79WCJVIERfOCTmhJAAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAPN3HLw6ZVeceyel5njbw/wCCV8e424fkq5dZ8Fv9MI6i1K+rSj5yZ2dvJPV6CksnTuH+OqfNnp7PhGruC3jJcNl2zdsE/wCny3T/AMtVH+2bNNio28Eu2Edt+84LaPhpJe5HMuUUfJ3l9WwRxSEoNZAPMNwlghS55JAAAPsABTyuxOM9zHIj9ocv4Er3DHPJliEPhYyEuETwQviYB8PCGCeGQx2O4skkDI5hniRc8hJZ7jDxknHHJjswhP2uxUQs5xjgkQyESJYSPQo5Twu5VnywSQ1yBIAAAAAAABEuxJTVkowbfZHm/tkYL6lzb3ZcRXPJx9P6Tqa/Tk45UHn5FHUGoqu7bvwtNLhHc6bRm72tOHaHdsoWXi2pmXBPvdHflaVTdFzF9k+Dwz0d0VPXbguZ4S58jzjh1durJMvF55kABzPAAAAAAAZxyR25Akxl1uvJKz+gRlhSw3z2MmpJRbbx5mFesNzG43XQprMlwvDg7dFXnJz+EttVOcvV+F59FrWVDaWZd/G8ZRe/c8PYtrK029TpyWPFiWD3DTqbc5Jly66/VnmQAGhxz4ACfICCJvEXglFVKHrasaS83g9Ujm0QfbNXS639VtuhVfeccsu9djwtkUPo+2rWm1hqPJ7kex9I0NOjBWEnSOKwkAHY9AAAAAAUz7FREuwjyxbwxd1Wpx+m06jXMYlhvmOTI/VWh4qardscGOUl4UXDae+B8y36ONUyT0mf/wAPqfvmQ0+DGnSj6sueMmS/2UV3ca9OaYXPY79em5FgkESOFNpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgDx93/8Fr/unsHjbxfh0Ou/7ptw/JVy6z4L/wCmDrj8tU+bPV2T+kVseVcflanzZ6uyGv8ASO2z2zyXbUfBP+ny7SR/8qv+2b6P1TkWf5FFL6pyLsUa3l9WxeyEoEJ479ycnmG0BDaJysZMgGMnHWr0qS9upGPzeDxa8VjvIq5HHvZ42p7l0vT4t1q8ZY8otMtq+6laUsxt4VcrzaOPLuGDH5tDxN6x9r98ST5aIdSC+tNJfFmItQ6i6jOTdpGCXllHjXm89cuVic4r5Mj8m+4q+Guc9YZ0de3XetBf/cin6Xa4/OKX+JGvlXWdRqpqVxLD9zOm7i5z+c1f8Ry2/UdYntV5nUxH02Mq6hZUlmVxTx+8U0NSsa2fBcU+P7yNc5VbiXe4q/4mI1a8U0riqv8A7jX/AP0ff2vP7mPw2Rd3bY/OKX+JFSuKEuFWh/VGt0a9zF5VzWz++zt0dY1CjhQuJtL3s2V/UVZ81ev3MfhsRGpTf1Zxf8yrKfbBga03jrNq805p/N5PX07qLqsZP6VGDXwR1Y99xW8vUZ6yzHEkx/YdS9KaUbmNVSfmkXJpm6NKv0vVV4xz2U2kSGLccGTxaGyMlZ8S9wHHSr0qqzTqRl8nk5DtreLRzEvYAMozyAIyiW0jIAJpgAARjnIEnBf5+h1cf2WczfBwX7zZVfkas3slifDX3dOVr9wst54Pc6bS9VT1Ga7xhlHh7nTWvXHh7ZPa6ec22pv/AMt/cUP/AM1nB/dK3tVqet1OvVxht9jqs5r388q/M4WR2X3S1z5AAa2AAAGAAHdYAQ7rkcnKKmFQqSfZRZr3qtzLV925jmXhreFe/h4M37xvfoGgVa6ePIw300tPwlvKUUl4XKU+fcSejr00tZYNtx9GG2SWdLGCp2NCKWPxayjmEV4Yxh/ZWAR155nlB5rdV5kAB5awAADuaFSlW1q0pxWfFUSZ1GXT0xsPp2u+JL8k1I69DTrzRD3jjmzNFjSjb2sKSXEVwdhckRSSxkmK5Z9GxV6axVJJABtAAAAAAIl2JIl2MwxPhj/qq39BwvMxlykl8DJvVX8yWPeYyTzDkt20fC+a/qD/AOyyF0p7SMlrsjGnSjlSMlJrBA7p88rb+n//AKqpAhPyJI2E8AAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4+7v+C1/kewefr8fFp1WL84mzD8kObWfBb/AEwLcc3FRPykehtOp6jXreaWcM6mq/8AEK67e0cmhVFT1ajKXZMu2X+WCf8AT5bh/jqo/wBs82kvHQi33aRzYwjp6TLxWlJ5zmOcndkUe8fyfVMFuccC5eSI85ZKfs5Ek/I8N6mUoxi3JpJebPL1PX9N0+lKpUuITx3UXlnPrFrVu7SVGlPwuXDZZlTp7TnNzlWm8vOHJkfqc2es9OOHiZn6h0de6kxk5U9LTi15zRY+vbz1S5j4Luc+efxeS+rvpqpL/d5Ri/izwtV6favY0nX8cKkF+zHllf1NddbmZ8NFvU8ysenqcLmvKE61RSSy1OXByutQePx9L/Ej1aGiaRcTdC+tq9CtL2fHLhHHqHS2hCMrqhX+k03zinLJE2wZL+XjorLzlcWz7XFJ/KSOTPieYtNfA8avta0oS4VeFSL4U/edStY7lpSxYXNKMfJTfc55xxHaWfSpP2uXDTILWndbh0/27yUa0Y9/BHlr+RNtvG3nNRq2FzDL+tjg8zjn6YnBP9q6AdGz1fTrqKcbmlBv9mUsM7sJRn9SUZr+68ni1Jjy1XxXp7oSAGeXgAA5Bkqc4tONSpHHuZD4Cz5nut7V8SzzL2tM3TrGm4+j1/FFeUuS8ND6kJOMdSTbf9lGNVjOOxD548juw7lmxTHdsrltVsNpWuafqNFVKNaKz5N8npRakuGmvga221xXt60alGrKLXlngvTQOod5bVIU9QanSSwsLksGl32t+13RTPE+WYE/ZHblnkaLr1hqlFTpVopv9lvDPYi+Cex5qZI5rLfExJheLPmSUxXOSo3Mg8wDIY4OvqC/3Orj3HYKaqUoOL7M15I5pMEteN0tLXriMV2Z7PT3831P7N/cefv6MaW7buEE0s8I5dlSnF3cFL68eUUK/wDHPaEfPa0vFvvzyr+8cLOxqMHDUKsJd0+Trsjsvua58gANbAAAAAACXbgd1gJ9/cuRBEc9lidY76FPQXZqeKknnHwPB6J6dm6lqPPGY5PM606h9J3FSpUpZgoqLWfMv3pJYfQttNyWZTlnOPeS0x6en/2sto9HRx/ld+echvkJBdue5Eq0AAAAAEnhNmTujenyoureYfhqx4MaUKbrV4UF3qPCM87IsHp+37ehJYklzwT2x4OvL1/h0aevM8vdXfLJXdhkr/Mu8O0ABkAAAADx5gHwih8ora4wUPhBi3hjfqtWkpRprtjJj3yL56r1vDqFKnjvEsXPs/yLhtUcYHzHfZ51TIfSem3F1fJNoyTnPBj7pIn+DZyxx4zISK5uFurNMrtslOnTRCF9YqKV9YqfY4kyApiVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsABCbZ1dUh6y1nH3o7Zw3CbptP3Hqk8WiWnUR1Y5hgLWV4dYuo47VGjhtJqncwm0+Gd3c9KVLXbry8VRnmvPHPOeC64p69N/0+WZ49PV8f5Z72/JS0u3a7Omj0UmeJs+r63SbfnOILJ7jeFkpmaOnJMPp2it1YYlK+AIj2JNbrMIJ5AMAUzSa5WV8SoiTwYmOY7jwdx7a0/WKEoVaajUx7MlxhmK71a1s3UnS8TlRz9Z8xaz2M4vGcnkbo0W21nTp0K0FKSTcGveRGt0EXr107S13pE948rBnb6TvC2lWtIepvvDmTfGSxdVsLnTL2dpcxfij+15M70/p21dfdJy8MoSzLHmi/NZs7Xdm2o6jbxSrxi2158FevgrmrMccWhzTXrj/LFb+KTXxRxXNtb3EHCpSg0+Pq4OepTnSnKnUi4yi8YZT3Ieeqk8Ndb3r4WzqOytHuZ+vhCpGsuViWFk816Zu7SubK8pyoLvF8vH/wC4L44D54ayeoyzHubaamY7W7rHtN8VLSaoapYXDn2lU8OIr4l02GsabfQUqV1SUm8eFy5Oe9sbS9pulcUYuDWHhYLP1XYVKM/XaJVlb1c5zKT7m2PTyeezor6Ofz2XxhtZXYPsY0huLc23bqNHVqVS7oQeHKEHjBeOg7m0vVot060aM/7E3ya76e0d48NWTSWrHNfD2n2yMeYWWs+Xkxk08OOY4GsvIT+BCSfwJMAuAuOwA5HNZXVzZVlXtqso1F254Mh7S6gzc42+qNyk+PF5GNiHysRyvid2l3DLgntPZ7plmrZOzvbe7pKpb1Yzi1nhnZWfgYA21ua/0StHwVHKiu8XyZf2xuex1u1jVpVIwm+HBvnJcNFutNRHE+Xbjyxd7zbxyTF5RT35Ko9iXiWyEkT7Ep5DMW7wywP1JjKG67mTXB0dq1FT1SFPxNetePmy5+r9l9Hvo3XheKrxks7RWo6zaybxifcoGuicep7o/J2u5tyUXR164g8Zzyecz1N1Nz1+4qtYUsM8tkfn98tc+QAGpgC7gAAAAKLmtGja1Jz7KL+4rLX6naj+D9sVpQf41vCRtw16rxDp0uPryxEML6vUq6puOXhbniv7OOeMmwujW9O20u3p04qK9Wm/ngwf0ysvwluun41mOHJme0lGMYL9lYO3XW4iKpbdr9Na4/wMBIEagAAAEM5XAXHIl2ePcZiB7+w9Nep65ScYtqjJSZnqnFRgljyLC6SaNG301alOOJ1l2L/L3s2m9LF1flIYa9NRrLQAJltAAZAAAA1kAAUVPqtlfZFFXik2/cI8vN/bLEXVWfi1yjjuqeP8y0pLK47nvb8reu1x8/V4PAWfWL4vBd9DTowQ+Vblk9TVSyl0mpuOjScly5l9Jcls7Boeo0mC9/KLneMYKfq56skvo2116cEQR7EhA54SIlgAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKJrKaKyl45HPDzaOezDvUu2jQ1iMkseN5+Zasln5l/9W7du6t6qXEVyWFnkuu2Wi+nh8t3mk49ZZlrphc+v0mSck3B4Lwz35MbdI7pQpVqDf1p5RkmOH8ir7hTpz2XzZcvXpapiSREk4UwAAyBEllcEgxwKVjOMDsVATHIx91X0CN3ZK+t6LdaLzOS9xbHTDWla6lOzuZ5oz9mMfczL2q0XXsK9Fd5waMA31rPRdyqnJ+1SqeJ/wBSs7ji9DPGSv258sdNotD3uqOjKxv1fwX4us8JIs7sjL+46Mdf2fG8WM04ORh+OUvaXOSF3PD02i8fbRmrxPKRnI82F25IppAgAOO6oUbmi6NenGUH3TRZW4Ng0atV3OizVtcd8v3l8jzybcea1XTh1V6f6YqsN1bh29eep1uhUuLam3HxQjxgyDoWvadrFBVLWtBTaz4M8nb1TT7TUreVC6pqVOXfBjfX9l6lol29S29cOMYrPq1yzqj080d+0u6Jw6iOJ7SyhJfyZJjzae/4yqrT9bpyo1s4c58JGQLatSuKaq0ZxnTf7SfBzZcNsflxZ9LfFPfwrAXfDHPbsjS5T4Pv7xz7wAHGODn0y9uNPu43FpUcJLuvecGceQ7Rye6ZLUnmrMTMSzHsXeNDVIK1upqnXiu8njJe0JJrKeUzWmhVq0asa1CbhOLymZT6e7yjdxjp+oVEq0e05P63wLZtm7df8Mnl2Ys3PaWROEG0ilNSjnILLE8+HQsPrFZzudLoThFtU5eJmJaNV0qsK0XlweeDYPdFsrnRLqm4+J+reDXyrSlRqypy4afKKdvmHoy+o49RHE8vW19qtZWt34cSqL2n9x47OWrXqVKNOlOblCn9Ve44iAy26rcueQAGtgARLQEAAMweRiHrZqkpanTsYTfgcOcdsoy3cVY0bapUlJRxF4bNctx3tXUtfrOpJySquEePLJIaCnM9UpvZsPN5vP0yJ0S03NpU1FrEoy8KyvIyZ5nh7I02OmaDRpwXhVSKlg9w59VfqyTLi3HLOTNMgAOdwAHcNrIBZz8D0tsabU1PWKNOEXOMZJyXuR5ry+F3fC+JlzpVoH0KyWo1YeGrVjhpok9s0s58sfhtxU6rL10y1pWdpChRj4YRXCO0F2Bf8VIpXphIAANgAAAAAABDWQJOG8ko28+f2Wcy7Hj7quvouk1ameyPeOvVaIc+pydGKZYV1mrKrqty5eVRpHUgm6kF5+JHJcTdW5q1W8uUmzsaHbK81SlSfvReYnowxy+UzWcuptx+Wb9BoqjptulHGYJ/5HfOOxj4LWjD3QSOco2SebTL6vp6RXHEQhc4JAPDeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh58iVnzAAFL4fKKimQFndTLT1uj1K8VmVNcGI4+1HnyM8bmtHd6VWpL9pGDb2HqburS7eCWCz7Ll5rNXz/9S4OnJ1/l73Tu7dHXqVF8KRmak8wTMBaRcfQ9So3Ee6eMGddKq+u0+jU/tQTOPesXReLflJ/pjUddJp+HdXYERZJCLaAAAAAAAApfLwYd6u6TK21SWpL6tbjsZjkWt1I0lanoknx+JTnj3kXumD1ME/mGvLXqqt/pbqMdQ0eppNRpqnDlP4lh7usfwfr9xbKOKcX7Jy7J1Oema7T8HsqpU8EvgXh1a06Na1oX1rT8TbzKUSu3j9xpu/mrnn+dP9MasCPCBX3KAAMgXxD+AAYQTx2X9QSInhmJmJWnu3ZFhrNKVS3jGhc8vxliaTrmu7PvfomoU6k7SMsY8mZmXHnk87XtGstZtZUbqipPHD93uOzDqO3TfvCT02t7dGXvBoGt2Wt2yq2tSLeOYp9j0eW+eyMJappmtbI1H1tlUq/RHLPiiuEs9mZH2bu6z12hGm5RpXCWHFy5l8TObTf3U8Gp0X9+PwuYB5XlkHEi57A5xywEkgHyJpynTqxq0Z+GpB5TRHPvGMLjueq2ms8wzEssdO94/T0rC/n+Pgvyjf1jIUcNZNaKFarbVo16E/BOLzkzL093RHVLKNvc1M14LmT/AGi3bRuXXHp3dmHL1dpXhUjGpGUJrMWsMwR1EsJWW5bicafhozl7PBnjOUWB1b0epd6fTuKMH+KzKTSOveMHrYez3mp1VYl7AJry5BRbRxPDg4AF8eAYYAAYAB90iUjMMx3Wr1O1RaftutGEvxz7JPyMR7DsPwtumlRqRTjLMpP4nv8AWXV1d6vTtqE34IQxPD4Z6vRHSvHTnqc44cHhImMcelg5WnDX9tpJt9yyfTiqVKFGP1YRUV/IqD+s8kkRaeZVe1ptPdAAMPI3xwOI9x8cYOxptnW1C9p21CDm5PDx5GzFSclorDMRzPD3NgaFPWdVTqxxRpYllrhmcbanChRjThHCSxg8nZ+iUtH0qnRwnU7uR7fh5L5teijT4+Z8y78dOmE+ecgjHxJJWG0ABkAAAAAAfzD7FGeQK/Msvqddqlo1SkpYlLsi8s4TMV9Vrty1OnQi8x8PJ3bdi9TPEIXfM/paWZWRl+DLLi6dUJVdw05eF+FJ8lu49l4MidJbKNS3nduOGpNL4ll3K/p4FH2bH62qhkaksRS+BWEsIFNl9RrHEcAAMMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEPLJIbzwjDEqK0U6bT5MGbvs3a6zW8XHrJNozpJeyzGPVSwl6+ndRWIxXJK7Tm9PLxP2rn6j0/q4Or8LDz2a8mZl2DqP03SYLxZcEomGljGPeXt0r1H1N07BvmbykTW74fUxdX4Vn9P6j0dR0z9srIkhfVJRUX0mAABkAAAAAQ3yzhu6ELi2qUZ8qawzlb57DnLZrvWLVmJYa/7y0+Wk7ir06SahF5gy/8AaV3T1/adXTZSUq8KWG/Mnq1ojutPhd21L24NyqSS8ixdgazPSdaior2K8vC2VG1Z0+pmtvEuX2X4nw8nVLOenajVsai9qm+TrF/9U9Ii5U9Utl4lU5m17veWBn3diH1uD0sk/hoyV6bAAON4AAAAAAfcB34MDg1KyttRs5Wl3SVWlLyfvMQbz2vf7YvVqOlTl6nOfZ8vh8jMy/ocV3b0by1lb3NNVISWMPyOrBnnHPE+Hfo9ZOKeJ7wszYG97XUqMbS+lGjXXGZPuy+GsdnlPsYU33tK60C+d/pym6GfE3FcRZdfTfetK/pQ0/UJ+GsuIzk+5vz6eLR10dmq0dclfVxMgduATjC75zymQR8whZjieJB5gBgxy0+TuaNqVfSr+lcUpNQjLMkvNHTx59w/aRtxZLY7RaGazMTy2E21q9HWNNp3VPClJcx9x2tYtVe6bWtcpesj4c+4xB0z1+ppmqK2rSc6dZ+GKb+qZoi1OCa7MvWh1UarBxPlIY7ddWvG4dOlperVrPlxg+Je887v37oyp1c0F1rWnqFpSxOnmVWS80YrT8STKjuWlnBln8OLLSayl8tMnggEc1wAAB5ZOprN9T0zTKt5UeIxTO4lyY+6yasrbTJaW5YdaOUb8GPrvEOzQ4Zy5YhiXVrieo6xXqwfjdSo/Dn3NmwGy9NWmaDRppLxVIKT/oYY6b6WtR3NRVSPiprv8zYCMfVwhTSworCO7XX4iKwmN5zRWsY6pzkBAiuVb55CcEErLlGMV4pSeEjNazaeIClGdSoqcIuTk8JIy9022vHT7ZX1zTxXmuzXY8rpzs6anHUdQg0/2acl/mZNSUIpR7Itmz7b0/8AJd2YcXHeVaWFgkLkFojw6QAGQAAAAAAAAZT28yp9ilBiezhuqip0pSbwsGDNzXk7zV60py8Xgm0jLe+L36FolapGXhaXBhOrL1tSdRttyeSw7Lg5/wCSVJ/U+q4mMUDz4opebSMz7EsfoOkRjjDmlIxPt+zeoarStl3byZz06iqFrSp/2YpHre83/jef0xpu/q/h2gAVxeQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKXy+CocZwBCwy3t9WMLvQK8VFeNLh+4uI4Lumq1CUGuGjbhv0Xi34cusxerhtX8w16lB0qs6cvrReDu6BfPTtXpXa7xeDs7u0+dhrVTxJpVG2jxn3z7mXWs+vg/2+XXidLqufw2E064+kWlKr/bimdmLecFn9M9UlfaX4KrxKD8KWS8MlK1GOceSavp2hzxmwxeDlPDZUU+ee5UaYdoADIAAA0mML3AGB1tSto3dlVtpdqkXFmANz6bV0jXK1tCTUaUswmvM2ILD6q6DG+0/6XRh4Z0vam0u5C7vpPUp1x5hqzU6o5dLZ+oUdxbbqaTcRzVp03HxPu2Y51qwnpmpVbOaaUHiLfmc219VraVqlKvFuFPxe3z5F9780u313RaWt2Phi4x8cvCvrEDeI1OHv7oc8/zr/mGMuVxgERy+X3XdE+fzIO1eJ4c/AADAAAAAAAAA47u3o3dvK3rwjUpyWMMwvv7alzt6+/CFg5eo8WcxWEn3M2LCODUrKhqFpK2uacakGuFLyZ1afPOOePpIaLWThtxPhY/TPecNRpR02/lisl7M2+WX/wD3lyjBG8dDvtq6u7u28caDllTXzzgyN043bT1myja1ni6j3Tfkb9Rgi0ddPDs1ujrePVx+F48t88IeQfL7/wAh8yOQfAEA+AJjOVKaqweJx5T9xm/pzq61LQ6UKlRzrQj7TZg98pcF3dNNXdhq6tnLEazUUiY2jV+jl4n7b8N+meGZb62p3VrUoVFmE44aMDbz0ero+s1oypuFCcvxXufyM/xeY5x5Ft790CnrOlyko5rU03D5lk3PR/ucXVHl05adUMFdlz3YK7ihVtrqdvXi1UpvDyUPuUW9JpPEuCY4APIHlhFScKVOU6kkkl5mvXUDVamq7gqyqSclRk4Qb9xl/qXqsNO23XiqnhuJL2F5swXp9vW1XUo0YvNWrLL95LaHH0xN5WbZ8Pp1nLLK/RrSPVadUu68HGp4vZfwMiN5fc6WhWUbDSbehFYkqa8XzO6sJHDqL9d5lDa7N6mWZPmiFx3KuRTjKpVVOnFzm3hI01pNp4hxRCIrxyUI/WbwviZC2BsqrVnDUdSg4rvGnJf5nc2Dsf1co6hqUPaa4pSXb3MyTTgoQUYrwpcItG17R/fkdeLD92TShGEFBeSwS1z2JkvMLOC1VrFY4h1JQIjnHITyz0JAAAiWeMEkSAhPgNlMpKKy3hI8PVtz6bY+KM7iHjXGD3TFbJP8Yc+bU48Mc3l7ql7yU2WBPqFSU2oUlKK8zltd/W9WolVgqcPOWTpnb9REc8OCN60kzxEr5y35BvCbPP0nV7LUYeK3rRn78HfnzB/I5bUmluJSFM1ctJtWWM+qupS9dTs4SzGS9pFhRWFg9ve9C8o63UldKTjKTcG/ceJ3lHHfOC5bfWuPBzD5nuuS+bU94Xp0v071179PxxD2TK/GFgtnYOlR0/SYvzqe0y5l5cFY1+b1c0z+F72bTehp4j8qgAcSYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiS80SAHkU8lQfYDHnVPSvW2/06PHq15Ixon7HYz9rdjTvdPqUKiypIwXqtrOz1GtQnHCUn4fkWjZtT1V9OXz79SaL08nqx9vY2FqctP1iEalRxoy7+4zLbzVWjGonlNZRr1GTpzjOP7LyZo2PqsNR0mDyswxFnNvOm6Z64dv6a13P/FaVxLsVFL7cFS7EAunPIAAAAAAAA/M4a9GNajOlUSlGSw0/M5ily96PF6xaOJGC+oeh1NL1epVVPwW1V+xhcHodOtfjRnLSb1qVCt7MFJ8IyVu7RqWsaVUpSgnUUfYyuzMEXtrW0vUpW83KFalLhlR1uC2jzddfEuS9Zx25h7m/tDlpupu4owaoVX7L8i2+e3vMk7e1O23Nok9Kv/D9IhHwwqS5bZYmuabW0m/qW1WL8EZYjL3kbrMETEZKNeSv90Oj2AI/awyMae6XwwOE+XyAAAAAAA+VgPL+AAHn7i0m31rTJ2dxGL4bi2vMwPeUNR2pry8LnSlGWePNZ7GxCLX6h7ao69pkqkYKFzTXiUo93jyO7S5+mem3hMbdrOifTv4l2tl7ittf02nLMYXEViUF957xrxtrV7zbGue1GSXi8E4y4ws9/vM+6Rf0NUsKd3bTU4yXOPJmNVp+ieqPDzuOj9O3XTxLteeCfgQ+HwOzOJEme69xzafWdtf29ynh055ycOfeU1U/DwbMNum8SzXy2L25eK90ehcJ58ce56DSa7lm9Kr53Oixt3/2US8uzPouiv6uGJSVZ5iJY56mbTjcwepWcMVI+1NJdzFs4yhNxmsSXdGy1SnGpBwlFSi+6ZijqJs+rbVZ6jp9N1ISfiqL+yQO77ZM/wDJjhozYvuGPyVyUrPiakmn5o8bemrQ0fQbi58aVVL2E13KxTHM26WnBinJeKwxT1Z1z8KazGhTknChmLS952ujuhu81T8JzXsUJY+BYtepUvr2dZpeOtPLS97M/wDT3R46Rt+GOHXSm1jtkl89vRxdK06y/wC000Y/yuJ9+OxDCTzwm2+Ei7NrbJv9VnGpd05UaP8Aa95HYNLkz24rCpxWbyt7StOvNUuI0bKk5tvD47GWdm7JtdMhCvdQVWtjPtLsz39B0Gy0ihGFCjHxL9vHJ7Bbtv2imL+V/Lsx4Yr3lEUopJLCXYct/AkE5FYjw3IfyDTfwJBngF2ABkCMol9ij+ZgV5OrqF3StKEq1WSjGKy2yu6rQt6Eqk5JRistmJd97mrahdOztZuNGD5af1jt0eltqLxEeEVum400mOZny5t2byr3lWVCwqOFOPHjj5ln1p1a0/HWqSqN+bZQuPZSJx7n2Lfp9Jjw1iIh841e4ZdReZtJFJZIcUVA6umHD1T5d3RtUu9KuoV6FSTjF8w8mZi2trNLV7KNWMl4kvbj7mYPLt6a6lK21WFnH6tV5ZC7ro6zj66x3WTYtxvTLGO09pXf1H0qFzpM7mMM1YL2THe0dOd9r1GjUj7C7mZdWpKvZTg1lNFtbA0b6JUu61emlP1r8Da8iK0+snFp5rKd1m3Vzaytojsu20pKjbQpRXEVhHNzjIRCy3yRUzzPKzUrFYiv4VgAw9gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYB9gKJLMcGNOqOjOEo6lSglGKxLBkznB52vWFPULCdvVXEkdWkzziyxZF7ppI1GCY+2BE2+/mXL0/wBXen6rGjObVGXf5nh6pa1bK+q0KkcNSfhXwOBT8DUoyxJNPJcMtK6nC+b4MltHqImfpsPRqRqU4zi8prJylodP9cWo2EaVdqNaPCWe6Lt8RSs2KcV5rL6jo9TGoxReFQIUuQnk1OtIAAAAAUvH9Cojw8YMSIbTRY/Uva9LU7L6ZbwUK9JOTcVzIvnCIqRjKLjKKafdM5dVpq56TWzzasWjiWt9ld3Ol30aizCrTece8yFVo2u89BVSHhje0o+0l7zg6l7RdGc9WsIOUX7VVf2fkWPomq3OkXkbu2nJYftQ9/zKhettLknHk9suTvSeJ8OC8t6lndTtK0XGpB45OJrKw+5kXUbSw3jpX02y8ML+kvagnjLMe3VGta3Ere5h4KkHhoj9Rpuiea+Gq9eFHu4AfHI4Xc43gAAAAAAAACXv5T8gBE8ETxLF3Vza3iX4WsqXtN+1GPZI8PphuitpV+rCvL8TN+GKk8YZmm7oU7m0qUKkVJTi1yYB31olbQtcn6mMo0M5hNLzJbTZIy06LLLoM1dTi9K7YKLjOEakJeKLWUw3hZLC6UbnjqNktMuKi9dRjnLeGy/sc5I/NinHbhCavTzgyTWVOUye48wjTE93LDI/RK6/H3tGcvJYMp+XbJhrpFVdHVK0cJ+PBmWPMS+bLk6tPEJDDPNFMimrThUpunUipRfdNdzkxhe8h8vhEvavVHEtrF+99h1J3ErvSqal4m24rjBqv1r1h1NVjplOp7VHMasU+EzczqtuantTZl9qjnFVaUG4Rb7nz33BqVTVtavNUllu5quePdlld1ehxUydVfKV2nR1m85Je70w0iWqblt6coSlRTxJpZWfibPaFszVbpUoQt3G2iksnZ9FzYNvom0Xf6hZ06la88NWnKay0jNtKnClFRpwUY+5I2V2muaYteXLuV4zZeOe0LS23sbTtMUalX8fPu1JdmXbSpwpQUKUVGK8kcuOCMIl8GlphjisOOKxHgb8vMkYB0wyAAyAAAAhtjLwAw0UyeHkqzwW7vLXKWlWEvFNKc01H5nvFjnJaKw59TqK4Mc3st/qRuP1FP6BbSzOWVP4GNXzy3y+7Oa9uat5czuKzzKTycPDLpodLGDHEfb5fueutqssz9DzjgduF3HlgeR3otIIAZG+D19lSa3LbNe88k9rYdF1Nz2+U8cvJx6+YjDMy79srNtRWIZqpRVShiXuOSFOMFiMUkRSjiCRWlko8z3l9Wx1jpjnyd/gF2x5k+H4ho8tyQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7AMCM+eSJLPBCfkwjEMTHLHXU7Q/EvwlRh7UFhpIx1jLcWufM2C1G2p3NtOlOKkpLzMJ7q0uppOqTpyi/DPLTLNtGs6o9OyhfqLbpx29WkeTauqz0nUoVm8wb8OGZssbmF1bQqU5J+KKfBr5yvn5GQOmevNT/BtzP4xbZndtF1R6lWP0/ufp29K8+WTEv6krvx2KYyjKPHYmGEVlfomJ7wqAAZAEAAAAESJKZpv5GJFFanTq03TqRU4tYaaymYn6h7NlZ1amo6dBypSblUjjiPyMtLHmU1acK1NwqRUovyaODWaKuopxMd3m9ItHDXXRNTutJvY3Nu2vC/ah2Ui9tSt9N3hpyubNqN/SjzFcZfxKeoOyalq56lpkPHTbcqsfd8ix9PvLmwuo16cpU5Qf1feVPJjvppnHkjs45iadpU3trXsa7oXMXGcXg4cYy2X1Ru9N3TQVvdKFK/S/FtdpfMtXXNHu9GuHTuYtwlzGUeVg4s2n4jqr4a7V+4ecsv4Esc9veDieAAAAAAAJeAwjs+C3OoOhUtc0dpxSnRTmmu7+BcYwmnGSymbMV5pbmG/T5rYrxMNa9MubrQ9ZhOSlTnSmvGvejYPbeq0tY0ijd05JuS5wYu6v7cdnefhalFqnWlhpLhHV6T7jem6n9Cr1H6ut7ME32ZKZqRnx9UeVk1eKuswRkr5hmwnyIXOGnlPnIIjjiVWtHE8Lw6Vr/4u/mZpTxEwv0qTesSa8nyZph2LtsXwu7B7U4KZYz7ir+ZaXVbctPa+zb7UXUUatOn7Cz3Jq1umOZdFKTe0VhrZ6XW+vwprFLQdPrfiaLcLiKfmYv6M7Zqbo33Yaf6rx2ni/GPHCLb3HqtXWdbu9WqNydxUcmvmbZ+iPshaPoNbV7ukvWXGJ0ZNdkyIpzny8rJlmNJpun7Zz0Wwp6ZpdtY00vBQgoI7iisZJT7EYfkTUViI7K1M8zzKY9iSEsEnpgAAAAAAABTJvJHwb7Ey7nBeXNO2oTqVJKMYrLZmKzaezxkvFI5l19Yv6VhZ1K1SSXhWeTC25dXq6vfyqzk/VN+yvcenvfcVTVLt0babVvB8NeZbK4fzLTtmg9OOu3l893zdpzX9Ok9oMeQ48h8EEscE4rAAT2DKCSCQwF/9KdMU3Uu6scThL2WWNYWtS/u4WtJNym/JGbts6dHTtOp0VFKSj7XHdkHvGpitPTjytH6d0U3zepPiHqr3FUSl/EqjjnBVOX0OEgAyyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHyBCw+cE/JBLAApkmWvvrQo6nYSlSgnWS4ZdE+5TKKlFprhmzDlnHeLQ5tVp66jHNJa8VacqVaVKonGUXjkUKs6FaFWE3CUWnmLL66kbflTqvUban7KWJJIsJ8PC+sXTS566nF3fMNbpb6LPxDMmydep6nZQhOa9alyi50vjwYE0LU6+k38LqlJ4bxJeWDNOg6nQ1KyhWpTTyufmVvctFOC/MeJXXZN0jUY+i094emsfEnsQnnhktcEUsZHhEkR7EmQAAAh5fYkAQlhEgAcc4QqRlCcVJPumu5j/emxIXbnd6bFKt3UeyMhZWRjPbsceq0mPUV4tDzasWju1ruaF1p95OjWU6NaEseJcf5lzaVuajcWv4P1uMXQa8PrMZkZP3HtbTdah+Pp+Ga848GI9y7U1DRq8/FT8dDPsY5eCq6rQZdLPMd4cl8dqd4cuqbabg7zR5ettHz7T9otySnGTjODjJPHKO5pmq3unVFKlObin+Tn2/oe1Uu9F1mKneKVK7wklBYiRtqUyeO0tUxErYfHKJ7cI9LVdGubNOpFxnSfbwvLPNWc4w18zkvSazw8zEwAA8MAAADsBzn4AefuPTaeq6RWtqkPE1FuHzNd9StrjR9WlRl7FWlLK+Bszxn5GKus+hYlDVaEfanL20l5ElosvE9Ep7aNVxb07eJXZ021uOsaHTjKadxTXt8l0J5eEYA6d69V0fWacE/xdaSjL4Iz5CrGrS9ZSacZLh5NWqwdN+3259z0vpZeqPEsg9FqMqmo3klj2Ussy0Y96NWjoWles19eK5MhcFy2fH0aeOWnDHFIFj3mnvpZdQFrGvR2/p9R+rtJOFwk+GzYjrVvCjtHZ93X9aoXc6b9Qm8ZZoNq97daxqtzqdeEqla4n4pOPPc263LPHTVN7Zhr1dd57PZ6YbbluneVjosac3SrTSk0uEfQnbOl09G0Gz0umklb01DKXfBgP0SNkw0vS62uatCnCtUanb54eH5mxCuref1a0H8pG3RaeaV6uGjc9bTJk6ertDl8sFUeFllEZJ9miptnZxMI+LRKpPJCWGI5xySZZAAAKZ9ioiWccAU/cT8ERnJxV69OhTc5ySSWWZiJmezxe8UjmZTdV4UKUqlSSiorLbMU773TVvaztLWWKCf1k+52d97rlcVJWdlP2V9Z5wWNzzzlFj2zbfGS6j73vXVzixyLj+ZJT9V8ElhiOFPmeZ5lJAJMsIJIABht+HMVlh48y4ti6HPVdRVWcH6im+cruc+ozxhpNpdWj01tRkilYXR000D1FNX9eHtS5jlGQopLyOCyoQtqMaUIpRisJHYKTqc85rzaX1Pb9HXTYorAADnd43gJ5IlyhHsBIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIa5yEiQB1ry1p3FGVOaTUljkwzvDQKukX83GOaEnnJm9rJ5G4dKoanZToVo59z+J36HV2wX/AMITd9trqsXMeYYJT4ye/tDX6mkXsYVJN0ZPB5+u6VcaTfzoV4+znMXjjB56zjK7lstXHqsT57S+XQ5vxMNg9Pu6N5bxq0pJpnZyzEOxdzT0yrGzuZN0JP2X5pmWLavTuKUZ05KSazwyoazSW09+J8Po+17lTV44793NFlTI4wO6ONLcpbwCMkgAG8IiLyBIAAp8ISZUAGF3OKtQpV01UpxkseaOUpXHB4tSLRxIsLc/T+3vPHX09KNZvOHwjHWubc1TR66hcUXJvlSgs8Gwbwjgr21Gsn6ynCWfeskNqtox5O9e0tVsMW8NdrLUbuznlNtrjw1Cq8u6d3TdWpHFx/d7My/rGwtHvpSreCUaj9z4LL1TpzqdKpKdpODguy+BBZ9q1GP/ADDnthtCyPIHcvNMv7SpKFS2qvD7qJ1KkKkOZ05R+aIe2DJXzDRNZhAIbi/NEp57HjpljuBvgZWeO4z7zyC75OhuGwp6lpFxbzipScGo/M75MMRab5NlJ6Z5iWzDeaXizWLUrWtpeoVLdtqpTfddzNvSXWPw3pFLTlLxXFJYlnzZZnWjRvot9T1OnFfj5YkdPojrC03qDplCc/BC4rxjKXlgnqY/3Na8eVuz1rrNLFvuG9Wx7R2e3bWnKOJ+Hk9mrUp0acqlWSjFLLbPO1HVrHTbFVHVg4KPHhfcxxureVbUITt7RuNCXDfngvW3bbkvSK1hTNduuHR14meZY063Q1rqDuj6LCUIadp9Twpr9pN8/wCWP6nR0TYOh6dSjJwdWpy2n2WV2+PvLpisPxR49/xKiyabZMGOeq0cyqOt/U+qzR0VtxH+FcatSFKFKlUlSpwWIqHH3HPaale2k/HTuKj+cmdQnGUS37bHxx0oD93m6urqlfW2N8VY1FT1J+znhpGSbO5pXVCNajJSjJZRr3+0pdsGR+lmqznQqW1aeZeL2V8Cv7nt9aR10WzY94ve3p5JZFiSRHsSV9doQ1ljKzgkpw08swyqzzghshe86Oqalb2NCVSrUSwveeq0m88Q1Zc1cdeq0ue7uaNtRc6slGKWeWYs3tuupe15WllJqiu795093bpr6vUlb28nG2TyvJltYect5ZZdu2vp4vkUbeN8nJzjxSltt+JvLfvIXDbALBERHhU5mZ8nbnzBIYeQgldiHyAyM/BhYa+Ry2lvWu7iFvQWZTeEeb3iscy2Y6Te3TDn0XT62p38LalFtN+08djNO3NKpaXZQpRjFSx7TXmeZsnblLSrRTnFeumk5P4l0pJYTKhuOtnNbiPD6Jsm1Rp6Re0dzzKilPnCKiKWQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKO/BWRhAmOVv7r0G31aylGcfbXMWu+TDmp2VfT7uVGtFpJ8PBsG4potbeW2aGqW8qkIJVlymS23a+cNum3hWd62eNRWb0juw5FvGU+feXdsfdNTTq0bS7k5W7eIvPKZbF/aV7K5lQuIuMl2eDr/AA7P3lkzYceqxqVp9Rl0Wbnxw2GtK9O4oxq05KUWuGmcy4ZiLZG66mmzhY3cpSodo/AytY3dK6oxqUpqSa8mVHV6S+C3E+H0Xbtyx6ukT9uxnHckp8/cTznhnGlkgjn3oRznkCQAAAAB9iGkyRhZAjPkMp8MkeZgUvj5CSWOxV2BiY5HBK3oS+tRpvPfMUeLqW0tIvqjqVqHL93B7+X7gmzTk02PJHeGJiPtZV3060SacqVOcZv3y4PDuemlXxP6NUil8WZQb5w+xOF7zkvtWnv5h4nHSWIK3TTV28wrUjj/ANWut4x62j/UzF5ByUVy8Gj+h6aXicWOO8sPf6s9bx+Xo/1OWh011RLNSrTb+ZlC81SztoSlUrwTS82WTrm/6EfHRsoy9YuFJrg6sP6ZxZJ4rVwanWaXTxzaVq7+6Xafd7Ovnd1Iu9pUZOjHPDlgwLsjpjXo1qN9qkmvVzzFriaw329z4XPxM2atrV/qcs3lVv4Lseen5eRadB+mMOHibIDVfq3NXHOLT9oVutWdvC3VWo6dNYXik2caWO38yfgMFpx4q444rCnZc1ss82k9+MgDt3NjSEkZ7sl8r3ARldnku3pnCT1iE1nwplpPMvZiZO6X6VUt7OdevDmUsx+RF7plimGa/lObHgtk1FbR9L+j9UlFDb7FSylyU19PhJRnC5Zx17ilRg5VJqKXm2WLuve1O3jK3sm/Wt4z5G/Dpr5rcVhw6vX4tNXm0vf3JuSz0qi/FNSn5JMxRr+u3mr3DdWo1T8kuODoXt1cXdd1rio5zb95xY8mWnRbbTDETPlQNy3rJqbTET2EsdgvevMLgErEcIKZ5SuFggAyJAIfwAEkfcTGMqs1TpxcpS4SR5taKxzL1Ss3niCEJ1KihSi5Sk+yMobB2vC0pxvbiP4yXKT8jh2HtONGnC+voZqPmCfkX9GKgkkkisbluXXPRTwvGybL0cZcsd0pKPCROHnkqwRhZILnlcIjiOyF9YqGOQGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJJNckkT7DkmOVqbz21R1S3lUhFRrJZT95iW/s7ixuHQuYOLXZtdzYPGeGi3t17ctdWt2nBKp5NcEvt+42wz028KxvGy1zxN6eWFm8P4lw7V3NdaTWjTnNyts9n5Hma3pN1pF1Khcwbgn7M8cM6K+PYslqYtVT/ClUyZtDl7eYZ60bVbbUraNajNNNds8o9HKxnzMDaFrV5pFyqlGo3Tz7UfgZS23umy1GipTqxpSxypywyr6zbr4Z5jwvW2b3j1ERF/K58rCb7kx5Z16d5bTScK9OWfczljUg+0kRvTMeU7XLSfEuQFPiT8ycjhsi0SkDKBhkAyQ2BIIckR4l7zPDHVCoFEqsEsuSRxTvbWH1rinH5yRmKzPh4nLSPMubl+aIPLvde02hBy+l0pY8lItq/wB/WVGTjCEpY80baaXJfxDjzbjgxeZX08e861zeW9v+UrQh82Yt1Pfd/VT+hS9W/ijwL7WtTvvzqu5fLgkcOzZrd5Q2p/UuCvavllTWN36fYJ+2qr/uss7Wt+XVw39BTpx90iy5KWc+Jv5sIlsG0Yqd7eVd1X6g1GWeI8Oze391fS9ZXqycvmdXHu5fvJalnvwO3YlKY60jiIQeTNfJPNp5O5KxgjINjXwEggMA7PkkpfD58+xiZ4ZiOZVFOG5eFLMvLB3tN0u91CvClSoTal+3jhGQNrbHp2z9bfJVJd18Dg1Wvx4Y7+Urodpzame0dlu7O2pcX9xG4uYtUE+U1yzLVpbwtqEKVNKMYrCIt6NO2pqEEopLg6Wr6xZ2FGU6leHiSz4c8lX1Goyaq696LSYdvx8z5elKSSblg8PX9y2Wl0JTnNTa/Zi+Sx9f33XuPFTsE6a7ZZZ11Xr3VZ1a05Sk/ezu0m02v/K/hF7h+oq05ri8vd3Huu81WUoUZOnRb+r5lvZzLxTy5e8h89uGT5c9yxYNNTDHFYU3U6zJqLc3kWfMlLgpbfYlcdzocgCSAAJIABPySHkctrb17qrGlQhKc3xwjza8VjmXumObzxCilTqVqkadKLlJ8YXcyTsLacaCje3tNSl3gn5HY2XtKlaU4XV5BSrtJ/IvaEFFJRSRV9x3L1OaU8LzsuyenxlyR3RGKhHwpFXuXmGmieUiCmeZW6temOIT5pElK75KjL0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAENZJAJjl424tFttXt3SuKak1zB+5mJtybcvdIrP2ZVKS7uK4SM3v6x172zoXdGVOtBSi+Gmd+j199PP8AhB7ntGPVxzHlr4sPmLKk3F+KMmvky894bLq2tWdzp8fxT58CXYsypCpRqOnVg4T9zLVp9Vj1Fe0qDq9Fm0l+Jh3bbWdQt14aNVxx2yd6juzW6cl/vLa8+Dw8NPuTnnser6PFk8w8Y9xzY/Erst9839N/jZOWPI79r1DlFP1tGb92CwxnyNM7Xgn6dNd71VfEsiLqNT/8PM5IdSbdLErWq2Y34HHuNc7Tp5+m2v6g1kfbI1TqRQb9i1qIp/1i02vzeZjvz7oZwZjadP8Ahif1Bq58yvq46g1Jt+qpyj8zz7nfGpTX4qbiWou/bBJ7jbMEfTVbetVP29qruvXKqad00n8Do19Uv60vFUrtvtlNnTzzhofI349Jix+IcuXX5snukeW85f8AUEkHRFYcvXaUkAHp5AAAJwiCcMCFw8dxxnhB8fAmlGdSXhpxc5Pjg82tFY7vVaWvPFe6HnAbSX/Q9rSts6nqFTHqpUY+9ovTQ9j2lu/Ff+GtLy+BH59yxYvE8pXS7Pnz+Y4Y+07Sb+/qJUaE1F/tY4L40DYcIpVNRcaqfOPcXdCppel0lDx0qUV2zweJre97CybjRXrn/dZEZdbqNRPTSOywYdt0ekjqy25lcen2Fnptv6uhCMIo6upa/YWMJOVxT8S/Z8RjTVt6aldzat5ypQfkW5cVqtxUdSvNyk3nlnrDtF7z1ZJY1P6hx446cML13BvytcqVLT1Km1x4n2ZZ19eXV7P1tzVdSp78nXzh4XBL9y4JvT6LFh9sKzq9yz6mf5yLsAnklnZCP5lABIAgnIMgBggwHn8B789h2eX/ACPb27ty91aqn4XCl/aa4ZozZ6Yo5tLo0+myZ7dNIdDSNMuNTuFQoReW+X7jK+1Nr0NKoxlUSqVscy953NtbfttKt0oxTqte1LHc9vBVdduNs08V8L9tOy009Ytk8iXkuCqP+ZTn4FUe5FLJEcJAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYWckOPuZUDA4501KOJJMtPdG0LXUYyqUYRp1u/iLwfYo+Zuw574rc1lyarR4tRXi8MC6zot7pdaUa1Kcor9vHB56aa47mftR021vqTp3FKM4vyaMe7m2LKk6lxYP2VzGnFFi0e71t/HIpO5fp6+Pm2PwsPyJ4fxOS6trm1k43VKVJ5x7S7nEsPlPBOUyVvHNVYyYbY54tB3yH24HZ9g/ge2swu/mBw+fNACSCQBA4ADIAAAzyGGk/MMGV7xlLuyfCksnYtLi0pJxr2vrHn62Txe/THPDbjx9c8TPDghCdSXhpxcm+yR6Fnouo3LWLepCLf1sFdPVrWimqNp4X8MLP8yqpuHUmsW9X1UPd3ZyXtmyeyOHdipp8XyTy9ey2dGM1Vu7yCguXFnuW1HbOnYnGdF1Iv8AtFhV9V1KsvDVuHJHSmvE8yfJzW0efLP/ACW7Oym4abDH/FXuyVe78s7VeqoW7n5ZRbup701G4f8Au05US1017h3NuPa8Fe/lpy71qbxx4h2r3UL6+ad1XlM6nhSfBVgHdTFWkcRCMyZ75J5mUeXPcLL7kpg2NJhEY5AAkgACSECUGUPhe8L49xjL74Yj7U/Co5k/Ixa0R3lmtZtPEGSuhSq3FT1dvTlUl7kj3dv7U1HUqqdWE7en3y13Mk7e2vY6XSTVKMqvnLBE6vdMeKOK95T237Hm1Exa3aFp7S2VOtThd364k/yclhoyLp9jQs7aNGjTUIR7JHYhFRiklwV90VnUavJnnm0r1ottw6WvFY7qCVH3slok5kkjD8mEsEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7FC5eCsYXuAp7dyGk45ayVtIYQY4eLrO37DUoN1aEXN+eOxjzcWx7qylKvaN1ot8QS7GXSmcFLhrJ2afW5cPaJ7IrWbRg1PeY7teLq3uLWp4Lik6b9z8jjXfOeGZ01bQdOv4SVa2g5P8Aaxyixtb2DUh461nWbS7QwT2n3elu1uyoaz9PZcUzaneFhx7sk799pGpWSk7i1lCEf2mjz/EnxnBL0zUv7ZV/JpsmP3RwkkfAg2tIB37BPPkOWADOA155DI8+QaRKXADCPIh+RUQY4ZTwRhpcMMkyIbHxaAHALD8ieBgYDABghZ8wJRBOURl57BkAy8YxgdhyJIDwuWzltqFxdT8FrRlVl7kjxfJWnunhspivk9scuIjlvC+s+xdGjbL1G9Wbnx26+KL50LaGm2cF6+hCvNftSRGajdcWPtHdM6PYs+eYmezHOjba1LUa6hKhOlFrPrGuDIG3dlWlhCMrmMa9TOfEy7KVCnSio04qKXY5V3wQGo3LLl7RPZb9FsWDB3tHMuKlShSioxikkchXhDC9xHTMzPdOVpFY4hTF5WGVDC9wMcPaE22SAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAKXjyZGE+6Ja54GHkw8zHLqXtjb3dJ061KM4vyaLc1jZOn3tPFGEaEvekXc1jsEsG/HqMmP2y5M2gw5/fDEes7FvLODdrKVw/dgt260fU7Pm4tZwXxM+yimuUde4sLe4X46lGa9zRJ4d4y0n+fdBan9NYrx/x9mvviiuCeJLgzZfbV0mtScY2lKDfmkW1ddPKM5uULmUV5JIkse947R3hB5v0zmxz2nljhr4ZI5Ls1LY2oUPzVSrcnlVNs67BPNlLj3HdTXYL/wByKy7Xqcc+146yngk7VbTr+hLFWhJHWmpReJRafyN8Z8c/bmnS5o81CCPF8x4ljOH/AEPUZaT4l5nDePMKiCPEn2yMr4/0PXXV59O34SCM/B/0IUufMxOSseZZjDefEKiUQm2+E3/I5aVvcVninScn7sHmc+OPt7jTZZ/tcf8AIjnPJ6tHb2tVY5p2cmn2Z3bTaGsVWlVtpRXmabazDX+5vpt+pt/YtxtLzGVjP+Zf9n079ZBOrcyi35YLg0rZOn2rXrYKsvijiybxip47pPD+ns+TjnsxLa29zdT8FvSlUfwPa07aWrXVZRrW86UX5mXLXQ9Otn4qNrTg/gjvwpRh2RG5t5tf2RwmtN+mK0+SeVgaV09pUakalxW9YvODXBdmm6Dp1i06FtCEl5pHq+EKL95GZdXlye6U9p9r0+D21QoxUeERjgqw8ktcYRy8pCKxH0jl/AR7hpr4kpNCGUgAMgAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYAAAAAAADAAAACH/AFCWV2J4AY4hT4ceSKXBNYcUyry4IyYif8sTWJ7cOnX02zrNupQpyb96OtLb+mTfNnRb+R6v8ipcI2RltH20TpMU+YeJLbOlP/uVH/CcE9qaZJ4+j018kXDnD96Jzz2R7jU5I8S1W2/T281Ww9n6dnilH+g/0P07v6qP9C5mT2PX7zP+Wv8Apel/9VsQ2hpsZZ9TFv5HZhtnSk+bOk38j3Se/Bi2qyz5l6pt2nr4q8dbe0pf9yo/zic1LRdOp/UtaS/kei8ruEePWt+W6NJij6cdOjTpxxCKRyJLHb/InKCTNfPP23xSKxxEGF7icAB64AAAAAZAG0gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACM84JGFnIAAAAAA5yCHnyJXYAAAAAygAC5AAAAAABDfJIAAAAAAAAAAB9iFnHIDPOCQAAAAAABhEeFEgBgjHOSQAaIx8SQAwiGskgBgYQBjgQ+H7xjPwJA4FLWCV2JBk4ABlAAAAAAEeEkAA1lgAwAAMgA2gAAAAB5xwRHPmBIAAAAAAAAAAABgAAAAfbghZ8wJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU5zwvILkCoFGf6kr4mORUCnOc/AcvkcsJefIkpWfPyEVzljllUCHkLgycpI8KIXPcOWX8DHIqXCBR8uxX5YMgCO3GScc5AAAAAAABGUYEgpysiXvRlhUnyCM8ZZHflGOWVQI5wQ17zLHKoFLEu2QcqgUrnklYzgMpAIaywJAAAESzgp88MCsFHOcBYb8zHIrTyg3goWUyXn+RkVApzhhZ7mBUMohZXL7jL80OROV7wQ+xTz3YFYxyU5XkE+RAqAZCfODIkFLyn8BlPgCoFLbQbwkzAqBT/AHR8DLHKoFDzjLJa8k2YmeGUtZZJRl5Jbw+DIqBCeSQAAQAAAAAAAfYobfYCsFPYkMJBGHjuMMMpBSsE/MxyJBTJ+SRL4jwORIKVxyyoyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYDjqSp014pzjCPvbwcL1Cw/8bbf/AJEWT14nVh0+1GpSqzpTjQk4yhLDXBoPR1bWZQ8X4Yvs5efxzOLNrIwzxwkNJt9tTHMTw+lrv7D/AMbbf/kQV9YZ/Pbdt/8AmI+av4V1nPGsX/8A+ZnPY61q9G9pVpavfYhLL/GtmiNyr+HXOx3iPc+lKnT8PiU14X554OnqOs6Xp9CVW5vKMVFZa8ayag6p6Qeu2227PSdFUZunT8FWdX639TEmu7l17WLyd1d6jcRlN5cI1HhHq+4ViOzxi2i9p/l2bua71v2Po7l9KvJvw9/AslqXPpL7MjVao1KsoeT8JpzVqTqc1qs5/vPJRCmsN045Xnjk5ba+8+HbXaMde8y3FXpL7QfPjqf4Su39JbZvrcXFSrGPwizTr1NXP5rV58/AUygoP24eH5rB5/eZHv8ApmGW9mg9dth6w0ra7qJ5x7awZA0nXtJ1Ogq1pe0Gvc5rJ81ITlTeaVSVP914PR0jXtZ0u7jc2uo3Xij2i6jwbqbhMeYc+TZo/tl9LISjJeKLUl70T8jTHYHpFbl0uvTtNZhSnYrvNcyNnun3UXbm87KFxpl1FSfDjUai8/I78Wqpk8InPosuHzHZePDJXBTnz8ic84OlypAAAEZQygJfYpXb4EtplLklFtvCXdvsYmTycYKZ1KVNZqVIwX954Ma9UesG3Nm0Z0J1/W3jWIKHKyavdQet27d0zq2qqRt7TLVOVN4lg5cuspjd2n2/Lm+uIbg7j6hbY0GcoXl7BuPfwSTwWFqfpIbBt5zo0a9aVWPD9ng0wqXd9VcpVr64qyl38U2cChGcvZh6yfnhZZwW19p8JSmz0r3tLcRekvtHhOdTP7pL9JfaSkvbn4fP2TT+NrdzWVp9zL5Umw7S6iszsLmK+NNnj91lhtjbsEt1dK9IzYF3Wp0XcVo1Z++PGS/du7+21rzSsr6mm+3jkkfOlpU2uPVyX8mjnpXl/Ra9Rf3NN/3JtHuuvtHlrvs9Z9svppTrUaqzTqwmv7ssnLE0H2R1m3ftZwo29ZXFBfW9bLLNlel/Xbbm550NOvKzo6jNc5WI5O7FrKX89kXn27Li8RyzIDjoV6VemqlGpGpBrKcXlFTa7nXE8uDwqAI8SMiX2OGtWo0l4q1WnTj75NI5ZZ8jBPppXF1b9NbaVrc1beX0qOZU5NNr3cGvJfory94sfqXiv5ZsV/YLj6dbY+0Q+n6f/wCNt/8A8iPmpT1XWFD/AIve8r/msfhXWU1jWL7H2zI/+pR+Ez/RLdv5PpYr2yk1GN5btvslURyucIxzKSive2fNzb+4NTsNw6ff19VvZUbevGpNOq3wn8zK3UP0hNw6rWlY6MqcLBRSU8Yk35nuu4VmOWm+0Za26Y7tuda3Ho+kUHVu72il7lNZLB17r1sLR5+rubuo5N4XhWTSTUNZ1fULmde51K6k5PPh9Y8I6M5Sm81ajm/PxPJovuEz4h149lj+6W4tb0l9mesfqp1nH4xKf9pfaLXszqN/umncYeL8nTcs+5ZK3b1oxzK1qpe/wcGn95kb/wCmYY7NybP0ldjSbV1VrR92Il1aD1p2RrLgrW8kvF28XBoS4Rg0pQ8Oe2UV06tan+Rr1IL+7I9V19o8vF9ox29svpfYarpt7RhVt7yjJSWUlNHd4azlY+B829vbr1/Q7pXVnqNxKcHmMZzeDO3TP0k7mjOnb7vgo0Y+ypU45bXvZ2YtfW3aUfqNpyY+9e7a9cfINJng7S3Zo257CN3pd1CcJLKi5Lxf0PeXCO6totHMIy1ZrPEjfOGUyxHvhL3nh7w3Zou1tNqahqt1CFOHeKa8X9DXDqV6Sd1UrTt9owUqXbxVImjLqaY/Mt+HSZc3tjs2iutSsbWlKde7oQUVl+KaRj/X+tex9FqSheXk8xfPhWTSrcu8txbguXXu9RuKUpcuNOo0jwqtSrW5r1p1Gv7UsnDbcO/aErj2bt/KW5F/6S2yI1fDaVKso+9xOB+kvtFPDlUz+6adRjCfCim/gVeoqLta1H8oGn97kmezp/peGsd24kPSX2h6yLnOp4H345Lk0br5sDVKip213V8fuksGi0qShLFSk4fvLBMJOL/FTcH/AHWZrrr18sX2jHaOay+kuh7l0XWbZXFnfUXF9k5rJ68ZxmswlGS965PmfY6rq1lcRrW2pXUJReVH1jwZb2H6Qe6NFqUrPUlCpZQ7y7ywdOPXxPaXDm2i9Y5rPLdbLwVlgdN+qe2d50IqxulCsorxRqNRy/gX8pJrKeV7yQpkreOYlFZMdsc8WjhIITySnk9vAAAAAANZWCl48ip9ixOrm/rbY+jyuqqbquOY8cHi9opHMvVKTe3TC+G4x5bSXxOOV1aweJXFKPzmjS3cXpHbzvpSpWULeNCWcPs8Fjar1H3RqVZVqt7UhLGGozaRxW3CtZ7JPHtOW8cz2fQr6Zaf+Ko/40Pptp/4qj/jR86v9Ntyf/5Kv/jZC3vuTOfwlcfH22eP6lX8Nv8ARcn5fRiNzbS+rcUn8pIqU6cnmM4y+TPnppnUzdmnxapXk6nP7Uy5NN6/7809JUVQn7/HyZjcaz9PFtnyR4lvRHv8CeHwjUfb3pNa2q0VrdGiqeefBHyMw7N677K3DUp2sLipTuJd/GsL+p0U1dLfbjyaHNTvNWWO/fuSuEdayvrS8pqdtc0qyayvBNM7Hi950xMT3hyTHE90ghNMZMiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wGPuvX6vNS+wl9x8/bf8m/mz6Bdev1eal9hL7j5+2/5N/NkHr/csuz/ABq+PMlpprBDx2x3DzGOER6aRiLn2Oays7q9uY21nQnWqTeF4Y5wLK1r3t3Ss7SDnXqvEUllm5/o/wDSPTNtaRb6vf26nf14qfhms+F/zOnT6ecsuHW6yunr/liXpz6Omsanb0b7cPhhb1kpRjF4kl8UZh0n0dti2Fv4FC4lKWHJuWeTMSSjHEUkvchnt7iZx6THWO8K1l1+bJPMTwsKPSXaKto0Poa8MY+FPCyeBqfo+bFvqdSM6VePj59mWOTLssZ4zkj4f1Pc4Mf4ao1OaO/U1J6g+jZqFnGpX21KLpRWcTllmBdZ0rUdHvJ2l/bzo1INp+KOE8H0wfhlw1le5mMutfS7TN66PVrUaFOnqFODcJJYTOLPoYmOapLSbpasxW/hod3+R6W3tb1PQ9Qp32nXNSnKDT8KlhP+Rx6/pl1ousV9LvKUqVWlNxSksZSeDpdlnzIrm1JWHimWvLc7oR1tsd2UqWiaxNU9WjH63aLX/uZvi1hPunyfMzSr+40rUKWoWc3Tr0pKWU8djeH0feo8d67bo072pB6jTWJJeaXmS+j1XX/GyubjofSnrp4ZVIT8mHx2JXPJJIhEkRj2mS+Xz5B5aWDHIonKMU22opd2zXv0h+tlLRY1dv7crRnecwrTzlJfBntekv1NhtbQZaVp9WLu7lOnPD5ijTCvWq3NadxdVZVKkm23J5ZGazVcfxqmdt0HXPXfw5dRvbvUbmd3fV51as3l+KWUjrPOOOW/ImTioub8jLno9dLq29NXWoX1KUbC3kpZax4lnyIylLZbcJ7Nkpp6c/h4PTPpVuXe1zGdrQdK0g16yVSOMr4GyWzfR32npVKnVvYVal13lzlZMwaLpVjpGn0rGwoQpUqUfCsLDfzO81wveTOHR0pHdWNRuOTLPaeIWtY7B23Z0o06en0GorzginU+n22r+i6VWwpJNY9mCLqfuJWH7zp9HH+HJ+4yeeWD93ejntHUKNSvZKtTu8Pw+1xk136j9H9z7LVW6r0XXtM5j6peJpG+74fB17+ytb+2nb3dGFWE00/FHJz5dHS8dnZp9yy4p7zzD5ldvrJr3p90TF1KUozoVZUppppxeGZ89I3ozW0CtV3Jt+nnT3mVen3l4m/IwF8k0/NPyIXJjtitwsuDNj1FOYZz6Jddb3btzR03cdR1NMbUPEsuSfZG3+k39rqdhRvrOrGpRqxUotPPDPmY/Dw8cIz/AOjB1Tu9J1WG2tVuM6fPmMpvlM7tJqpiemyK3Hb4468bcDPuD55IpThVoxqweYyXiT+BUnkmYV5JgT02v1Z2/wDEoz2YE9Nr9Wdv/Eo0aj2S36b5atOYfVXyJzgiH1V8ipZWW8YK3byu9PbCHx7K5HCS4CTayejtrRrzX9ct9KsKUp1K01FtLKjnzYrWbTxDF7RSOZU6Do2pa5qNKx063qVKlWSipKOUvmbA7B9Gm4uY0626ppReG1SlhmaOjXTPTdkaDRjWo06uoyj+Nm0mk/gZFwuEuEvImNPooiObK3q90taenH4Yn0zoFsWxVP1VGs/AuPE0z27jpJtGtayt52i8MljKSyX7nD94yvI7YwY4+kbOpyz/AHMNa76Oux7+3fghXhVivxeJJIwx1F9HrX9FpTvtFUKlrTTlOLeZNG5qTXLfJTKMaicZxUk+6ayjVk0uO8dobsO4Zsc888vmPd29e0uZ29zRnSqxeGprGTifOE0jcn0i+ken63o1fXNLt1C/opyUYLCb+SNO7ihWtLipbV4uNWm/DNNY5IbPgnDKy6TV11Nf8vf2PvXXtoalTvdKuptwlzCcm448+DZyn6RGjVNjyvY+JapTppVIvt4scmoCxhjy8Em8PyzwMepvSODPoceWYmYXJv3e2ubz1Wd3qd1NUsvwQjJpY+KLbScYuOFhvOQ3hLgmEKsqkKVKDnOclFJLPLNU2teXRXHTFXsqoUqtevGlbUp1aknhRgsszJ059H/cWvqnfaoo0rGflnEjKHo29HbfSrOluPXqEal/USlSTWYqL96NhKdOnTgoU4RhFdlFYRI6bRc97ITW7pMT0Y2GNE9HLY1koVKsbidVd8y4yXXb9I9pUaHqo2mY+9pZL+iTHLefIkY0+OI8IedVmmfcxPq/QLYupxarUasc/wBlpGLt9ejTVo0p1Nr1FiKz+MfdG1GMkY9/Y8X0uO0eGzFrc2OeeXzV3Joeqbd1OpY6nbTpzg8eNxxF/wAzzW/E8JcM+gPVvpxo++NBq21e2hG5inKlOCSfi8ss0W3rtrU9p7huNF1OGKtJtqSXsteREanTTinssWi11dRHE+XR0rUL7SL+ndafc1KVWlLxRUZYi38Ta3oJ10p606WibjnGF5xCMlwmzUiL4+JXaV69pdwu7Sbp1qT8UWnjk8YNRbHZt1eipnr/AJfTmMlKClBqSfmnwyqDyYU9GTqZT3Zov4Ivqi+nWcF43L9r5Ga4tZ7YJ/FkjJXmFSzYpxWmsqgAbWoAAES7GM+uWwbvfOlK1tJQi1HHtMya+SMJHi9YvHEvVLzSeqGn69GbcaS9u3XykVv0ZtwYbVWj4vL2jbzjvyTHLOb9nR2RuGaPEtKLn0Z+oPr5OhXs/Vt8Zl2Ohd+jx1BtJeGo7abxn2eTeVZa8/6kOMJcySb+J5toaTHZsrueas8zL507g2DubQ/FG6sK1WUXh+rptotuvRuqGVc21Wjj+3HB9NKlnZ1Yv1lrQn7/ABU0yw979Ito7pU53lo6dRrj1fs8nNk2/iOay7cO8d+Lw0DXhlHPDRNNyh+RqTpS98HhmX+r/RDW9pTnqOm03W0xdoxWZIxDJOE3BpqS4a80R96WxzxKYxZseavNV6dPuqG6tlXEXp1269BvE1Wk5cG2/R3rDoW96cbOVZUdRhHM1NpJv4GicksYRz6fe3enXtK9sq06ValJSj4ZNJte83YNXbHPdy6rbqZq8x2l9NlLPxTKk14sGGPR06rU946TDS9UqxWrUYZqPPDRmV/5k5iyxkjmFXzYZxW6bKwAbWoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wGPuvX6vNS+wl9x8/bf8m/mz6Bdev1eal9hL7j5+2/5N/NkHr/AHLLs/xq8+Xm+wT5x5+YayU15qFJtL5kfEc9k1M8d2ePRG2TT1zcNXX7qnlafPMM9mbkxUYRwkkvcjF3o3aDQ0np7Y3tKCjO8pRlMykiw6THFccKZr805c0owhhEg63HwcDCGeQBHYhpftc5Jl2I7/A8zA1k9MTZNv8ARVu6hRxVppU2oLGTVxPxNNrDPop1T0Olr2z7uzqwU4qDmk17kfO++iqeo3VKKwqdaUcfJkJrsXTbmFn2nPN8fTP041hSa8i+eiG8LrZu9aFzRqNQuZKlKL7cljfErt6ipXlCvnHq5qWfkceO81tEpPPijJSay+mdjcxubOjXhJSVSCllfFHYz4fkywOgervWunVneOfj48OfkX/5cllxzNqRKkZa9F5qLueZufU4aPoF7qM5KPqKUprPwR6ax/MwT6X+6a+ibPt7WzrJTuZ+rqRT5w0eM1opSZe9PjnJkirVrqTuaruzeF5rFWUnGpLCT7LBbnln+hFOOE0nw+eSrs2Vy9uq3K64qRjrEPR2tpFXX9xWOkUotu6qqDa8j6EdNdtUdq7TstJpwhGdGCUnFdzVH0QdAo63u27vKscuzakn/M3Tj5Evt+KIjqlXd3zza/TBhE4AJNDIwieECGssA0iMN8eRMl7JC4wjEjpa1pttqum1rG8pqpTnFrDPn71e2pc7S3jc2lxHwxr1JTpfu+R9D85fBq76Z+hxq3dvrfg/I0vC2kcGuxROPqSe1Z5pl6fprFjD4OS2qzt7qjcU5Si6c1LK78MoT4Tj7gs+FrghIniVrmOqG/XQHeX+mWxqF9Jr1lHFLHnwZDb5yarehlrXq689D9rEvFPvwbVNFi02Trpypetxellmonl8mBvTa/Vnb/xKM9QZgX02v1Z2/wDEr7j1qPZLxpvlq05h9VfIlLlt9iIfVXyDyVufK719sEpeGLlz2Nr/AERNiUaOlvdFzQjL6THEPEs4aNXNDt1e7gsLKSzGvWjDHzPob0w0aGg7NstNhHChHP8AVHfoMUWvzKH3fPNccVhdC4WCPCiQTcRwrKPCiEkpFQMiGlnIxh+WSSmXv9xiRElGcZRmk0/J9jSr0qdjw25umOpWdF+qvZOpUcVwjdX/AKmKPSi0ajfdLtRvnSU7ihBOD80cmqxxfHy7dBmnHmj/AC0ZeG17iW8vGCilzTXiTUl7yptr5FfnsuUT25M45Mt+jBs3/SPe9K/u6XrLCkva480YjSTkl2y8G53og6EtL2NXqTh+MqVfEn8Dr0ePrujtzz+nimPyzdb0adCjChSiowhFRil7kcqSRT2ZUWCP8Kj58oaQwskgyGAABTLjg1+9LbYcdV2/HWdOoqN3Tl460sfso2CeP5njb1s4Xu1NStppP1lvOKz5ZRoz0i9Jhv02WcWSLQ+bEX3T+snhkv3s9HcmmrSNfutPT4hNs8/3pFcvXieF1x26qxK4+mO47nbG87C8pVfBbusnWWe6zyfQrbOrW+uaJb6latulWimmfM2ss03j6yXBvZ6MGsfT+m9jZybc7eHLZJaDJ36UHvGH++GWH2C7AEwr4AABCjzkkAMIAACGkSAGBhAGBwXttQu7epb3FOM6c4uMk1ng0+9JTpD/AKL1Z7j0Kk5WFSWJUksyTfmbjyPH3bpdtq23ryzuqUakZUZeFNdnjg59Rhrkq6tJqbYLxMeHzYXPbheYaw8s9feOkVdC3FdafVj4WqkpRT92TyHnPJXbRxPC50v1ViXu7B3Bebb3VZ6hbVXTh62PrsPGY55PoTsvXbXcm37bVrN5pVIpZ+OD5r1E/BLD7o3L9ELXvpGyKOhuTlK2Tly8kjt+WYt0oTd8EdMX+2dwQ+Ce6JpXQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD7AY+69fq81L7CX3Hz9t/yb+bPoF16/V5qX2EvuPn7b/k382Qev9yy7P8AGrfbJz6dThVvqNOosxlJZOA7Olf8TofvHFj90JXN7JfQ3pTShR6e6PTgsRhbxSX8i6l2LZ6YfoHpP2EfuLmLNj9sKRk90gAPbwJYAAES7Ed+CoGGOHW1KKen3MfJ0pL/ACPm/vO0VlurUKcXlSryf+Z9ItR/MLj7OX3Hzn6j/pfefbS+8jNxjtCc2af5W/6W9jPBFVYpyS9zJKan1JfIh4WWfw3e9ED9Ttp9rIzH5GHPRA/U3afayMxMs2D4qqLqvnseaNK/S31mrdb8r6TKeYUJKSj7jdGvLwUpTXksmgfpF3Ernq/qdaWeexy6+3FeHdtNOrLysDzIk8RbJeM57FNT6kvkQcLXLaz0K9PjQttSu4wcZVoLLfZ8mysexgj0RF//ABLP/lozuuEWLS9scKXrZ5zSnyIjl9yc9viMnU5AAAChlb7FOePiAXu8zBfpgepfT+unUj63KxHz7mdF72av+mhq1GlcW+lOf4ypT8SRy6yeMXd2bfHOeGsFFP1cc+4lLxciOUknzwS1xmLwV2VzjtDMvod3NaPVn6MpfinbyeP5G7Dzng029DfT4y6gPUXFtqjKOfLsbk85J7QfEqW6zH7iSPcwN6bX6s7f+JX3GeuM4MC+mz+rK3/iV9xvzz/CXJpflhpzD6q+RK78kQ+qvkSVq3ld6e2Hr7FSe/tBXk7yH3n0jtUo21KKXaEfuPm5sT9YGg/xkPvPpLbfkKf7i+4mdu9qs7xP/JEK1nzJAJNDgAAeZD7EgCFks3rPQlX6danShHLcO38y8y3OpH6HX32bNWb2S24Plr/t86dSg4alcU5YzGbXBwrhcHc3B+kN/wDas6a7lav5XfF7UJJ1KSf/ADI/efQjovaQtNjWSpL69KMn/Q+e6/K0vtI/efRHpL+g2nfYR+4kNuj+SG3r2wu7jhskiXYkmYVwABkAABS++TgvYRq2VanNcSi0zsP/AKHFcfm9T5Hm3eJZr5fPnrhb0rTqhqNCkvYRZfnxwi+evf619T+RYxWs3vldtN8VVNRey15s269DW8qVtKvLabTVKCx/U1Gn9U2v9Cv8z1H9xfedGh+SHJu3wy2SABPqmAoXDbQbXGAK8r3goYyORWMr3lOG0dO81PTbNP6Xe0aOO/jlgxM8eSImfDvAtLUeoW0rNvOuWU2ll+Gqi09U667UsqU6kZqt4ZYxCS5NU58dfMt1dNlt4hlh9hHsYKvfSV2tbUHV+g1548o9zypelZtddtFvWsnn91i/LZ+yz/8Aq2Kb44KXFSWJc57mu/8AtV7Yxn8CXxH+1Ztfw5Wi3vfBidThn7I0Oo/9WIfSwtoW3V+4hSp+Gm6KfbgxSmlwzIXXDfGl7+3E9a060qW0nFRaqd+DHj8iD1E1m/NVq0Nb1xRF/JJP+TNj/Ql1F1dx6nYc/iqCf+ZrizPvoOfp3rX8MvvNuh+SHPuvwtwlyuSSI9iSwQqYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfYB9gMfdev1eal9hL7j5+2/5N/Nn0C69fq81L7CX3Hz9t/wAm/myD1/uWXZ/jVnZ0r/idD946x2dK/wCJ0P3jix+6Erl9kvoj0w/QPSfsI/cXMWz0w/QPSfsI/cXMWbH7YUjJ7pAAe3gAAAAAcGo/mFx9nL7j5z9R/wBL7z7aX3n0Y1H8wuPs5fcfOfqP+l959tL7yM3HxCa2b3WW8U1PqS+RUU1PqS+RDQs0+W73ogfqbtPtZGYmYd9ED9Tdp9rIzE/Is+n+KFF1Xz2cV3+bVP3T5/8AX3P+tfUl5Lk+gF3+bVP3T5/9fX/819SOHcPCS2f3SsX6y47kVfybK+zeCir+TZDR5WefDcv0RcraeP7iM7JZME+iK87Uz/cX/QzsuFlli0vshS9b80pwCMjxHU5EghSQ8QEvsUfAqb47HFXq06FGVatNQpxWXJ9kYmYhjiZlx391QsbSpc3NWNKnCLblJ4SNA+u27nvHe9a5cnKNrOVKDzw0Zg9JrrFQr2tXa+g1fG58Tq03xFo1mk225yfik+ZP3sh9bqIt/GFj2vRzWPUsjOFnAxhpZ9qTwkHxy3kyB0N6fXm+t0Uc0ZRsqcvFKs17OU+xH46Te3EJjNljFTqlsP6IW1paZst6jeUJQup1HhyWPZM7ps6ej6db6ZptGytoRhClBR4XfHmdxJ47ljw4+ivClZ8k5bzaUp5eTAvptfqzt/4lGe0sdjAnptfqzt/4lGM/sl60vyw05h9RfIkpp/UXyKit28rvT2w9fYn6wNB/jIfefSW2/IU/3F9x82tifrA0H+Mh959Jbb8hT/cX3Ezt3tVnePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83xy24Plr/t879wfpDf/AGrOmu53NwfpDf8A2rOmu5Wb+5d8XtRH8rS+0j959Eekv6Dad9hH7j53R/K0vtI/efRHpL+g2nfYR+4kdu9yG3vxC7pdiSJdiSYhXAAGQAAEP/ocVx+b1Pkcr/6HFcfm9T5HmfEs18vn917/AFr6n8ixi+evf619T+RYxWs3vldtN8UIn9U2v9Cv8z1H9xfeaoT+qbX+hX+Z6j+4vvN+h+SHJuvw2bJAAsCpqWueCCXyzzdxa1YaBptS/wBQrwpU6az7TxkxaYiOZIrM9od+c4wg5zfhiu7Zj/fnVzau1recpXdK8rQ70qU14kzX3rD191fVrqrp+2a07O3i3GUlypr3owTdVat1d1Lu4qSnXqPM3nuyMz66K9qpnSbVN46rs8bz9JHWdQ9YtvwqWSy1Fy5MW671D3hrSk9S1N1FLvjgtZNpYfmdnSdO1PV7hUNLsqt3JvGKayR85smSfKZrpcGGPDqyU5VHKVaq/E8v233KH4Y8Oq/5yMy7I9Hzc+5Lf1lzXlpq7+GpEzDtf0cNCsqUFq6pXkljxP3m2umy37tGTXafH2hp3RaqS8MM1H7kdu30zUq8W6Gn1pQ96ib42XRbp3aNSpaDSjPHLTPbs+nu1LSj6qhpdKMM5xg3xt8/lxzvMfUPnstH1lrL0y492PCStF1hvwrTLhLvzE+h8tkbbbTenU8r4Ey2Vtt4zp1Pv7jP9O/yRvU/h857q1ubWXguaE6Uv7Mlg4X5YM0+lfpllpW9JUrGiqUHBcIws/IjsuP07cJnT5/Xp1JZn30HP071r+GX3mAmZ99Bz9O9a/hl950aL5Ycm6fA3Cj2JIj2JLBCpAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gH2Ax916/V5qX2EvuPn7b/AJN/Nn0C69fq81L7CX3Hz9t/yb+bIPX+5Zdn+NWdnSv+J0P3jrHZ0r/idD944sfuhK5fZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf9L7z7aX3n0Y1H8wuPs5fcfOfqP+l959tL7yM3HxCa2b3WW8U1PqS+RUU1PqS+RDQs0+W73ogfqbtPtZGYn5GHfRA/U3afayMxMs+n+KFF1Xz2cV5+bVP3T5/wDX1f8AzY1L5I+gF5+bVP3T5/8AX79bGpfJHDuHhJbP7pWPLuUVfybK33ZRV/Jsho8rPPhuV6In6J//APNf9DOz7IwV6InG08f3EZ07Fi0vshStb80pwHhLglduDpalqdhp0PHfXMKCx3k8HTMxHlyxEy7fYnHGWjGu7+su0NCoTnQ1G3va0O9OE+TAnUL0jtX1jNDQaFTTsLHrE8nNk1dKfbsw6HNl8Q2g3fvfb22bKpW1DUaEKsFxSlLEpGrfWDr9qW4lU03b0athbrMZSzxP4mHNf1/WdwXCra1fVLua7Ns83suOF7yMza21+0JvS7XTH/K/eUznOpXnXqzcqs3mcn5spbUMyb/kdrS9Ov8AVa6t9NtZ3VZvCUUZ06Rej5qWsyp6ruCUrWlB4dtUj9b4nNjw3yS782pxYK95Y36V9ONb3zrFKhbUKlKyypTucezheRvJ0+2dpWztCpadptvCniK9ZJL60vNnd2ptzSds6XHT9JtIW9JfW8Pmz13w8ImdPpa4o/yrGs11tRPH0qisIkLsDtcAYE9Nr9Wdv/Eoz2YE9Nr9Wdv/ABKNGo9kt+m+WrTmH1V8iSIfVXyJK1byu9PEPX2J+sDQf4yH3n0ltvyFP9xfcfNrYn6wNB/jIfefSW2/IU/3F9xNbd7VZ3j5YcgAJJDgAAAAAW51I/Q6++zZcZbnUj9Dr77NmvN8ctuD5a/7fO/cH6Q3/wBqzprudzcH6Q3/ANqzpruVm/uXfF7UR/K0vtI/efRHpL+g2nfYR+4+d0fytL7SP3n0R6S/oNp32EfuJHbvcht78Qu6XYkiXYkmIVwABkAABD/6HFcfm9T5HK/+hxXH5vU+R5nxLNfL5/de/wBa+p/IsYvnr3+tfU/kWMVrN75XbTfFCJ/VNr/Qr/MtR/cRqhP6ptf6Ff5nqP7i+836H5Icm6/DZskACfVN0Ne1K10fS6+o3dSMKNKPik2zSTrx1Yv956tW06xqypabSk4SSfFRGTPTA35XtoW+39OuH4Kyca8Yv7zV2MEoJZwQ+t1EzPTVYdr0ccepeERioRSXbyZLaXOcsN548kXP0x2lebx3Za6VQpyjRnL26uMqJHUrN54hNZLxjr1S9bpR0y1vfWqU4QpVLazz7ddx4RuR076Y7b2dZ0la2VN3cV7VXHd+89zZG27Ha+gW+mWdGMHCCVSSX1ml3Pcy+zJ3T6WuOOZVTWa++a0xE8QJYXCSx7kTkn5diEkmdkI7/apAL5gyyPsU+ZU+xT+0JPtpr6Yv6cy/ciYKfkZ29MX9OZfuRMEvuiu6v5JW/bPghLM++g5+netfwy+8wEzPvoOfp3rX8MvvPWi+WHndPgbhR7EkR7ElghUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD7AY+69fq81L7CX3Hz9t/yb+bPoF16/V5qX2EvuPn7b/k382Qev9yy7P8as7Olf8TofvHWOzpX/ABOh+8cWP3Qlcvsl9EemH6B6T9hH7i5i2emH6B6T9hH7i5izY/bCkZPdIAD28AAAAADg1H8wuPs5fcfOfqP+l959tL7z6Maj+YXH2cvuPnP1H/S+8+2l95Gbj4hNbN7rLeRTU+pL5FaKKn1JfIhoWafLd70QP1N2n2sjMT8jDvogfqbtPtZGYmWfT/FCi6r57OK7/Nqn7p8/+v362NS/kfQC7/Nqn7p8/wDr9+tjUv5HDuHhJ7N7pWO+5TPLjJJdyX3YXGWnkhlm4bOejz1A2ztXanq9Q1GlTq+DHgk0me/uT0l9L09uNlpyvF5OLNQJxg0nNchTpR4UsN/BnbTV3rXiEXk2zFe/VMs7bq9I/XtWjKOl0qunNrCaZjTWOoG89Xc3qGuV6sH5Nnkaboesam0tPsKlxns0i6dE6S791KvCNTQbilRf7bR4m2XJPZsjHpsMcTwsWoo1Kkq025VJctt9yPHHxKOeX2Nidr+jFe3nhrajqk7fzcXHsZf2f0L2lotKKvrOjfzj2lKJspo8l57tOTc8OOOK+WnOhbI3Zrbi9N0evXpyf14rJmXZHo1ahfqje6tqEraPeVCcf8jajRtE0rR6XqtNs6dvH3RR6HdHbi0FY7yi8+7Zb9q9lk7J6ZbV2vSpytNMo/SoL8sly2XslhYXZDjzeCqLXkjupjrTwjb5LXnm0pSSDSAPbwAAAYE9Nr9Wdv8AxKM9mBPTa/Vnb/xKNGo9kt+m+WrTmH1V8iSIfVXyJK1byu9PEPX2J+sDQf4yH3n0ltvyFP8AcX3Hza2J+sDQf4yH3n0ltvyFP9xfcTW3e1Wd4+WHIACSQ4AAAAAFudSP0Ovvs2XGW51I/Q6++zZrzfHLbg+Wv+3zv3B+kN/9qzprudzcH6Q3/wBqzpruVm/uXfF7UR/K0vtI/efRHpL+g2nfYR+4+d0fytL7SP3n0R6S/oNp32EfuJHbvcht78Qu6XYkiXYkmIVwABkAABD/AOhxXH5vU+Ryv/ocVx+b1PkeZ8SzXy+f3Xv9a+p/IsYvnr3+tfU/kWMVrN75XbTfFCJ/VNrvQs/MtR/cRqjP6ptf6Ff5nqP7i+836H5Icm6/DZsgk+OTg1O6hY2NW7n9WnFyZ2OxbXU+vOjsPVa0OHGg2icvPESqtI5tEND+reqXGq9RNXrVasp01XfgT7ItV89zua5UlW1q6qzeZSm22dMrWWebyvGnrFccQN4NtfQ22xGy0K81G7pKVWpUUqcmuyNR6v1Vx+0vvPoP0PsI2XT7S5xgo+uoRm/6HZoKc35lGbvl6cfTC+v2iUveRnD5Kic+1YRHsS1lAGQAABlP7RUyn9oT4Ptpr6Yv6cy/ciYKl3RnX0xf05l+5EwVLuiu6v5JW/bPghLM++g5+netfwy+8wEzPvoOfp3rX8MvvPWi+WHndPgbhR7EkR7Ek/CpAAMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2AfYDH3Xr9XmpfYS+4+ftv+TfzZ9AuvX6vNS+wl9x8/bf8AJv5sg9f7ll2f41Z2dK/4nQ/eOsdnSv8AidD944sfuhK5fZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf8AS+8+2l959GNR/MLj7OX3Hzn6j/pfefbS+8jNx8Qmtm91lvooqfUl8itFFT6kvkQ0LNPlu96IH6m7T7WRmJ+Rh30QP1N2n2sjMT8iz6f4qqLqvns4rz82qfunz/6/L/5r6k/kfQOtHx05Q/tLGTQX0kLSVl1f1Ok23HybXc4twjtykdntEX4Y+b5bKZfVclx8Cc+YaXk85IVaJZ06BdJtI3nafTrm+XjglKVJxzg2D0Po1smwglcaRbXUvfKJiL0JdXVa61bT5xUPVQSi/wC0zaSJO6XFS1InhU9fnyRlmOXh6btDbenYVjpFvQx28MT2qdKNKKhCKjFeSK8vOCTtilY8QjpvafMqXlLhEpcEg9R2eVPhYw8fEqAEJccoL5EgwIWfMkAyAAAGBPTa/Vnb/wASjPZgT02v1Z2/8SjRqPZLfpvlq05h9VfIkiH1V8iStW8rvTxD19ifrA0H+Mh959Jbb8hT/cX3Hza2J+sDQf4yH3n0ltvyFP8AcX3E1t3tVnePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83xy24Plr/ALfO/cH6Q3/2rOmu53NwfpDf/as6a7lZv7l3xe1EfytL7SP3n0R6S/oNp32EfuPndH8rS+0j959Eekv6Dad9hH7iR273Ibe/ELul2JIl2JJiFcAAZAAAQ/8AocVx+b1Pkcr/AOhxXH5vU+R5nxLNfL5/de/1r6n8ixi+evf619T+RYxWs3vldtN8UIn9U2v9Cv8AM9R/cX3mqE/qm1/oV/meo/uL7zfofkhybr8NmyLfBZnWlVX0v1z1KbqfR34fmXljOC3epVCdzsjVKFNe1Oi0sE3kj+Mqtin+cPnJU9Z66frc+s8Tzkg7u4aE7bXruhPiVOeGjpFav7pXjFP8IUVfqx/ej959F+k1SFTpzoXgkn4bSCfzwfOmSyvk0/8AM3v9G7XbfWNiW9KjJP6LBU5Je8kNvt/LpQ+845msWZQfKK1yih55fkVR7dyaVuEgAMgAAMp/aKmU/tCfB9tNfTF/TmX7kTBUu6M6+mL+nMv3ImCpd0V3V/JK37Z8EJZn30HP071r+GX3mAmZ99Bz9O9a/hl9560Xyw87p8DcKPYkiPYkn4VIABkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+wD8wMfdev1eal9hL7j5+2/5N/Nn0C69fq81L7CX3Hz9t/yb+bIPX+5Zdn+NWdnSv+J0P3jrHZ0r/idD944sfuhK5vZL6I9MP0D0n7CP3FzFs9MP0D0n7CP3FzFmx+2FIye6QAHt4AAAAAHBqP5hcfZy+4+c/Uf9L7z7aX3n0Y1H8wuPs5fcfOfqP+l979tL7yM3HxCa2b3WW+iip9SXyKimp9SXyIaFmny3e9ED9Tdp9rIzEzDvogfqctF/5sjMTLPp/ihRdV89kp+Rqd6Ze1fodxR3FRpuc7qooyaXY2wfDLX6mbXt917WurCpSjUq+rl6nK/axweNTj66TEeXvR5vSyxb6fOnCxx5DHHi7Hqbv0G+2tuG40fUacqdWnJ913R5fLb9xXbVms8SuePJF45hevRfd1XaW87Os5unaV6qVeS8om/2ianaavplHULKoqtCtHMZLzPmXKLa74M8+jz1kqbbrU9D1qp4rGWIxlJ/U+KO/RamKT0yh900U3/nX6bkNERz5nT0nVLLVbGle2FeFWhVj4otPujt+ImYtExzCuTExPEqgRkZ/oemOUgjxfAN8gSCMv3BPKAkAAAAAMCem1+rO3/iUZ7MCem1+rO3/iUaNR7Jb9N8tWnMPqr5EkQ+ovkSVq3ld6eIevsT9YGg/wAZD7z6S235Cn+4vuPm1sT9YGg/xkPvPpLbfkKf7i+4mtu9qs7x8sOQAEkhwAAAAALc6kfodffZsuMtzqR+h199mzVm9ktuD5a/7fO/cH6Q3/2rOmu53NwfpDqH2rOmu5Wr+5d8XtRH8rS+0j959Eekv6Dad9hH7j53L8rS+0j959Eekv6Dad9hH7iR273Ibe/bC7pdiR3QJiFcAAZAAAQ/+hxXH5vU+Ryvv/I47lYt6nyPM+JZr5fP3r3+tfU/kWMXz17/AFr6n8ixitZvfK7ab4oRP6ptd6Fn5lqP7iNUZ/VNr/Qr/M9R/cX3m/Q/JDk3X4bNkF2RRXp069KVKovFCaw0zlGET894VPu+fnXvbtzoXUTUasqThQuazdPjCwWE+xun6UXTuO6Nvfhe0TV1Ywcoxivrml1WlVt6s6FzBwrQeJR9zK9q8M0ut+26mMuKI+4Uy8vIzz6I+/KOgarU23dzSje1PFGT8jAz4WWclnXr2l1Tureo6VeDThOL5NWHJOO3Lo1OCM1JrL6cQqRqxU4NSg+U15lcTXzoH1w03VNMpaLuKtG2vaSVOnznxr3sz/QrUq1KNWlUjOEllNPyLDhzVyV5hTs+C2G3FocoIT4GWbmlIIzwFL38ASyn9oly47EZWVjuYk+2mvpi/pzL9yJgqXdGdvTEWd9Nf3ImCX5Fe1fySt+2/BCWZ99Bz9O9a/hl95gNmfPQc/TvWv4ZfeetF8sPO6fA3Cj2JIj2JJ+FSAAZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPsA+wJY+69fq81L7CX3Hz8t/wAm/mz6B9e+OnepZ/5EvuPn5Q/J/wA2Qev9yy7PP/G5Ds6V/wATofvHWOzpX/E6H7xxY/dCVyz/AAl9EemH6B6T9hH7i5i2emH6B6T9hH7i5izY/bCkZPdIwmgQlhnt4SAAAAA4NR/MLj7OX3Hzm6jv/wDmF6v/ADZP/M+jOo/mFx9nL7j5zdR8f6YXvv8AWy+8i9x8Qmtm91v+lvlNT6kvkVPBTU/Jy+RDwsszHLd70QP1OWj/APNkZi8zDvogfqbtPtZGYmWfT/FVRtV81hhe/JHdjjHxNstEdmJ+u/Sew3zpc7q1pRp6nSTlCUUk6j9zZpZuXQtW21qlXTdYtpUbiDw1jj+p9LFwseZaG/unugbxs50b62p06kk060Yrxf1I/U6OMnevlK6LcbYf428Pnes+b4JeG0/d2Znjf/o463pdSrPbXiu7ePOZyw8GHdf21rmgVPU6lY1IyTx7MGyJvgvRYMWrxZY7SuPYPVTc+zaila3FW7pRx4aVSTcV/I2C2V6SWi3lGEtyulYya9pR8jUNZXLhKMvc44IxCXtSUW37zZj1OTG1ZtDhzPoRpXVXZWp01UtNVhOD83wXDb7k0evTVSnd03F++SPm7Tu7qjHwUbqpSXkoywdiOua7GHq4a1eRS7Lxs6o3CyPts1PqX0rpXVGrBVIVabTWV7SKvWU859ZT/wASPmx/pNuhJf8A8jv1j/zGS907pfE9yX/w/Gs2xr44aJ2i/Pl9J1WpeVWn/iK4PPZpr3o+aq3Tu11aX/x7U5pTSXhmz6AdKKtevsrT6txUqTnKhFtz79jowaj1J44cmp0c4I5mV2AA63EAAAYE9Nr9Wdv/ABKM9mBPTa/Vnb/xKNGo9kt+m+WrTmH1F8iSmD9hfIqK3byu1JjiHr7E/WBoP8ZD7z6S235Cn+4vuPm1sR//ADA0H+Mh959Jbb8hT/cX3Ezt/tVrePlhyAAkkOAAAAABbnUj9Dr77NlxludSP0Ovvs2a83sn/Tbg+Sv+4fO/cH6Q6h9qzprudzcH6Q3/ANqzpJ8lZv7l2xz/ABFzVpfaR+8+iPSX9BtO+wj9x87lxVpfax+8+iPSX9BtP+wj9xI7d7kPvXthd0uxJD7EkxCuAAMgAAI8/wCRxXH5vU+Ryvv/ACOK4/N6nyPM+JZr5fP7r3+tfU/kWMXz18/WvqfyLGK1m98rtpvihE/qm13oV/mWo/uL7zVCf1e5tf6Ff5nqP7i+836H5Icm6/DZsmACwQqbjr04VYOnVhGcJLDi1lM1X9IPodcQvLjce26cq0ajdSvT8ofI2qy8t+RTUp061KVOpFThLhxa4ZozYa5a8S36fUXwW6qvmNWp1KFedvcU5U6tN4lFrzKPPLeMG8fVLoht3dsJ3NCCs7pLKVKKXifxNcN69C96aA517Sz9fZQ5cs8/0IXLpL08LNp9yxZfPaWLaVSpQrxr0JulVXaUe5k7px1s3PtOcaFSUtQo571pN4Rja+sryyrOhcWtaNRd/YZ1m32lGUX8Vg00vfHPZ1ZceLNHEt0doekVtK/tl+G7qFnWf7KRf2m9Stn6hbK4tdTjOm33Png1B91HJ2qN/fUIqNC9q08eSkdtNwyR2lGZNnxT3iX0ihr2lTUfDeUva7e0uTvxrUpYaq08Pt7SPmstf3BlZ1u8TXKxUfByPc+6k01uPUOO2arN0bh+XNbaJ/tl9J/W0/KrT/xIh1qWE1Up/wCJHzZlufdMnl7j1D/8j/8Acf6U7rkk3uPUOO34xmf6hV4/pGT8sw+mHiW9nKLjJeFdnkwT5I7F5fahfVXW1C+rXdR+dSWTrt+/GSMz3678wndJi9HH0yqkZ89B39O9a/hl95gLJn30HOd961/DL7zdovlhzbp8Etwo9iSI9iSfVMABkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwH2AtrqLt+W5NsXWmQfNam4/1NbY+jJeRjj1k85/tG2vD5T7BvzOe+mpknmXTh1eTDHFWpv+zNeL/tJ/1Oaw9Gu6oXtOu6k/ZeeWbWchNmuNFj5bZ3LPMcS8zaumvSdvWenPvQpqJ6pS2/IqXY6qxxHDhm3VPIAD0AAAB8gAcdzD1tvUp/2ouP9TWPdXo7XWq63XvYzmlUm5cP3m0BTn4mnLhrl9zfh1F8HerUz/Znu/8AmT/qRL0ZbuSa9ZP/ABG2ucPzDa7Gn9ljdP8AU86yOi20amx9j0NCqycpU5OWfmXq/gT8wuVzwdNaxWIhw2tNp6pTHsSQu3BJ7eTCGOAAIklJYfKfkeXqGgaLfRautMtqrfnKmmz1Q+55msT9MxaY8SxPuboXtDWqkpyjK2beX6uKLL1P0XNsuSna393nzWTYrlvtwH3NNtPS306KavLXxLVjVPRhpRcZWVxVk/NOR0/9ma87+OefmbZ594T58zX+yxt39Tzw1Po+jNcSl+OqzS+Ej3bD0W9DqODvdQuof2vCzZPLyS1xyxGjxxLFtxzz9sV7Q6G7R29cU60IO7cOyrRTTMn2tGlb0Y0benGnTgsKMVwkVoqj2OimOtPEOW+W1/dKQFnPINjWAACJdjHnXjYlTf21aWkU5NOFVVOPgZDl2I8855PF6xaOJeqXmluqGpf+zLdxSSqT/nIl+jNeL/tJ/wCI2zeUMtdzmnRY3bG554hq5tr0cbnTdx6fqTnP/dq8ajTl7nk2hpxcKcI+6KRVlsJcYN2PDXF7XNmz3zTzZUADc0gAAAABjnJ5m6dPeq6JcWK71Y4R6YayjFoiY4lmJms8w1S1L0bLq51K5uvHNetqOS9o6/8AszXj71J/4jbTnyIWcnJOjxzLtjcs8RxDU2Ho0XaqQl62fsyT+t7jZnZukvRdAttPk3mlTUf6Htf1IecfE249PTFPMNObV5M8cXO/HJUU8cJoqN7nAAAAAFMl5lFWKlSlDP1lg5Hw+SF3fYxJy1u6j9Arnce77rWIzklWx2Zbq9Ga7x+Unn5m2aJXmcs6PHM8y7qbjmrHTDUuXoy3bWPWT/xIzH0I6c1NhUbqFSTfropcv3GUOSpHrHpaUnmHjLrsuavTYAB0uQGECG/cYB5KK1KnWp+CtCM4vvGSyjk8iJf5CYFu6zsvbeqUJU6+lWsXL9tU1kx3r3o8bP1WE4yq1qDk85ppLBmXj3kN9zVbDS3020z5K+Ja33Xot7ejPFvqF24/Fnh3noxzhWata1SVP3tm1qfxYyaZ0eOZdMbjnr9tTP8AZmu/+ZP+pP8AszXn/Mn/AFNsssnkfscbP9TztTP9ma87esn/AIh/szXn/Mn/AFNs+RyP2WJn+p52pn+zNef8yf8AVD/ZmvP+ZP8AxI2z5Iffux+xxsf1TO1MfozXf/Mnj5mSegPSSt0+16+v6k5yVxTUOXnBmrPHcJvOD3XS0pPMNeXXZctemypAA6IcgADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB9gAKeAO3KD5QYMAj5EGP+jn/KSrOEQu+PeRgcirKxkZWCn5dyZdviBOUMop7lpb36gaBs+5o2+sVZRnWx4FHHJi14rHMvVazaey78oZR17GvTvLOjd0n+LrQU4P4Psc2OOTMTyxPbyqyguOxT2+QT5yzLCc88iTRHmUXFSNChOvN4jTi5S+SPMzx9ERz9uR57kFobS6h7e3RrFfStLqylcUc+LPbgu/PuRit4t4e5rNfKpNJDxIpZC47Hrn/Dx/2ryhlFAHJyr8SCaZSl78k4wwJT7lPAkQORUx28xHh8nE7u19b6tV6XrP7PiWTEzEERM+HK+fMLuRgnHGWZ5Bv+hKawU45+BK88dgy6Oqazp+mOKvK8afi7ZZ3aNWFWnGpB5jJZT+BgT0qqteFtaOhWnTl6+n9V4zyZo2nKUttaZ4nl/RaeW/P2Uaa5Jm/DdbHEUiz1coZRHlwRjy8zc0JlLgPnlEJe8wh1h6n7j2tviy0fTYUHbVq0IScllpN8mrJkrjjmzdiw2y24qzgufPsTnPxOC1qettqNSXedOMn82jl5xybPpp+zu8k9nwR2DMivKIyi2N/b20bZdrQuNZnKMK8vDDwrzPV29q1rruj0NUsW3b11mDfc8xeOeHqazFep6XiQysZKWvcM4PTCrKCkmQ0E03zwxyJ8SGSJN/yIXwHdjn/KckPvlkSlGCcqklGK7tvCOOhcW9wpO3rU6qTw/BJPBjmCIlzL4MhcBLIx7jPIZWCrxFLRKfPIgl513rmnWuoxsK1eMbiSyot+R6Skmk0+GsmufUitcL0ibSnGtONP6PH2VLjubDWmXaUW/7C+404ss2tMT9OjNi6KVtH25soNpFK5ROMLg3ctCfPPkQ8EZaHDHLCcE5Kccc9wuB/wBH/aU0uxGeS3t77v0jZ9lTu9XnKNOb4x3OS13VplztP/SenJ/QPB48+eDx6kcvcUtxy99SROS09i780Pecar0epKSo/X8RjTSeqm5LrrFd7Uq0qH0Glceri0ucZPM56w9xhtPLO3iQckilcDu8m2J5alWU1ghtYwiMYC4fKDHlK95DayPkMCThPHfI7+ZDTC4XJkVZ94yilcB8mBVlYGUilcclNWpTpR8dapGnH3yeEY57sw5M8kSwcdKrTqw8VGpGcX5xeUV9lhozEsccD55Ko9iklPC5DKoAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMADo6xfUdK0yvqNz4nSoQc5474RYdj1l2leWtavSnUSpLLjLiT+SLs3+n/odqeFl+okaxej/tGy3VvDVp37m42kvEoqWEziz5clZ4o7dNhxWrNsn0zhtnrNtLXtS+gW8qtCrnH45eFFO5etG0tB1eOm3frqk3Lw+OnzH+phv0mdm6btm+0ivo/rKFW7k1NxeO2PcXhcdNtBfRmWqVYVKl9O18bqSeX4jTGfPzMfcOmdLpuK2+rM4aHqtprGnUr6yqRnSqx8UcPOCyNz9YNs7f1CpZXNG6q1ab8M3ThlJlkeiHqN3cWWrWFeq5wtZKME3nCyZB1na+zLG4vLvUK1CFW5zKoqs1n+WTd617YuurmnBjpmmlo5epsfe+jbutZ19NqNeF8wm/a/oeb1H6n6FsW8t7TVqF1VqV1mPqoZRgLppe0tM68LTtKuHKyuLh8Rfs9+DZrcO19I12qq+o28asqa4yvIzTLe1e3ljLix0ycT4Y1q+kZsmlKEaltfw8WEvFDB4nVnXem2vysNW3FC+Tkouh6ttZy+MlodR9E0vdPVPT9ubct0qEeLiajwpJnL6Sek0dFtNI0+ml+Jp04t/JnL6uW8zFvDt9DT0iJr5lsDc7k0nbOx7XV6yqfg+NGCppLMsY4yeBPrPtL8Fyv4SqzhHvBLMjzeo+F0KtU+f91pv/Ix56NOw9M3Dpd3q+oudSUKzpqPi9nHyNs5cscVo58eHDMTbIzJsTqltreF39E02dSnV/s1eGXbrGp2ulWU7y8qwp0oJtuTxk1a35pVvsTrjZUNEc6dOtTjJxzxlnv+k5uK6u6+mbSp1JKFf1cp+DvzgRqbRExPmHqdHSbVmvtlf1l132bdajUsqSuFKnnM2sRePiezt/qRtzdle80uy9a3GhJ1G+3hxz/1LRrdGNuQ6ftKnNXEbb1zkny34cmPvRlSjqOswXaFOpBN+5ZRrtqM1ZiLeJbK6XT3pa1PML36OPp9T6i39Da6vI6j4ZOq6rbi+ecF+bh6n7d0HcL0O/dSNysZkvq8mEvR2/XTqb/8uf3nT9JCjO56k0bSk/DOvONNvOD3GW1K/wAWn0qZMkRbwzvpfVLbepazdaXaSnUrW1P1lSS5WDxtQ657SsrpUKlveP2seOMPZX8yvpf0n0PbemzupKc7y7peGvNvyaOrvbbexdJ2pfWcri3VVUZeFOovHnBmcmeKdUsxi0s5OmImWR9ta7Ybg0ynqGnVVOnUWUs8o7uo3dOysat5VTcKUXKSS54Nc/RG1SvPXtX0lVXUtaEM0uc+ZsfXowuLedGoswmsNHRivOSvP25M2OuO/H0svZvU7b26tYudL05Vo17b66qLB2uovUDRNiULarrCqtXDxBQWWYDs5f6LekFcWlOMoUby5UYJLvye36RVda7vvbuifXUa3haXY5/3Num35h2fs6ResT4mGeNI1+y1PbtHXaTdO1qw8a8fDSLKuutO0rbWvwXP17qeLw+sS9hfzLY656rW2v0/s9uWtSNF3NLwZ7YLe/0Q2oui07v8IWz1apbKTl65eLxf1M2z37dLxj0+LvN/+mdNe3Zpuk7XqbhqeOtaxh4sUuZNGq22up1Kh1Prbi1CV7U06VdzpUYttqLfmjKfo06lLcG07/Rb9q4pWcVT59pPuY26eaNY3fXPULGrRjKhSu5RjBrjGTVlvktMTDdp6YaRaLNiafUnRJbLut2To3FOxt8OalHEuT0Ng710neekT1PSVUVGHfxrktbrzYW2n9G9Yo21JQgkuIr4o8P0VVjYN0044a48PyZ0Vy39WKT+HPODHOGckfnhd22Oqu3Nxbnr7esY11eUajpy8S4yu5fvbsao9DljrjqfGP8Ae6n3m1svM96fJbJEzLXq8NcNqxX7YA9LDLtbSKXLrU/vM17S/RrS/wCEp/8ApRhT0sX/ALpar/zqf3matpZ/0Z0zP/haf3IxT5GMnxQ4d5bl0/aujz1XUlN0Id/D3Orsfe2j7w25V13SvWfRabkn41h8dy2PSN/VzcfNlvei5+p68x/zKn3GJzW9WafT1TBWdPXJ9zK89odUdu7m3XX23YRrq8oRcpeNcYRg70k/xfVLTqs+IRuKcm/dyjn6BRx171J4S/FT+9nF6TlFXPUWytpY8FarCEucd3g5c2S2TD1T55SGnw1w6npjxwyxqfWfaOh1bawuXWqT9VBesprMM495fu3NdsNe0inqdhUUqM1x7zGmr9Jds0entdeqqSqUrV1Yyk8vPhLU9EzULmpTutLqVHKhSclFN/Fm+mXLExF/w5MmHBNJtj+pZH3h1d21tjUalhfUbqpVp/W9VDKR7Oxd+aHvCj49LqOMksuE+6Olr+2dmRvbjUNXrW8K1xHwz9bNJ/5mAdq3dtoPXK4tdu1m9PqzjGOJ5i+ecGL58lLRE+JZx6bFlpM1jvDLfpGT2bCx0xbwjcypTqeGiqL8/iXv02jpcNm2MNG8f0BQ/E+PvgxF6YyUtK2/nyuMmUukD/8Al9pmFher7HvHbnUTDXlpEaSLKOpXUTQ9gqyesxrNXcnGDprOPme/pGt2ep6DR1q3f+61oeOLfuMZ+lBoK1jZk7jDbtIOaPO2XuBQ9HmTjVSqWlo1lPnzFs1q3tE/RXT1tjpMeZ8r+2t1G0DcevXujWMqiubOXhn4lhN/AdROo2gbHqW1PWfWuVz+TVNZNY+jGr3Fl1IsaleNSK1WtmMscMvrre47m6s6BpEX4owm0/caY1dppzPl0W0ERl6Y8M53W7tIttr09w16vq7SpT9ZGMniTXyLU0brRtPU9UhYU43FGc3iM6ixFmJuplzS1zfmg7Oq3X0ewtvxVZ+Lwxwvee91o2ltez6dyvdJ1K0+l6fCMafq60fE+V7vMzOpyT3ie0MRpMUcRaO8rz67dQLHb22naeGvO4vIeKjUpLhfzMUdAOqOm7XstQt9bjf3Ne7uPHBxTnhPyZcNleW+5+h1W6voxqVrOlGCk1lo4fRQ2/puraFqta+oQqunc+GDcefI8RfLfJEx4bJx4ceG1beYZU3n1U27tOjZVdTjXSvIRnTUVyk+x7ut7q03SdrR3Jc+N2cqaqLC5w1kwJ6W1OFLUdNowXsw8GF7uUZC6lLPQi3T/wDDU/uN9c9+bRP05rabHFaTH9y8One99H31pNXUtH9YqNKo6cvGsPKLn8zCHogNPYd74Vj/AHqWTOCOjT3m9ItLl1eOMeW1K+Ia4dSuPSOtG/O2j95sTZc2dH9xfca7dSf/AKj7T+Gj95sTZcWdD9xGnT/LZ0av4aLG3P1X23t3d1PbOoRrq8qNKLS9nnsXbresWmkaNPVLpv1EKfrH78Yya++lDoittwabuPHhf0qnFyx8S4+u+5fD0n0+vQmnK58NJqL5eYnj9xaOrn6bP2tLTTp+/LJOw976NvTTvp2kyn6tSccT75TPK1rqrtvSd4R2tcRryv5SUfZjmOWYe9F7Uq9hq99o1eMoTo0XWw+O/JO2rFbr9IHULtx8UaCU0+/Zr3HmuqtMR+ZZto61tb8QzDvHqlt/a967O+pXFWrFJtU45wmdrYvUbb+75Tp6dOdOcFlwq8Mp17a+0/wlV1bVatGnWqwUZqpNJPHzNctRv7HROtttS27XzbV7mMZeGfGMr3Hq2bJW3Ez2eaYMN6TMRPLNvpCrZz0O1nvH6V9Hg26aoNp/5HPo9bbMuijrW0a/+j/0Z5i37fg8y1/S152hat98P7jm0D/6Xai//wBKR5tbm0vNY4pH+3e9HdbHdC7q7NjdpT5q+vbeflkxFS1S20n0gNW1C6f4qlc+Jpd+5fXog/8ACbvt28vmY4r6HT1z0ib21uJNW8rrFRJ8tZNd5maxw34umMk9XhsPtDq9tbcury0uzdWnWjLwr1nCbLu3Zr9jtrQLnW9Qcna20fFPwLLwa1dddsWXT/cej6toiqUoKXiqPPyMndRr96n6PNfUJvLr2sZvJtx5r9Mxby05sGLqiaeJXn0/3zo299PqX2jes9VT+t41g8vQOq229b3VX21Zxr/TqNR05eKPs5XxLI9EzK2hcvHeKwWN0kUf9fGp4X/e5Hv1rdnj0ac2/wANrZZUXJvsuSwtG6sbZ1XeUtrW3r1fqTj7SwuC/GsqS9+Uav7rs6e0+vtjdxj6tV8yk155PWbLbHES86bBXLMx9s+783ppGzdLeo6s6jpqSjiCy+Tvbb3BY6/pEdSsW3QlHxc9+2TAXpP6rWvnZ6PbPx/SKKq+Fcnu+jpr8V0zv5XEn4qDlT58sLBqjVT6kV+m+dFxh6/tfe2+qm3Ne3hU2vZKs72Cbba9njvyVb26o7b2peqyvZVLis1lxo+1gwR0mf4LWt7xkvFONarSjNeWc+Z7HQjQtB193+5twajQ+k1K06cYVqq4T+DPFdVktHH22ZNHipPV5qzjsre+i7ttvW6bUaf9ib9r+hiT0ouoFK3so7YsFdUtRjUU5VI5jHw/MteFxZ7F66Rt9GvYVrOtTTxCeY5l8i7vSxsLN7Js9XVBfSqlWKc0ucMWy5L45/LFMOHHmjn2qeifVjRbTbNPSLmlf1bmlmc5yi2v6mRdk9UNu7u3FX0LTFWV1Rh45+OPGC0ejO3tNh0vqXqoQdd05e14Vxx//ZY/o1+H/XNrPHKpSXBnFkyxxEsZ8eG3Vav0zp1H33o+w9Pt73WY1ZU69RU4erWXk9ja2t2m4tHparY+L1FX6vi7mHPTFUXtPSlJZ/3teRf/AENWOnVh8jfTLac3R9Oe2CsaeMv2voEeQR1uPlIADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH2AA8Df0nHZ2qPzVCX3GCfRI/Srcny/wCqM9b5hOe09SjTpupJ0JYiu74MHeinp+o2m6NyVLzTri1pz/JupBrxc+RxZY/nDrxT/wAVlfpgfne2vtJfei/67cehsZeStEyx/S2sdQvLnbkrGxr3ShUl4vVxz4eV3L8r29xLojG39RUVf6J4fV49rJq4n1MjpmY9LF/v/wDWKfRe1KOj6Zu7Uqi9ijNt/wBTp7P0q/6vbr1O+1i8qfg20q4jCnJptPJ6fo37cv7zSd2aZqFjXtI3MsR9bFpS5PF2vPdXS/cup6Xa6bcXNC8qPw1IU8xWPiaO8Yo6vDpmec9px+Xl7M0aw0P0h7CxsPWepp1XFeN5eEzZDqrueO1dn3moRknXjxCCfLya8bK0fcq656bq2pWFd0rio6nrPA8Q+DPX6/7g1vUt4W1vZaLf1rG2bjV8NNtSa9x7reK1n/LTbFbJljn6X/6Pezp2dldbj1OCld6jU9fSbXMUyyfS/eNTsOVz4F/mVad1j3DZWdtZ0tsamoUvDTWKL7HH6TFvqus0dGu7XTLqvOtSpymoQbcW35nqt62pxDzfFemXqt9r/wCo/wCom2/haf8A6Tx/Q7knsTUP4ts97qLaXc+iNvbUrWrUrq2pp04x9rKXuPL9EiyvLLY9/RvbKtazd22o1Y4bWDZWJ64c9p/4p/3/APqxPSDbfXnSs/8AJgdfrn4rTq/ot7Ui/VOhTivdng9Pr/p+pXHXDS7i1025r0o0YeKrCL8K/mXh122Fd7i21ZalpsWtQtqcJcrL4RotSeu8u2l69GOJ/wAsn3tRPZlWomsOxbXP901w9G151nX/AJVv+py6bvXqFqG3rjQY2Vxb1rek1OrUpYTilzyzg9GJSnqGrxUW6jpVPFhd5YeTxlydd6xDZhwTixXmZ8uT0dcf66tU9/qpfecfpApz6t6aovwt3NPn+Z6PQDTNSt+smqXVxptzb0JU5JTnBqL5ODrzp2q1+rWm1bXTLivRVzBupCLcVybuOzj5/wCRmTqput7T2M7uGfW1KHhpv44ML7J2A957TvN5bmua9WVWnKVOMKjSTXvRmfqxtWpunY30Oml62lRUop+/BhDaWuby0TbVfZENMuklCUI1PU5jyec3mOpt0nPTPRxy7vok0KVrv3X7ah+ThTxF/wAzZ9Pg1r9FbRtZ0nfmux1W0rU26axUlDEZcmyeHhYa+J1aXtVx63mcndrp6R1jDQt6be3FCC5ufFUaPD2BXqb46s1dSlF1KVpVU488L/8AcGUfSV0qhfbLq3NVxU7aDlDPvLT9EDb9a00+81W4pezdRTpya78nLNJjPER4l31yROlm0+YdL0yLedaroUlJxp5fix5FW0uiOm6xtmx1CVe6zXp+LCrPw/0Mp9ZdkU947Zq28Ir6XCD9TJvhMxBtrfO99jWMNuahpV1eRtl6ujOlRbWEzOWlYv8Aya9PkyTi4xsudK+nlnsO0u6do2/pHMsv4GD+muF6QmpJNfnsvvNidhavf63oyu7+3nRnKH1ZRwzXLfOh7j2H1RlufTrGvdUq9Z1GqMPE+TZkiKxEx4asPVe1onyzf6Ref9UesfurP9S1/RV9Wtg3bg+3f3dmXRc07vqH0xuLO5t521a5ppuNRYZg/Zd1vjZNS/2xY2VdxqzajVVLMUjze3TljJ9cNmKnVhnFz35djoco/wCuzUnn2vpk/wCmWbVy8zVvoVomt6d1SdxqljcKVxUlOVXwYiss2la7m3ReyWrcuPUrx+Gv3pY/mtp9tD7zNm08vbWmZ/8AC0//AEown6WP5ra/bQ+8zbtT9G9M/hKf/pR6p8jRk+OFjekWm+nNxhNlvei61/qdvMdlUqfcZK6h6F/pBtq40/GXKLa+eDWzaF7vrZdK82paWNxK2qzniapcYf8AI1ZpnHmm7q00epp6448xL0vR/al141JxaaVKZT6SMfF1U0rHlc03/mjl9HLQdd0vrHe1tUs68Y1Ldy9a4NRbZy+kVpeq3fU7TKtpp1zXpxuabc4QbSWV5miKz6H/AG65tWNXz/hn/cP6B3n8A/8A0mvHox3P0CnrV/nPqKdSol8smxW4Kc5bHu6cYSlN2LSily34exr96N2ianUpa1Y3mn3ForinUpxlUi13b+B054nmOPwj9PMdMxP5dHadnedZN6XVbU7qorCi8+CnUcfM8q00S02515ejaf4/o1CpDHjl4pP+Z3dAtt2dJt3XlChY17undZhTnSg5JNvuzg03TdzVurtvr2rWNepK4rRzOMHiPPmcUxz08+UpX+M2mOOnhfPpif8ACdA+3/8AYyj0j42Bpq/uGNfS5sb+80rQY2NjXunGv7Spxz4exk3pNQq0NhabTrU505xprMZLDR3Y4n9zz/hGZpidHEf5c/UnT/wnsrVLNL2qlFxXwNVdB1atZaDq+zvWL1ri6cIvnJuXWpQrUZ0prMZLDRqHqO0NUh6Q0ZR025en1Lte2ovw4z3Zr1lJ6o4+27br16bdX09ndGhz29p+xdSoU1TlQj4q8vdwcvSl1N29Ua2rzTqKyq5TXZZMp9dtvTuOn1xKxoSq1LSl+LhBcv5Fp+iXty703SL281C0rUKtw1Lw1YtM0ehPqRDojVV9CbT5Y63voy1jrjT0u8c6dC6rv2ovwvGfJmRl6P2mVI8XVzOD5cZVm0/6nd679P8AU73ULXdG28U7qy9qa85P4Fu6b1Y3lb2MdPq6LfSuoYj6z1Lw/wDI9TjpW89bxXLlvjj0/pd+49oW2zekuq2FovDCok3l5PD9DjL27rOU8fSjJF3a3m7unc7S7g6dxcUsyUljnBgjpnqO7Onm5rrQFpl1Vta9w36yNPMcZ9+DdPGO1Zjw54i2Wlony9X0vM/hPT8d8x+9F+9S5+HoRbtvH+7U+W/7p0evuzrzde1qOq2lNu7pwjLwY58jGOo6v1A3NsqW2K1hXpQox8CbotZSXyNNp9O1uft0Yq+rSkR/b5ZG9EJY2HeJf+KkZuXkYY9ErT7/AE/Yl3b6ja1betG6axUjhv4mZ0d+jiYxViUbr551Fphrj1I/+o+0/ho/ebE2f5lR+zX3Gu3Uj/6j7T+Gj95sVZfmVH7Nfca9P8lm3VfFRiz0k9IeqbJg4RfioVfWdvcYSstSqbt0XRdEhUc3b3sXOOfJG128dPpaltu+oVKblmhPwpe/DNZvRr2pqVv1Ov8A8J6dcU7eHilTnUg0u/BzanHPqRx9uvR5axitM/Tt7yctm9TdVvLbw0berYRhzFd/CXB6N9Fwt9Q3hXhJupTllvzSKvSu25fXNpaXdhZVrmVWqqbVGOZJfHHkX10b23Us+ldLSbik6NWpTcZKSw1k8Uw2jL2+nvLqKTgj/LEilqXV3qZe6XO6nT0yzficYSaeC192ba0va/WPSbDTFV8ELuH5SWX3XmXH9B3L0r6iXl7p9hXu7e89j8XDxefc8PW9P3Xq3VLSNwXmn3E7etdReFTfsYa7mO3V/lmIv0fXDKHpafoha/J/cc+3ln0Xp+J97KWf6nB6WTb2haYynjt/I7e16Fav6McqFKlKrVlZyShFct+43eZcUeyP9vF9EBY0q7x7v+paGguK9JC+TaTd3x8S9/RJ0/UbLSrpX9jXtZNcKpBrzMa67ou6LfrRrG4NN065ULS48al6t+38veebdqxLbSOrJMMg+l3KE7Swts/jKnEUz2dzUpUvRhjSmn4o2UU1gsS2st2dUt66fW1yyrW9pYT59ZT8PiRn7dO1YansOvtm3xCM6Xq457HrH/yRMw8Za+l00ljL0TZp7QuV/ZRY/SPH+vXU2n/3uRxbRqb12Bfaht2xsa9T108U6qp5isHa6MaLr9j1TV3qtjWcrio5zq+DEV8zXW/Noq32wzWs358tqcGvXpU6c6GoWW46cGp22I+JGwreMpmOvSD0SrrPTm9oW1GVW44cFFZZ26mk2xcQ4dHkjHmi0sSbYrUt59S9Eu1+Nt6WnShU93ix/kW5U1GrtC21jSJy8KuLybjFccNl+eiXtq8stJvLnULKvbV6dVwiqqw2seRavpDbO1at1Lsqem2Vepb1MSnUhDMeWRs47Rj6vtMRmpObojwuC02+9L6EX0YUvbuK/rlxzyy2uinS+y3ptmvfV7qvTqxruPhhVccJfA2UtdAta+zaGl1KeFK1UWv73hNfray3n0j3FXVvQq3unVpuajRg5YybcmGK2i1vDnw6ibUnHTzyvbQ+hGmadqVK9c6k502mnOeXwU+lpBUem9lTzxG5hE73TrqFuTcG41b3Wl3VtaSjnNSm1z/Q9j0gNr3O69kOyto5q05etS+KRviKenPQ5rTk9WPUdTo5LPSGco8p0pfcYx9G6WOtGsJtL8VL+fc9DoXuLcVpSns/UdJvIUVmKqSptR93c8ndmibn6ddRquu6JZ1a9CukmqcPF37mrr8W/DfGGebVn7heXpiNLaelLP8A3uJfvQ79XVhn3GBOpdTfW99Jtby7tK30OE1JUfV+2mjP3RKlXpdPLGncUKlGos5hNYaPeC3XnmzxqaenpYpz35XuPMldin9okkSqQADIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADSfciMIx+rGK+SJBjgUzhCePFGMsdsonwRxjwrHuJA4FMadOH1YRj8lgh0qbeXTi372it8oLsOBQqVNPKhFP5B0aTeXSg3+6isDiDlx+oo/wDJp/4UVOnB94RePgVAcHKHGLWHFNfIRjGP1YpfJEgcCmUIN+Jwi2vPHJbe+92WG0tMV7fwcqTko4Rcx4m6NtaRuazdpq9B1qX9nODxkiZjivl7xzWLc28MVb260aAtu16Wl0Y169xTcPDTw2so4PRa2tc2em1teuqU6M7ipJqnNYaTZeendG9hWFyq9vpbU4vKzPPJftnbUbWjGjQhGFOKwkkctNPkm/Vkl2ZNTiik0xR5cvgguVGKfvSDhCT5jFtebRUEkjt4cCEljDRT6mknn1UM/IrD7DiBSoQjnwwis+5FFSapUpVJPiKyzk/Z5OOpCNanKnNezJcoxPbwf7a1dZd2Xm+N22+ytEo1XThV9XdTSzHDM89PtAp7a2tZaTDGaEMNo4dF2Tt7SNYudWsrTw3VxzUnLnJcsFwc+LDMWm1nVmz1tSKU8KmslDo0m8ulB/OKKwdPDlQkksJJL4ESp05fWhGXzWSoDgQoxSwkkvgil0qTeXThn91FYHApVOEeVCK+SJlnBJEvmY47DX70sfzS19/rqf3ma9q/o1pf8JT/APSiyes/TzUN8UqMLK8pWypzjNua74Zf+jWsrHSLOylLxToUYU3L3tLBopSfUmXRe0TSIh3sZ7lDpUm8unDPv8KKwdExy51KpwTyoRT96QcIN5cIt+9oqA4DC8ymMIR+rCK+SKgOBS6VNvLpxb+KI9VTzn1cc/IrA4OVMoQksTipL4rJKSUcJJEgzwCXBT4IeLxeCOffgqA4ENJrDSaEYxisRio/JEgxwIaTWGk0U+po5z6qnn91FYHECFFJYSSXyI9VTzn1cM+/BUBxAhxi+6TKVSpL/s4f4UVvPkBwKYwhFYjGMfksEef8ysoxzyZjtLFu8NcepTX+0daJJ5+jRy/5mxVl+Z0f3EYu3Z0z1TV+q9Dd9vqFKnbU6Kg6Tjy2n3yZUoR8FKEO/hikzlwUmuS0y69Rki+OlY+la5WCFThF5jCKfvSKgdLlRKEZfWipfNBKK4SS+RIHApnTpzeZU4yfxRxXDo0qM6sqcMQWXwc0uxx1qUKtCVKpzGaw17zzarMT3ax+kFuaW9db0/auiUKkqtGtitJLKwzPXTHRqmh7KsNMrpOdKHtLBTpuxds6bq9TVbSwUbqo8yk+clzw7YNGLFaLTNnTmzUtWK0hMYRisRio/JEerp/2I8/AqB08OVTGnCP1YRXyRUAOBQ6VJvxOnFv34JVOC5UIr5IqA4AhpPukyQZFKhBdopfJCUISeZQi38UVAxwGEUyp05fWhGXzRUBwKY06cfq04x+SJaT7pEgzwKVSpxeVTgn70hKnCT9qEZfNFQMcHKhUqf8Ay4/0RUopLCSS9yJA4AAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACHHzRIAjDCWCQAAAAAAClReSoAQ4+4RWCQY4AAGQAAAAACJLKJAFKjxyx4Soht+QEgAAAAAAAAAAAAAAAAAAAAAAAAAAQ0SH24Ap8PxJSwSgYAAGQAIb44Akp8PPwKl2AEeFBLBOQYAAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIl3RIADzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDWSQAXCISwSAAAANZCWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k=');


SELECT 'Functions Demo' AS '';

SELECT
    EmployeeID,
    fn_full_name(EmployeeID)          AS FullName,
    fn_branch_name(BranchID)          AS Branch,
    fn_manager_name(EmployeeID)       AS Manager,
    JobTitle
FROM Employees;

SELECT
    ProjectID,
    ProjectName,
    fn_project_status(ProjectID)                         AS Status,
    fn_project_duration_days(ProjectID)                  AS DurationDays,
    fn_format_kes(Budget)                                AS Budget,
    fn_format_kes(fn_total_project_funding(ProjectID))   AS Funded,
    CONCAT(fn_budget_utilisation_pct(ProjectID), '%')    AS UtilisationPct
FROM Projects;

SELECT
    LicenseID,
    OrganizationID,
    LicenseType,
    LicenseStatus,
    fn_license_is_expired(LicenseID)      AS Expired,
    fn_days_to_license_expiry(LicenseID)  AS DaysToExpiry
FROM Licenses;

SELECT
    OrganizationID,
    OrganizationName,
    fn_org_compliance_score(OrganizationID) AS AvgComplianceScore
FROM Organizations;

SELECT
    b.BranchID,
    b.CountyName,
    fn_employee_count_by_branch(b.BranchID)  AS Employees,
    fn_incident_count_by_branch(b.BranchID)  AS TotalIncidents,
    fn_open_incidents_by_branch(b.BranchID)  AS OpenIncidents
FROM Branches b
WHERE fn_employee_count_by_branch(b.BranchID) > 0
   OR fn_incident_count_by_branch(b.BranchID) > 0;

SELECT
    d.DonorID,
    d.DonorName,
    fn_format_kes(fn_total_donor_contributions(d.DonorID)) AS TotalContributions
FROM Donors d;

SELECT SettingKey, SettingValue,
       IF(ImageData IS NOT NULL, CONCAT(ROUND(LENGTH(ImageData)/1024,1),' KB'), 'No image') AS IconSize
FROM AppSettings;

INSERT INTO Employees (EmployeeID, FirstName, LastName, DateOfBirth, IDNumber, Gender, BranchID, JobTitle, ManagerID) VALUES
(106, 'James', 'Kariuki', '1985-03-15', 'ID-44631', 'Male', 19, 'manager', NULL),
(107, 'Fatuma', 'Hassan', '1991-07-22', 'ID-33722', 'Female', 1, 'expert', 101),
(108, 'Peter', 'Kamau', '1994-11-08', 'ID-22813', 'Male', 22, 'associate expert', 106),
(109, 'Lilian', 'Achieng', '1989-05-30', 'ID-11904', 'Female', 42, 'subordinate', 102),
(110, 'Hassan', 'Omar', '1987-09-14', 'ID-00995', 'Male', 1, 'expert', 107),
(111, 'Beatrice', 'Njoroge', '1996-02-28', 'ID-99086', 'Female', 47, 'subordinate', 101),
(112, 'Samuel', 'Kipchoge', '1983-12-01', 'ID-88177', 'Male', 27, 'manager', NULL),
(113, 'Aisha', 'Mwangi', '1992-06-19', 'ID-77268', 'Female', 12, 'associate expert', 106),
(114, 'Brian', 'Otieno', '1997-04-05', 'ID-66359', 'Male', 45, 'subordinate', 102),
(115, 'Caroline', 'Wambua', '1990-08-11', 'ID-55440', 'Female', 16, 'expert', 112);

INSERT INTO Projects (ProjectID, ProjectName, ProjectType, Budget, StartDate, EndDate, BranchID, ProjectLeadID) VALUES
(6,  'Turkana Solar Grid',              'Climate Action & Renewable Energy',        7200000.00, '2026-03-01', '2027-09-01', 23, 112),
(7,  'Meru Community Health Drive',     'Public Health & Medicine',                 3500000.00, '2026-02-15', '2027-02-15', 12, 106),
(8,  'Kwale Mangrove Restoration',      'Marine & Coastal Conservation',            4800000.00, '2026-04-01', '2027-04-01',  2, 110),
(9,  'Nakuru Waste Segregation',        'Waste Management & Circular Economy',      2900000.00, '2026-01-10', '2026-12-10', 32, 115),
(10, 'Kisii Farmer Training Program',   'Agriculture & Food Security',              1800000.00, '2026-03-20', '2027-03-20', 45, 113);

INSERT INTO ProjectTeam (ProjectID, EmployeeID, ProjectRole) VALUES
(6,  112, 'Project Director'),
(6,  115, 'Energy Analyst'),
(7,  106, 'Project Director'),
(7,  108, 'Field Officer'),
(7,  113, 'Health Coordinator'),
(8,  110, 'Lead Marine Biologist'),
(8,  107, 'Conservation Officer'),
(9,  115, 'Waste Analyst'),
(9,  109, 'Community Liaison'),
(10, 113, 'Lead Agronomist'),
(10, 114, 'Field Trainer');

INSERT INTO Organizations (OrganizationID, OrganizationName, OrganizationFocus, BranchID, ContactEmail, ContactPhone) VALUES
(6,  'Turkana Energy Co-op',       'Climate Action & Renewable Energy',        23, 'info@turkanacoop.co.ke',    '0755666777'),
(7,  'MediReach Kenya',            'Public Health & Medicine',                  12, 'contact@medireach.co.ke',   '0766777888'),
(8,  'Coastal Greens Ltd',         'Marine & Coastal Conservation',              2, 'hello@coastalgreens.co.ke', '0777888999'),
(9,  'CleanCity Nakuru',           'Waste Management & Circular Economy',       32, 'info@cleancity.co.ke',      '0788999000'),
(10, 'Highlands Agri Solutions',   'Agriculture & Food Security',               45, 'agri@highlands.co.ke',      '0799000111');

INSERT INTO Licenses (LicenseID, OrganizationID, LicenseType, ApplicationDate, LicenseStatus, IssueDate, ExpiryDate) VALUES
(6,   6, 'Emissions',           '2026-02-01', 'Approved',          '2026-02-20', '2027-02-20'),
(7,   7, 'Environmental Impact','2026-01-15', 'Approved',          '2026-02-01', '2027-02-01'),
(8,   8, 'Water Abstraction',   '2026-03-05', 'Pending Inspection', NULL,         NULL),
(9,   9, 'Waste Disposal',      '2026-02-28', 'Approved',          '2026-03-15', '2027-03-15'),
(10, 10, 'Environmental Impact','2025-12-10', 'Revoked',            NULL,         NULL);

INSERT INTO Inspections (LicenseID, InspectorID, InspectionDate, InspectionResult, Remarks) VALUES
(6,  112, '2026-02-15', 'Pass',               'Solar installation meets all emission standards.'),
(7,  106, '2026-01-28', 'Pass',               'Clinic waste disposal protocols are satisfactory.'),
(8,  110, '2026-04-10', 'Scheduled',          'Awaiting coastal survey team availability.'),
(9,  115, '2026-03-10', 'Pass',               'Segregation facility fully operational.'),
(10, 113, '2026-01-05', 'Fail',               'Pesticide runoff levels exceed permitted limits.');

INSERT INTO Incidents (IncidentType, IncidentDate, Description, BranchID, ReportedByID, ResolutionStatus) VALUES
('Climate Action & Renewable Energy',        '2026-03-20', 'Flash floods damaged solar panel installations in the valley.',            23, 112, 'Investigating'),
('Public Health & Medicine',                 '2026-02-10', 'Cholera outbreak linked to contaminated borehole water.',                  12, 106, 'Resolved'),
('Marine & Coastal Conservation',            '2026-04-02', 'Bleaching event reported on 3km stretch of Kwale coastline.',               2, 110, 'Open'),
('Agriculture & Food Security',              '2026-03-15', 'Locust swarm destroyed crops across 200 acres in Kisii.',                  45, 113, 'Resolved'),
('Waste Management & Circular Economy',      '2026-04-05', 'Illegal e-waste dumping found near Nakuru industrial estate.',             32, 115, 'Investigating'),
('WASH (Water, Sanitation & Hygiene)',        '2026-01-30', 'Sewage overflow contaminating river upstream of Nyeri town.',             19, 108, 'Closed'),
('Wildlife Anti-Poaching & Rescue',          '2026-03-28', 'Snare traps recovered near Meru National Park boundary.',                 12, 113, 'Resolved'),
('Freshwater Ecosystems',                    '2026-02-18', 'Blue-green algae bloom spreading across Naivasha lake sections.',         31, 106, 'Open');

INSERT INTO Donors (DonorName, DonorType, ContactPerson, ContactEmail, ContactPhone) VALUES
('Kenya Climate Fund',          'Government',      'Dr. Paul Ndung\'u',  'pndungu@climatefund.go.ke',   '0202345678'),
('Africa Conservation Alliance','Foundation',      'Lindiwe Dube',       'ldube@acafrica.org',           '0744111222'),
('EU Green Partnership',        'International NGO','Thomas Müller',     'tmuller@eugreenpartner.eu',   '+493012345678'),
('Equity Bank Foundation',      'Corporate',       'Janet Waweru',       'jwaweru@equitybank.co.ke',    '0711333444'),
('UN Environment Programme',    'International NGO','Priya Sharma',      'psharma@unep.org',            '+254202624000');

INSERT INTO ProjectFunding (ProjectID, DonorID, Amount, FundingDate) VALUES
(6,   6,  7200000.00, '2026-02-15'),
(7,   7,  1800000.00, '2026-02-01'),
(7,   8,  1700000.00, '2026-02-10'),
(8,   9,  4800000.00, '2026-03-20'),
(9,  10,  2900000.00, '2025-12-20'),
(10,  6,   900000.00, '2026-03-01'),
(10,  7,   900000.00, '2026-03-05'),
(5,   8,  3000000.00, '2025-07-10'),
(2,   9,  5000000.00, '2026-01-05'),
(3,  10,  2000000.00, '2025-08-20');

INSERT INTO EnvironmentalAudits (OrganizationID, LeadAuditorID, AuditFocus, AuditDate, AuditStatus, ComplianceScore, NextAuditDate) VALUES
(6,  112, 'Climate Action & Renewable Energy',       '2026-02-10', 'Completed',   95.00, '2027-02-10'),
(7,  106, 'Public Health & Medicine',                '2026-01-20', 'Completed',   89.50, '2027-01-20'),
(8,  110, 'Marine & Coastal Conservation',           '2026-04-20', 'Scheduled',    NULL,  NULL),
(9,  115, 'Waste Management & Circular Economy',     '2026-03-05', 'Completed',   91.00, '2027-03-05'),
(10, 113, 'Agriculture & Food Security',             '2026-01-10', 'Completed',   61.00, '2027-01-10');

INSERT INTO ResearchStudies (StudyTitle, FocusArea, LeadResearcherID, BranchID, StartDate, EndDate, StudyStatus, Abstract) VALUES
('Turkana Wind & Solar Hybrid Potential',      'Climate Action & Renewable Energy',   112,  23, '2026-03-01', '2027-03-01', 'Data Collection', 'Assessing feasibility of hybrid renewable energy systems in arid northern Kenya.'),
('Cholera Vectors in Meru Borehole Water',     'Public Health & Medicine',            106,  12, '2026-02-01', '2026-08-01', 'Data Analysis',   'Identifying bacterial contamination pathways in rural borehole water sources.'),
('Mangrove Carbon Sequestration — Kwale',      'Marine & Coastal Conservation',       110,   2, '2026-04-01', '2027-10-01', 'Data Collection', 'Measuring carbon storage capacity of restored mangrove stands along the Kwale coast.'),
('Impact of Monoculture on Kisii Soil Health', 'Agriculture & Food Security',         113,  45, '2026-03-20', '2027-03-20', 'Data Collection', 'Analysing long-term effects of single-crop farming on soil biodiversity in Kisii.'),
('E-Waste Heavy Metal Leaching in Nakuru',     'Waste Management & Circular Economy', 115,  32, '2026-04-05', '2027-04-05', 'Proposed',        'Proposed study on heavy metal contamination from informal e-waste dumping sites.');

INSERT INTO ResearchFunding (StudyID, DonorID, Amount, FundingDate, GrantReferenceNumber) VALUES
(6,   6, 1500000.00, '2026-02-20', 'KCF-TRK-001'),
(7,   7,  800000.00, '2026-02-05', 'ACA-MRU-002'),
(8,   9, 2000000.00, '2026-03-25', 'EGP-KWL-003'),
(9,  10,  950000.00, '2026-03-10', 'EBF-KSI-004'),
(10,  8, 1100000.00, '2026-04-10', 'UNE-NKR-005');


INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (116,'Paul','Gitau','1985-12-26','ID-39256','Male',9,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (117,'Faith','Mutua','1979-03-16','ID-38657','Female',15,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (118,'Duncan','Odhiambo','1984-11-20','ID-68878','Male',38,'expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (119,'Julius','Maina','1987-06-19','ID-30379','Male',14,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (120,'Thomas','Mwenda','1979-05-04','ID-57052','Male',23,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (121,'Jane','Kimani','1991-12-24','ID-20328','Female',36,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (122,'Michael','Kariuki','1985-03-22','ID-47930','Male',6,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (123,'Aisha','Wanjiru','1991-05-14','ID-31319','Female',24,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (124,'Brian','Ndeto','1985-12-24','ID-31417','Male',30,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (125,'Joyce','Towett','1976-06-09','ID-51347','Female',26,'expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (126,'Teresa','Okwemba','1997-05-24','ID-61856','Female',42,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (127,'Leonard','Mutinda','1999-03-06','ID-44438','Male',38,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (128,'Ursula','Chebet','1997-11-09','ID-74686','Female',6,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (129,'Kevin','Sudi','1993-12-08','ID-88172','Male',5,'associate expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (130,'Grace','Sudi','1980-02-20','ID-99353','Female',35,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (131,'Ronald','Adhiambo','1982-02-04','ID-69470','Male',1,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (132,'Vincent','Kipchoge','1988-05-21','ID-93748','Male',33,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (133,'Lillian','Nzuki','1998-10-16','ID-10074','Female',39,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (134,'Bernard','Mugo','1985-09-28','ID-17592','Male',16,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (135,'Tobias','Otieno','1998-11-23','ID-26483','Male',9,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (136,'Immaculate','Wekesa','1993-12-24','ID-37760','Female',35,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (137,'Priscilla','Wanjala','1991-10-02','ID-67422','Female',34,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (138,'Michael','Maina','1975-12-11','ID-87110','Male',36,'expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (139,'Robert','Sang','1977-08-22','ID-40007','Male',5,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (140,'William','Yego','1987-06-29','ID-97684','Male',32,'expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (141,'Yvonne','Njeri','1993-04-05','ID-34957','Female',7,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (142,'Stella','Owino','1995-12-13','ID-17100','Female',44,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (143,'Gilbert','Maina','1979-11-26','ID-42591','Male',13,'expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (144,'Julius','Bett','1987-06-30','ID-70637','Male',16,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (145,'Diana','Hassan','1999-04-01','ID-11934','Female',6,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (146,'Herbert','Nyawira','1996-08-04','ID-38016','Male',26,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (147,'Mary','Nyamweya','1986-11-24','ID-69638','Female',19,'associate expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (148,'Edwin','Wairimu','1984-10-06','ID-17665','Male',38,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (149,'Joyce','Hassan','1996-05-21','ID-75909','Female',34,'expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (150,'Michael','Simiyu','1978-01-18','ID-98501','Male',16,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (151,'George','Odhiambo','1998-06-14','ID-51467','Male',17,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (152,'Nathan','Ondieki','1980-11-14','ID-98039','Male',42,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (153,'John','Wanjiru','1979-06-27','ID-19602','Male',35,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (154,'Zachariah','Otieno','1985-12-16','ID-58434','Male',19,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (155,'Simon','Makokha','1979-08-25','ID-27601','Male',17,'expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (156,'Oliver','Muthoni','1984-06-12','ID-54942','Male',14,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (157,'Zipporah','Hassan','1979-02-21','ID-93136','Female',28,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (158,'Xavier','Ndungu','1986-10-01','ID-31178','Male',29,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (159,'Henry','Wambua','1981-09-08','ID-81511','Male',3,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (160,'Hannah','Kariuki','1988-10-29','ID-57795','Female',3,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (161,'Richard','Kinyua','1993-03-25','ID-91351','Male',10,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (162,'Collins','Owino','1976-02-11','ID-33509','Male',22,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (163,'Oliver','Ruto','1979-11-07','ID-60140','Male',3,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (164,'Oscar','Waweru','1988-09-09','ID-39831','Male',15,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (165,'Gilbert','Kibera','1987-07-01','ID-19099','Male',18,'associate expert',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (166,'Jane','Kibera','1976-03-28','ID-25118','Female',17,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (167,'Richard','Simiyu','1994-06-29','ID-55309','Male',47,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (168,'Edward','Muthama','1983-07-12','ID-43386','Male',3,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (169,'Bernard','Adhiambo','1978-02-20','ID-97062','Male',22,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (170,'Fridah','Mugo','1993-04-27','ID-52753','Female',26,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (171,'Edwin','Odhiambo','1992-01-03','ID-98777','Male',12,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (172,'Mary','Macharia','1987-11-14','ID-37549','Female',28,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (173,'Valerie','Nyambura','1984-08-02','ID-77000','Female',31,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (174,'Quentin','Musyoka','1990-01-13','ID-22240','Male',16,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (175,'Andrew','Mutua','1977-01-27','ID-42092','Male',31,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (176,'Rose','Wesonga','1983-09-21','ID-60328','Female',32,'associate expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (177,'Richard','Ogola','1984-10-25','ID-33053','Male',45,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (178,'Francis','Wanjiru','1980-12-24','ID-70901','Male',43,'associate expert',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (179,'Valerie','Masinde','1997-08-23','ID-65933','Female',36,'associate expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (180,'Wambui','Ng''ang''a','1986-02-02','ID-93579','Female',18,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (181,'Winnie','Gitau','1994-09-24','ID-20155','Female',46,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (182,'Consolata','Nzuki','1978-08-13','ID-28136','Female',10,'expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (183,'Michael','Odhiambo','1993-04-14','ID-53369','Male',35,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (184,'Isaac','Nyamweya','1975-11-17','ID-85456','Male',25,'associate expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (185,'Miriam','Odhiambo','1999-02-22','ID-81582','Female',39,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (186,'Oliver','Adhiambo','1996-10-13','ID-13804','Male',25,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (187,'Pius','Ndungu','1998-12-17','ID-13534','Male',26,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (188,'Julius','Chebet','1995-09-17','ID-33819','Male',4,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (189,'Oscar','Njuguna','1990-02-20','ID-59692','Male',18,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (190,'Beatrice','Njeri','1975-11-14','ID-80702','Female',4,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (191,'Michael','Okwemba','1976-10-21','ID-14067','Male',16,'expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (192,'Kenneth','Ndungu','1996-03-29','ID-97747','Male',8,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (193,'Zipporah','Abdalla','1982-07-12','ID-89415','Female',39,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (194,'Timothy','Kipchoge','1976-02-25','ID-50888','Male',37,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (195,'Rachel','Wambua','1985-11-22','ID-23356','Female',45,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (196,'Zachariah','Ndeto','1994-03-20','ID-96706','Male',24,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (197,'Grace','Odhiambo','1996-12-27','ID-23833','Female',28,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (198,'Lawrence','Ngetich','1998-05-28','ID-95256','Male',18,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (199,'Abigail','Adhiambo','1987-01-15','ID-52245','Female',16,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (200,'Wambui','Birgen','1995-11-05','ID-84691','Female',40,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (201,'Ulrich','Njuguna','1983-02-27','ID-73904','Male',14,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (202,'Aisha','Simiyu','1987-05-24','ID-82848','Female',1,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (203,'Kenneth','Owino','1996-11-30','ID-82768','Male',16,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (204,'Sarah','Achieng','1988-03-13','ID-39045','Female',26,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (205,'Brenda','Ngei','1998-10-25','ID-55056','Female',28,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (206,'Harriet','Kiptoo','1995-05-10','ID-45509','Female',20,'expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (207,'Victor','Kimani','1999-01-14','ID-34267','Male',13,'expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (208,'Immaculate','Simiyu','1987-09-11','ID-23176','Female',13,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (209,'Simon','Ochieng','1998-12-17','ID-26591','Male',18,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (210,'Ronald','Kiptoo','1980-08-30','ID-93606','Male',32,'expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (211,'Brenda','Wamuyu','1994-10-04','ID-54657','Female',12,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (212,'Florence','Otieno','1992-12-22','ID-74454','Female',5,'associate expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (213,'Anthony','Koech','1988-08-18','ID-21164','Male',16,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (214,'Alex','Mwenda','1995-03-18','ID-68028','Male',20,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (215,'Joyce','Masinde','1979-06-14','ID-37235','Female',41,'expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (216,'Kevin','Yego','1982-10-18','ID-82350','Male',5,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (217,'Brenda','Wairimu','1976-06-18','ID-40340','Female',19,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (218,'Jacob','Ng''ang''a','1983-11-16','ID-65723','Male',8,'associate expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (219,'Oliver','Rotich','1978-03-15','ID-17816','Male',11,'subordinate',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (220,'Valerie','Kimani','1996-01-10','ID-49857','Female',45,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (221,'Valerie','Njoroge','1976-10-15','ID-66626','Female',21,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (222,'Jacob','Juma','1975-12-06','ID-98117','Male',18,'associate expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (223,'Hellen','Okwemba','1994-11-02','ID-46458','Female',12,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (224,'Caroline','Njeri','1990-08-10','ID-63523','Female',22,'associate expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (225,'Xavier','Owino','1997-03-23','ID-47777','Male',43,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (226,'Oscar','Achieng','1989-02-09','ID-43082','Male',21,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (227,'Duncan','Gathoni','1993-07-15','ID-17104','Male',13,'associate expert',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (228,'Valerie','Hassan','1984-02-18','ID-45003','Female',36,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (229,'Dorcas','Kimani','1976-04-17','ID-92578','Female',39,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (230,'Grace','Ngei','1993-04-20','ID-22217','Female',15,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (231,'Gloria','Nabwire','1981-11-27','ID-75323','Female',46,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (232,'Christine','Njeri','1985-12-07','ID-69871','Female',36,'expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (233,'Michael','Gitau','1993-08-12','ID-54548','Male',33,'expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (234,'Rehema','Wafula','1996-12-18','ID-29476','Female',29,'associate expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (235,'Lydia','Wanjiru','1989-06-08','ID-34727','Female',45,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (236,'Herbert','Kariuki','1989-04-10','ID-71993','Male',46,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (237,'Katherine','Wachira','1976-08-29','ID-26547','Female',33,'subordinate',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (238,'Moses','Mohammed','1998-08-05','ID-69890','Male',1,'subordinate',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (239,'Robert','Njeri','1986-11-21','ID-54375','Male',40,'subordinate',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (240,'Xavier','Juma','1998-12-08','ID-59808','Male',21,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (241,'Michael','Yego','1987-11-22','ID-39817','Male',6,'associate expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (242,'Moses','Kiplangat','1988-06-07','ID-13794','Male',3,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (243,'Harriet','Abdalla','1994-04-27','ID-29080','Female',16,'associate expert',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (244,'Brian','Ngetich','1978-07-17','ID-89887','Male',25,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (245,'Janet','Towett','1995-09-08','ID-93611','Female',17,'associate expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (246,'Pius','Muthoni','1999-07-09','ID-30706','Male',5,'associate expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (247,'Stella','Cheruiyot','1986-03-21','ID-69878','Female',20,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (248,'Esther','Yego','1992-02-09','ID-84963','Female',23,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (249,'Fredrick','Gitau','1975-05-13','ID-84177','Male',44,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (250,'Halima','Towett','1990-10-21','ID-38705','Female',41,'expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (251,'Charles','Wesonga','1976-10-07','ID-50492','Male',29,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (252,'Hannah','Achieng','1988-03-28','ID-52823','Female',27,'expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (253,'Immaculate','Gitonga','1987-03-24','ID-31567','Female',17,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (254,'Felicity','Omondi','1996-01-04','ID-19869','Female',10,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (255,'Isabella','Achieng','1992-09-12','ID-11824','Female',17,'associate expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (256,'Amina','Barasa','1992-02-03','ID-93695','Female',24,'expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (257,'Ruth','Khisa','1989-09-18','ID-89964','Female',15,'subordinate',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (258,'Rehema','Okwemba','1993-04-25','ID-25292','Female',9,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (259,'Simon','Wachira','1980-03-17','ID-22739','Male',16,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (260,'Zawadi','Abdalla','1999-03-26','ID-64935','Female',38,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (261,'Diana','Nyawira','1993-04-22','ID-46666','Female',3,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (262,'Valerie','Yego','1991-04-09','ID-23022','Female',44,'associate expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (263,'Joyce','Ondieki','1987-05-18','ID-34878','Female',8,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (264,'Harold','Nabwire','1975-12-16','ID-16629','Male',22,'expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (265,'Michael','Ngei','1984-04-17','ID-86858','Male',14,'subordinate',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (266,'Janet','Simiyu','1975-02-16','ID-46342','Female',10,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (267,'Nancy','Omondi','1976-02-27','ID-27275','Female',1,'associate expert',258);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (268,'Walter','Wanjiku','1982-10-25','ID-44782','Male',4,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (269,'Michael','Njeri','1995-02-09','ID-57453','Male',33,'associate expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (270,'Samuel','Makokha','1998-05-23','ID-49535','Male',30,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (271,'Sebastian','Ouma','1994-02-14','ID-99928','Male',7,'associate expert',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (272,'George','Njuguna','1981-08-27','ID-18609','Male',9,'expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (273,'Lydia','Simiyu','1998-10-19','ID-48652','Female',30,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (274,'Henry','Okwemba','1999-09-25','ID-38183','Male',28,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (275,'Felicity','Wanjiru','1992-11-19','ID-64524','Female',47,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (276,'Zipporah','Abdalla','1981-11-05','ID-72163','Female',5,'expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (277,'Lawrence','Mohammed','1991-09-19','ID-27054','Male',36,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (278,'Gloria','Owino','1990-11-11','ID-97207','Female',28,'subordinate',251);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (279,'Quentin','Simiyu','1989-01-06','ID-56090','Male',7,'associate expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (280,'Sebastian','Sigei','1979-11-09','ID-55890','Male',36,'associate expert',258);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (281,'Ursula','Ogola','1999-12-22','ID-13441','Female',39,'subordinate',277);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (282,'Ruth','Bett','1987-04-05','ID-50499','Female',22,'associate expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (283,'Gilbert','Otieno','1981-05-13','ID-92991','Male',2,'expert',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (284,'Douglas','Odhiambo','1995-05-08','ID-54681','Male',11,'associate expert',251);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (285,'Beatrice','Hassan','1981-12-24','ID-30632','Female',40,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (286,'Oliver','Nyambura','1994-01-08','ID-73656','Male',39,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (287,'William','Omondi','1990-06-26','ID-66349','Male',8,'expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (288,'Immaculate','Wanjala','1988-11-01','ID-15952','Female',15,'associate expert',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (289,'James','Langat','1988-07-09','ID-37686','Male',9,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (290,'Gloria','Kamau','1997-04-24','ID-66446','Female',12,'expert',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (291,'Vincent','Mutinda','1990-11-20','ID-19447','Male',26,'subordinate',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (292,'Sarah','Wanjiru','1978-06-29','ID-51033','Female',37,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (293,'Mwanaisha','Omondi','1993-03-03','ID-12733','Female',21,'expert',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (294,'Isabella','Achieng','1994-08-04','ID-23875','Female',16,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (295,'Fredrick','Mugo','1990-03-25','ID-39041','Male',22,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (296,'Benedict','Musyoka','1983-09-12','ID-55793','Male',23,'subordinate',277);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (297,'Kenneth','Kipchoge','1981-07-27','ID-43550','Male',13,'expert',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (298,'Collins','Wesonga','1997-03-01','ID-70811','Male',37,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (299,'Consolata','Koech','1994-09-23','ID-18950','Female',31,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (300,'Joyce','Kinyua','1997-10-04','ID-19724','Female',20,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (301,'Clifford','Muthoni','1978-06-11','ID-94497','Male',6,'subordinate',164);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (302,'Abigail','Barasa','1999-11-12','ID-15376','Female',29,'subordinate',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (303,'Walter','Wekesa','1996-05-02','ID-75715','Male',10,'subordinate',115);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (304,'Yusuf','Njoroge','1997-08-19','ID-94689','Male',12,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (305,'Valerie','Mwilu','1998-06-13','ID-89928','Female',11,'associate expert',196);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (306,'Queeneth','Maina','1977-05-07','ID-92691','Female',42,'associate expert',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (307,'Edward','Muthoni','1986-04-21','ID-96057','Male',39,'subordinate',209);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (308,'Andrew','Waweru','1988-11-30','ID-95990','Male',45,'subordinate',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (309,'Timothy','Mutinda','1991-11-24','ID-94343','Male',22,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (310,'Gladys','Mureithi','1975-10-26','ID-57526','Female',20,'expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (311,'Dorcas','Chirchir','1985-02-28','ID-28030','Female',10,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (312,'Vincent','Nzuki','1998-08-14','ID-14947','Male',43,'associate expert',106);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (313,'Katherine','Ruto','1983-02-10','ID-91885','Female',11,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (314,'Isabella','Juma','1985-08-27','ID-68222','Female',40,'expert',285);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (315,'Cornelius','Yego','1988-11-18','ID-71474','Male',13,'associate expert',285);
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (11,'Blue Enterprise','Public Health & Medicine',27,'info11@blueenterpri.co.ke','0756809217');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (12,'Savannah Enterprise','Community Empowerment',19,'info12@savannahente.co.ke','0767345369');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (13,'Mt Kenya Group','Waste Management & Circular Economy',31,'info13@mtkenyagroup.co.ke','0734485709');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (14,'Turkana Enterprise','Climate Action & Renewable Energy',19,'info14@turkanaenter.co.ke','0758627335');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (15,'Aberdare Cooperative','Marine & Coastal Conservation',13,'info15@aberdarecoop.co.ke','0787245121');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (16,'Coast Initiative','Infrastructure Development',31,'info16@coastinitiat.co.ke','0757681478');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (17,'Green Systems','WASH (Water, Sanitation & Hygiene)',19,'info17@greensystems.co.ke','0720900185');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (18,'Blue Consortium','Climate Action & Renewable Energy',33,'info18@blueconsorti.co.ke','0728971415');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (19,'Tana Trust','Freshwater Ecosystems',29,'info19@tanatrust.co.ke','0754127965');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (20,'Tana Initiative','Wildlife Anti-Poaching & Rescue',33,'info20@tanainitiati.co.ke','0757347231');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (21,'Rift Trust','Education & Skills Training',15,'info21@rifttrust.co.ke','0713434165');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (22,'Green Institute','Other',10,'info22@greeninstitu.co.ke','0727140163');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (23,'Lake Services','Disaster Relief',9,'info23@lakeservices.co.ke','0770570392');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (24,'Lamu Foundation','WASH (Water, Sanitation & Hygiene)',2,'info24@lamufoundati.co.ke','0742326130');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (25,'Eco Hub','Disaster Relief',39,'info25@ecohub.co.ke','0777543814');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (26,'Green Association','Freshwater Ecosystems',20,'info26@greenassocia.co.ke','0725150068');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (27,'Savannah Cooperative','Infrastructure Development',40,'info27@savannahcoop.co.ke','0768165858');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (28,'Green Services','Community Empowerment',35,'info28@greenservice.co.ke','0712762652');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (29,'Aberdare Group','Disaster Relief',10,'info29@aberdaregrou.co.ke','0747550089');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (30,'Kenya Society','Freshwater Ecosystems',37,'info30@kenyasociety.co.ke','0763296412');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (31,'Nairobi Systems','Education & Skills Training',5,'info31@nairobisyste.co.ke','0777670511');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (32,'Aberdare Systems','Agriculture & Food Security',2,'info32@aberdaresyst.co.ke','0759592972');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (33,'East Africa Agency','Education & Skills Training',17,'info33@eastafricaag.co.ke','0712474440');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (34,'Nairobi Society','Freshwater Ecosystems',47,'info34@nairobisocie.co.ke','0794758775');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (35,'Green Institute','Marine & Coastal Conservation',3,'info35@greeninstitu.co.ke','0755672536');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (36,'Highland Partners','Other',44,'info36@highlandpart.co.ke','0769829168');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (37,'Kilimanjaro Partners','Other',9,'info37@kilimanjarop.co.ke','0718850827');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (38,'Mara Initiative','Waste Management & Circular Economy',13,'info38@marainitiati.co.ke','0715929538');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (39,'Safari Initiative','Education & Skills Training',20,'info39@safariinitia.co.ke','0775517568');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (40,'Mt Kenya Services','Waste Management & Circular Economy',3,'info40@mtkenyaservi.co.ke','0792300386');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (41,'Lake Society','Other',4,'info41@lakesociety.co.ke','0793448048');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (42,'Coast Solutions','Other',24,'info42@coastsolutio.co.ke','0765519453');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (43,'Mara Agency','Education & Skills Training',12,'info43@maraagency.co.ke','0773825686');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (44,'Kilimanjaro Society','Other',34,'info44@kilimanjaros.co.ke','0744940064');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (45,'Nairobi Cooperative','WASH (Water, Sanitation & Hygiene)',28,'info45@nairobicoope.co.ke','0787962287');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (46,'Blue Hub','Waste Management & Circular Economy',21,'info46@bluehub.co.ke','0723183958');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (47,'Highland Association','Waste Management & Circular Economy',29,'info47@highlandasso.co.ke','0787852524');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (48,'Tana Partners','Disaster Relief',29,'info48@tanapartners.co.ke','0754568849');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (49,'East Africa Society','Community Empowerment',28,'info49@eastafricaso.co.ke','0745770532');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (50,'East Africa Trust','Infrastructure Development',41,'info50@eastafricatr.co.ke','0761480959');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (51,'Aberdare Partners','Public Health & Medicine',10,'info51@aberdarepart.co.ke','0787811027');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (52,'Mara Initiative','Marine & Coastal Conservation',5,'info52@marainitiati.co.ke','0740916332');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (53,'Valley Society','Wildlife Anti-Poaching & Rescue',37,'info53@valleysociet.co.ke','0714734487');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (54,'Eco Enterprise','Education & Skills Training',24,'info54@ecoenterpris.co.ke','0766900152');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (55,'Nairobi Alliance','Agriculture & Food Security',24,'info55@nairobiallia.co.ke','0760429657');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (56,'Coast Group','WASH (Water, Sanitation & Hygiene)',2,'info56@coastgroup.co.ke','0733623285');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (57,'Aberdare Agency','Agriculture & Food Security',8,'info57@aberdareagen.co.ke','0743912609');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (58,'Coast Enterprise','Freshwater Ecosystems',40,'info58@coastenterpr.co.ke','0746827691');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (59,'Kilimanjaro Network','WASH (Water, Sanitation & Hygiene)',9,'info59@kilimanjaron.co.ke','0719574001');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (60,'Blue Enterprise','WASH (Water, Sanitation & Hygiene)',44,'info60@blueenterpri.co.ke','0750800280');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (61,'Valley Trust','Agriculture & Food Security',35,'info61@valleytrust.co.ke','0747414527');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (62,'Blue Partners','Other',24,'info62@bluepartners.co.ke','0775335134');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (63,'Green Network','Other',9,'info63@greennetwork.co.ke','0740928766');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (64,'Kilimanjaro Foundation','Education & Skills Training',36,'info64@kilimanjarof.co.ke','0783486831');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (65,'Mara Hub','Marine & Coastal Conservation',40,'info65@marahub.co.ke','0721168941');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (66,'Lake Agency','Disaster Relief',47,'info66@lakeagency.co.ke','0771651231');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (67,'Tana Cooperative','Community Empowerment',5,'info67@tanacooperat.co.ke','0726432427');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (68,'Nairobi Enterprise','Climate Action & Renewable Energy',44,'info68@nairobienter.co.ke','0776461249');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (69,'Eco Hub','Infrastructure Development',38,'info69@ecohub.co.ke','0733905077');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (70,'Eco Cooperative','Agriculture & Food Security',4,'info70@ecocooperati.co.ke','0725643269');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (71,'Eco Association','Marine & Coastal Conservation',11,'info71@ecoassociati.co.ke','0751843788');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (72,'Savannah Society','Agriculture & Food Security',19,'info72@savannahsoci.co.ke','0720362778');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (73,'Safari Hub','Waste Management & Circular Economy',9,'info73@safarihub.co.ke','0790417534');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (74,'Lamu Hub','WASH (Water, Sanitation & Hygiene)',33,'info74@lamuhub.co.ke','0792276827');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (75,'Turkana Alliance','Marine & Coastal Conservation',43,'info75@turkanaallia.co.ke','0789855638');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (76,'Lamu Institute','Community Empowerment',3,'info76@lamuinstitut.co.ke','0713185168');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (77,'East Africa Consortium','Infrastructure Development',14,'info77@eastafricaco.co.ke','0783536822');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (78,'Lamu Foundation','Climate Action & Renewable Energy',41,'info78@lamufoundati.co.ke','0779403742');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (79,'Lake Services','Freshwater Ecosystems',44,'info79@lakeservices.co.ke','0761411882');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (80,'Mara Trust','Disaster Relief',4,'info80@maratrust.co.ke','0730560959');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (81,'Tana Services','Climate Action & Renewable Energy',14,'info81@tanaservices.co.ke','0753736129');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (82,'Eco Institute','Disaster Relief',21,'info82@ecoinstitute.co.ke','0754518084');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (83,'Eco Society','Agriculture & Food Security',36,'info83@ecosociety.co.ke','0723434617');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (84,'Savannah Enterprise','WASH (Water, Sanitation & Hygiene)',18,'info84@savannahente.co.ke','0767359961');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (85,'Eco Solutions','Public Health & Medicine',19,'info85@ecosolutions.co.ke','0759745270');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (86,'Tana Group','Marine & Coastal Conservation',21,'info86@tanagroup.co.ke','0783856157');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (87,'Highland Network','Other',11,'info87@highlandnetw.co.ke','0773639728');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (88,'Mara Services','Waste Management & Circular Economy',32,'info88@maraservices.co.ke','0712194423');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (89,'Rift Systems','Climate Action & Renewable Energy',16,'info89@riftsystems.co.ke','0737711680');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (90,'Valley Initiative','Public Health & Medicine',19,'info90@valleyinitia.co.ke','0773726543');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (91,'Kilimanjaro Association','Agriculture & Food Security',1,'info91@kilimanjaroa.co.ke','0723551860');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (92,'Eco Consortium','Disaster Relief',24,'info92@ecoconsortiu.co.ke','0761483713');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (93,'East Africa Agency','Public Health & Medicine',37,'info93@eastafricaag.co.ke','0781304110');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (94,'Valley Hub','Waste Management & Circular Economy',5,'info94@valleyhub.co.ke','0759628750');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (95,'Mara Hub','Waste Management & Circular Economy',40,'info95@marahub.co.ke','0797740725');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (96,'Green Alliance','WASH (Water, Sanitation & Hygiene)',26,'info96@greenallianc.co.ke','0757933510');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (97,'Highland Hub','Education & Skills Training',10,'info97@highlandhub.co.ke','0735731728');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (98,'Aberdare Agency','Agriculture & Food Security',3,'info98@aberdareagen.co.ke','0715140804');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (99,'Eco Institute','Other',31,'info99@ecoinstitute.co.ke','0776579187');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (100,'Eco Systems','Marine & Coastal Conservation',21,'info100@ecosystems.co.ke','0788434002');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (101,'Blue Agency','Community Empowerment',20,'info101@blueagency.co.ke','0785452713');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (102,'Aberdare Systems','Agriculture & Food Security',32,'info102@aberdaresyst.co.ke','0782414353');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (103,'Kilimanjaro Foundation','Education & Skills Training',22,'info103@kilimanjarof.co.ke','0796214928');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (104,'Tana Association','Other',47,'info104@tanaassociat.co.ke','0798759827');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (105,'Kenya Services','Waste Management & Circular Economy',42,'info105@kenyaservice.co.ke','0784705693');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (106,'Savannah Initiative','Community Empowerment',31,'info106@savannahinit.co.ke','0731649697');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (107,'Lamu Agency','Marine & Coastal Conservation',44,'info107@lamuagency.co.ke','0741133104');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (108,'Turkana Solutions','Freshwater Ecosystems',2,'info108@turkanasolut.co.ke','0766428930');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (109,'Tana Alliance','Wildlife Anti-Poaching & Rescue',45,'info109@tanaalliance.co.ke','0736530311');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (110,'Aberdare Services','Disaster Relief',47,'info110@aberdareserv.co.ke','0717840058');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (111,'Eco Systems','Freshwater Ecosystems',36,'info111@ecosystems.co.ke','0751794395');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (112,'Kilimanjaro Systems','Wildlife Anti-Poaching & Rescue',21,'info112@kilimanjaros.co.ke','0732581992');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (113,'Mt Kenya Institute','Agriculture & Food Security',23,'info113@mtkenyainsti.co.ke','0796909489');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (114,'Coast Services','Freshwater Ecosystems',16,'info114@coastservice.co.ke','0745685196');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (115,'Lake Group','Waste Management & Circular Economy',19,'info115@lakegroup.co.ke','0736823769');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (116,'Kilimanjaro Institute','Climate Action & Renewable Energy',23,'info116@kilimanjaroi.co.ke','0781934042');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (117,'Coast Association','WASH (Water, Sanitation & Hygiene)',37,'info117@coastassocia.co.ke','0796669576');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (118,'Rift Agency','Education & Skills Training',10,'info118@riftagency.co.ke','0747144109');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (119,'Lake Trust','Education & Skills Training',29,'info119@laketrust.co.ke','0793368900');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (120,'Kilimanjaro Network','Freshwater Ecosystems',35,'info120@kilimanjaron.co.ke','0744689318');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (121,'Coast Alliance','WASH (Water, Sanitation & Hygiene)',40,'info121@coastallianc.co.ke','0785350905');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (122,'Savannah Initiative','Infrastructure Development',34,'info122@savannahinit.co.ke','0738768933');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (123,'Savannah Initiative','WASH (Water, Sanitation & Hygiene)',27,'info123@savannahinit.co.ke','0752852204');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (124,'Kilimanjaro Solutions','Infrastructure Development',9,'info124@kilimanjaros.co.ke','0710677086');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (125,'Blue Cooperative','Infrastructure Development',31,'info125@bluecooperat.co.ke','0771782139');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (126,'Safari Association','Education & Skills Training',19,'info126@safariassoci.co.ke','0792162036');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (127,'Nairobi Group','Agriculture & Food Security',47,'info127@nairobigroup.co.ke','0714283568');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (128,'Tana Partners','Public Health & Medicine',26,'info128@tanapartners.co.ke','0773295361');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (129,'Lake Initiative','Public Health & Medicine',20,'info129@lakeinitiati.co.ke','0782732063');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (130,'Green Institute','Waste Management & Circular Economy',30,'info130@greeninstitu.co.ke','0792669691');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (131,'Aberdare Services','Marine & Coastal Conservation',33,'info131@aberdareserv.co.ke','0769386090');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (132,'Safari Solutions','Education & Skills Training',11,'info132@safarisoluti.co.ke','0768779776');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (133,'Coast Partners','Public Health & Medicine',22,'info133@coastpartner.co.ke','0747695361');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (134,'Safari Partners','Community Empowerment',41,'info134@safaripartne.co.ke','0761967161');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (135,'Tana Systems','Education & Skills Training',6,'info135@tanasystems.co.ke','0761801765');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (136,'Green Partners','Marine & Coastal Conservation',31,'info136@greenpartner.co.ke','0751360096');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (137,'Kenya Consortium','Wildlife Anti-Poaching & Rescue',16,'info137@kenyaconsort.co.ke','0767890371');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (138,'Coast Institute','Waste Management & Circular Economy',38,'info138@coastinstitu.co.ke','0783111991');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (139,'Coast Society','Disaster Relief',16,'info139@coastsociety.co.ke','0717800224');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (140,'Green Enterprise','Waste Management & Circular Economy',11,'info140@greenenterpr.co.ke','0761819400');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (141,'Aberdare Association','Disaster Relief',8,'info141@aberdareasso.co.ke','0791409369');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (142,'Valley Group','Freshwater Ecosystems',9,'info142@valleygroup.co.ke','0771260626');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (143,'Mara Society','Wildlife Anti-Poaching & Rescue',45,'info143@marasociety.co.ke','0780593699');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (144,'Mt Kenya Network','Other',16,'info144@mtkenyanetwo.co.ke','0797891401');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (145,'Lamu Trust','Agriculture & Food Security',29,'info145@lamutrust.co.ke','0777837952');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (146,'Valley Trust','Community Empowerment',8,'info146@valleytrust.co.ke','0717969032');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (147,'Mt Kenya Systems','Freshwater Ecosystems',37,'info147@mtkenyasyste.co.ke','0778257131');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (148,'Blue Institute','Agriculture & Food Security',29,'info148@blueinstitut.co.ke','0724813341');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (149,'Safari Services','WASH (Water, Sanitation & Hygiene)',33,'info149@safariservic.co.ke','0767947975');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (150,'East Africa Enterprise','Marine & Coastal Conservation',33,'info150@eastafricaen.co.ke','0763578987');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (151,'Turkana Initiative','Agriculture & Food Security',30,'info151@turkanainiti.co.ke','0796946112');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (152,'Lake Foundation','Wildlife Anti-Poaching & Rescue',17,'info152@lakefoundati.co.ke','0710882032');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (153,'Safari Trust','Public Health & Medicine',28,'info153@safaritrust.co.ke','0754834406');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (154,'Nairobi Hub','Public Health & Medicine',5,'info154@nairobihub.co.ke','0770133276');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (155,'Lake Cooperative','Marine & Coastal Conservation',9,'info155@lakecooperat.co.ke','0792864715');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (156,'Tana Society','Wildlife Anti-Poaching & Rescue',29,'info156@tanasociety.co.ke','0758493892');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (157,'Nairobi Hub','Marine & Coastal Conservation',42,'info157@nairobihub.co.ke','0754224395');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (158,'Blue Hub','Wildlife Anti-Poaching & Rescue',34,'info158@bluehub.co.ke','0726863214');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (159,'Savannah Foundation','Other',2,'info159@savannahfoun.co.ke','0748585494');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (160,'Mt Kenya Cooperative','Agriculture & Food Security',25,'info160@mtkenyacoope.co.ke','0739359535');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (161,'Mara Society','Marine & Coastal Conservation',18,'info161@marasociety.co.ke','0734860242');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (162,'Green Initiative','Other',43,'info162@greeninitiat.co.ke','0763744793');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (163,'Kenya Group','Freshwater Ecosystems',5,'info163@kenyagroup.co.ke','0722722795');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (164,'East Africa Enterprise','Community Empowerment',44,'info164@eastafricaen.co.ke','0716356622');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (165,'East Africa Agency','Climate Action & Renewable Energy',15,'info165@eastafricaag.co.ke','0779327823');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (166,'East Africa Alliance','Agriculture & Food Security',19,'info166@eastafricaal.co.ke','0739955413');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (167,'Turkana Institute','Community Empowerment',39,'info167@turkanainsti.co.ke','0796958136');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (168,'Highland Group','Waste Management & Circular Economy',10,'info168@highlandgrou.co.ke','0794646571');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (169,'Savannah Cooperative','Waste Management & Circular Economy',18,'info169@savannahcoop.co.ke','0717683761');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (170,'Turkana Partners','Infrastructure Development',44,'info170@turkanapartn.co.ke','0764682851');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (171,'Kilimanjaro Initiative','Education & Skills Training',42,'info171@kilimanjaroi.co.ke','0795499669');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (172,'Aberdare Institute','Disaster Relief',27,'info172@aberdareinst.co.ke','0762256466');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (173,'Lake Agency','Marine & Coastal Conservation',35,'info173@lakeagency.co.ke','0770352673');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (174,'Savannah Association','Disaster Relief',10,'info174@savannahasso.co.ke','0769160423');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (175,'Mt Kenya Cooperative','Wildlife Anti-Poaching & Rescue',36,'info175@mtkenyacoope.co.ke','0777240606');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (176,'Rift Group','Waste Management & Circular Economy',14,'info176@riftgroup.co.ke','0752778120');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (177,'Nairobi Enterprise','Education & Skills Training',6,'info177@nairobienter.co.ke','0778859782');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (178,'Safari Initiative','Waste Management & Circular Economy',25,'info178@safariinitia.co.ke','0796734356');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (179,'Lamu Initiative','WASH (Water, Sanitation & Hygiene)',13,'info179@lamuinitiati.co.ke','0785859489');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (180,'Mt Kenya Network','Climate Action & Renewable Energy',14,'info180@mtkenyanetwo.co.ke','0752417915');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (181,'Kenya Network','Freshwater Ecosystems',8,'info181@kenyanetwork.co.ke','0771354377');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (182,'Lamu Network','Wildlife Anti-Poaching & Rescue',16,'info182@lamunetwork.co.ke','0780437237');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (183,'Lake Agency','Climate Action & Renewable Energy',35,'info183@lakeagency.co.ke','0793476710');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (184,'Lake Consortium','Education & Skills Training',33,'info184@lakeconsorti.co.ke','0773588640');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (185,'Green Services','Other',21,'info185@greenservice.co.ke','0736488712');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (186,'Highland Cooperative','Public Health & Medicine',37,'info186@highlandcoop.co.ke','0738877259');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (187,'Eco Foundation','Waste Management & Circular Economy',36,'info187@ecofoundatio.co.ke','0784707275');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (188,'Tana Association','Marine & Coastal Conservation',13,'info188@tanaassociat.co.ke','0752341192');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (189,'Rift Group','Climate Action & Renewable Energy',36,'info189@riftgroup.co.ke','0793818113');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (190,'Highland Consortium','Other',32,'info190@highlandcons.co.ke','0792875520');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (191,'Kilimanjaro Enterprise','Marine & Coastal Conservation',47,'info191@kilimanjaroe.co.ke','0755277487');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (192,'Eco Hub','Climate Action & Renewable Energy',12,'info192@ecohub.co.ke','0779772985');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (193,'East Africa Systems','Public Health & Medicine',5,'info193@eastafricasy.co.ke','0795150871');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (194,'Kenya Cooperative','Marine & Coastal Conservation',41,'info194@kenyacoopera.co.ke','0739171269');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (195,'Eco Foundation','Freshwater Ecosystems',33,'info195@ecofoundatio.co.ke','0768491329');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (196,'East Africa Services','Infrastructure Development',32,'info196@eastafricase.co.ke','0712106933');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (197,'Mt Kenya Hub','Wildlife Anti-Poaching & Rescue',1,'info197@mtkenyahub.co.ke','0712655134');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (198,'Coast Hub','Waste Management & Circular Economy',2,'info198@coasthub.co.ke','0774952657');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (199,'Tana Partners','WASH (Water, Sanitation & Hygiene)',7,'info199@tanapartners.co.ke','0777256130');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (200,'Savannah Network','Community Empowerment',34,'info200@savannahnetw.co.ke','0742954814');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (201,'Valley Consortium','Other',26,'info201@valleyconsor.co.ke','0720491172');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (202,'Rift Enterprise','Community Empowerment',16,'info202@riftenterpri.co.ke','0799336828');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (203,'Lake Trust','Infrastructure Development',42,'info203@laketrust.co.ke','0714198042');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (204,'Rift Agency','Wildlife Anti-Poaching & Rescue',36,'info204@riftagency.co.ke','0770158840');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (205,'Kenya Partners','WASH (Water, Sanitation & Hygiene)',32,'info205@kenyapartner.co.ke','0765776234');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (206,'Highland Solutions','Agriculture & Food Security',3,'info206@highlandsolu.co.ke','0739321686');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (207,'Turkana Services','Waste Management & Circular Economy',3,'info207@turkanaservi.co.ke','0719817675');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (208,'Coast Hub','Community Empowerment',43,'info208@coasthub.co.ke','0714288066');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (209,'Highland Foundation','Freshwater Ecosystems',38,'info209@highlandfoun.co.ke','0728888795');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (210,'Rift Trust','Waste Management & Circular Economy',11,'info210@rifttrust.co.ke','0782352153');
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (11,'Bomet Upgrade','Agriculture & Food Security',5935000,'2025-12-05','2028-12-03',33,291);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (12,'Kajiado Initiative','WASH (Water, Sanitation & Hygiene)',7661000,'2024-02-11','2027-10-20',26,299);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (13,'Mandera Initiative','Infrastructure Development',4978000,'2025-08-08','2027-09-13',28,148);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (14,'Bomet Programme','Other',10635000,'2025-04-23','2026-02-09',10,198);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (15,'Kakamega Network','Wildlife Anti-Poaching & Rescue',5688000,'2025-02-03','2026-05-15',24,295);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (16,'Isiolo Programme','Marine & Coastal Conservation',1930000,'2024-07-15','2027-09-17',27,127);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (17,'Mombasa Programme','Education & Skills Training',9580000,'2024-10-20','2026-07-01',19,206);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (18,'Bomet Programme','Disaster Relief',9667000,'2024-10-17','2025-11-13',11,136);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (19,'Isiolo Project','Waste Management & Circular Economy',8579000,'2024-02-06','2026-05-14',20,224);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (20,'Eldoret Scheme','Waste Management & Circular Economy',4540000,'2026-11-16','2029-10-07',30,128);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (21,'Garissa Project','Public Health & Medicine',6983000,'2025-10-13','2027-08-11',28,309);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (22,'Garissa Project','Education & Skills Training',10383000,'2026-04-16','2028-03-13',21,175);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (23,'Migori Assessment','Other',4471000,'2025-07-09','2027-06-04',37,152);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (24,'Kirinyaga Drive','Infrastructure Development',13076000,'2026-01-24','2028-12-07',29,305);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (25,'Marsabit Network','WASH (Water, Sanitation & Hygiene)',13917000,'2025-11-16','2026-11-10',16,165);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (26,'Kakamega Network','Wildlife Anti-Poaching & Rescue',13428000,'2025-02-15','2028-08-19',26,237);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (27,'Nyamira Network','Wildlife Anti-Poaching & Rescue',9407000,'2024-06-23','2027-10-21',6,128);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (28,'Malindi Upgrade','Infrastructure Development',6316000,'2024-11-20','2025-10-21',44,266);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (29,'Kericho Scheme','Other',7552000,'2024-01-04','2026-04-17',34,243);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (30,'Lamu Cleanup','Education & Skills Training',6908000,'2025-11-19','2028-09-05',23,107);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (31,'Homa Bay Programme','Waste Management & Circular Economy',7315000,'2024-02-27','2027-03-12',20,188);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (32,'Siaya Campaign','Agriculture & Food Security',8412000,'2025-08-04','2027-12-23',29,182);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (33,'Eldoret Project','Public Health & Medicine',13774000,'2026-02-01','2028-11-04',44,305);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (34,'Kisii Network','Freshwater Ecosystems',8954000,'2024-09-06','2026-09-14',30,160);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (35,'Kericho Upgrade','Marine & Coastal Conservation',3553000,'2026-11-14','2028-01-24',40,151);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (36,'Busia Assessment','Wildlife Anti-Poaching & Rescue',6870000,'2024-12-07','2025-05-25',46,308);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (37,'Eldoret Assessment','WASH (Water, Sanitation & Hygiene)',13599000,'2026-03-12','2028-04-15',8,168);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (38,'Migori Survey','Infrastructure Development',5634000,'2026-07-20','2028-10-04',23,191);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (39,'Siaya Assessment','Marine & Coastal Conservation',13832000,'2026-12-26','2028-10-19',6,273);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (40,'Garissa Scheme','WASH (Water, Sanitation & Hygiene)',4408000,'2025-02-06','2027-12-05',33,200);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (41,'Vihiga Assessment','Marine & Coastal Conservation',9917000,'2025-07-06','2027-11-18',45,266);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (42,'Kericho Survey','Marine & Coastal Conservation',8522000,'2025-03-06','2027-08-20',4,192);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (43,'Nairobi Cleanup','Marine & Coastal Conservation',3696000,'2025-09-17','2028-08-14',44,226);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (44,'Vihiga Network','Climate Action & Renewable Energy',8506000,'2024-02-19','2025-04-10',3,171);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (45,'Lamu Survey','Waste Management & Circular Economy',3255000,'2025-10-24','2027-09-17',8,247);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (46,'Meru Project','Other',9398000,'2025-09-27','2026-12-15',35,156);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (47,'Bungoma Programme','Disaster Relief',14099000,'2026-04-10','2027-08-09',23,310);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (48,'Thika Cleanup','WASH (Water, Sanitation & Hygiene)',13207000,'2024-04-26','2027-10-23',23,282);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (49,'Bungoma Drive','Community Empowerment',2781000,'2024-04-26','2025-10-12',35,172);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (50,'Kirinyaga Drive','Education & Skills Training',12035000,'2025-05-19','2027-09-22',7,135);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (51,'Vihiga Initiative','Waste Management & Circular Economy',14705000,'2026-03-23','2027-04-05',46,183);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (52,'Malindi Upgrade','Wildlife Anti-Poaching & Rescue',8519000,'2024-10-21','2026-11-14',25,216);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (53,'Eldoret Upgrade','Other',14919000,'2024-07-17','2027-05-23',24,217);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (54,'Migori Scheme','Community Empowerment',540000,'2026-02-24','2028-11-22',45,192);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (55,'Eldoret Survey','Wildlife Anti-Poaching & Rescue',4068000,'2025-04-16','2027-06-27',19,187);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (56,'Garissa Assessment','Climate Action & Renewable Energy',13415000,'2025-11-25','2026-01-04',41,301);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (57,'Siaya Initiative','WASH (Water, Sanitation & Hygiene)',14551000,'2024-08-15','2025-07-07',45,134);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (58,'Wajir Drive','Waste Management & Circular Economy',2029000,'2026-06-09','2027-06-22',42,143);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (59,'Nakuru Restoration','Infrastructure Development',5505000,'2026-12-25','2027-07-21',6,281);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (60,'Nyeri Initiative','Freshwater Ecosystems',8312000,'2024-03-19','2025-09-22',29,103);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (61,'Nairobi Network','Education & Skills Training',13887000,'2024-07-23','2025-08-03',15,199);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (62,'Thika Network','Other',2178000,'2024-06-12','2026-03-13',9,265);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (63,'Kakamega Programme','Agriculture & Food Security',9728000,'2024-10-21','2025-08-12',47,155);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (64,'Kakamega Restoration','Community Empowerment',11748000,'2025-04-03','2026-03-25',8,251);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (65,'Bomet Scheme','Wildlife Anti-Poaching & Rescue',5652000,'2024-04-09','2027-02-08',36,254);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (66,'Marsabit Network','Public Health & Medicine',14391000,'2026-05-07','2029-10-17',13,292);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (67,'Kericho Project','Infrastructure Development',1394000,'2024-08-13','2025-04-16',41,253);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (68,'Eldoret Survey','Public Health & Medicine',6416000,'2025-03-13','2028-07-12',35,275);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (69,'Kericho Cleanup','Other',1695000,'2024-10-03','2025-05-07',3,116);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (70,'Kericho Survey','Waste Management & Circular Economy',10798000,'2026-09-25','2028-07-23',26,122);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (71,'Kirinyaga Survey','Community Empowerment',3001000,'2025-02-10','2026-09-07',10,238);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (72,'Mandera Restoration','Community Empowerment',10892000,'2026-11-21','2027-05-23',28,287);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (73,'Malindi Initiative','Freshwater Ecosystems',1912000,'2025-02-15','2028-10-02',20,271);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (74,'Kericho Programme','Public Health & Medicine',12098000,'2024-12-01','2025-08-12',34,233);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (75,'Turkana Drive','Education & Skills Training',2579000,'2026-05-24','2027-01-11',28,170);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (76,'Nyandarua Programme','Waste Management & Circular Economy',12170000,'2026-11-03','2028-08-17',24,115);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (77,'Migori Assessment','Marine & Coastal Conservation',6524000,'2024-05-25','2025-10-22',47,130);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (78,'Lamu Network','Agriculture & Food Security',542000,'2024-01-08','2025-08-12',25,139);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (79,'Kericho Initiative','Agriculture & Food Security',13658000,'2026-12-21','2028-04-11',16,207);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (80,'Mandera Project','WASH (Water, Sanitation & Hygiene)',9864000,'2025-02-17','2028-01-06',15,306);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (81,'Nyandarua Initiative','Wildlife Anti-Poaching & Rescue',1629000,'2025-05-25','2027-06-03',36,217);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (82,'Nairobi Scheme','Freshwater Ecosystems',5277000,'2026-05-24','2029-04-15',24,252);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (83,'Migori Campaign','Disaster Relief',9454000,'2024-03-01','2026-01-08',35,189);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (84,'Nairobi Scheme','Public Health & Medicine',12934000,'2026-07-28','2029-12-10',7,153);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (85,'Nyandarua Campaign','Wildlife Anti-Poaching & Rescue',8561000,'2024-03-23','2026-02-02',15,234);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (86,'Vihiga Network','Education & Skills Training',8011000,'2026-02-19','2027-09-05',41,310);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (87,'Kericho Programme','Community Empowerment',9803000,'2024-07-22','2025-04-10',17,181);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (88,'Kericho Network','Disaster Relief',5845000,'2025-08-09','2026-02-07',9,300);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (89,'Nyeri Drive','WASH (Water, Sanitation & Hygiene)',3193000,'2025-08-11','2027-02-18',23,298);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (90,'Kitui Cleanup','Waste Management & Circular Economy',8091000,'2025-02-03','2026-11-10',46,279);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (91,'Kisumu Campaign','Education & Skills Training',2930000,'2024-12-08','2026-07-17',4,274);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (92,'Wajir Project','Marine & Coastal Conservation',1009000,'2025-08-18','2028-09-08',7,219);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (93,'Nyeri Drive','WASH (Water, Sanitation & Hygiene)',695000,'2024-04-05','2025-07-12',44,262);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (94,'Thika Assessment','Community Empowerment',4740000,'2024-01-03','2025-11-15',9,124);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (95,'Samburu Programme','Public Health & Medicine',8052000,'2024-03-19','2026-12-13',32,108);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (96,'Bomet Upgrade','Wildlife Anti-Poaching & Rescue',3331000,'2025-04-06','2027-05-15',10,109);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (97,'Malindi Upgrade','Waste Management & Circular Economy',8673000,'2025-09-16','2026-02-09',25,136);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (98,'Vihiga Campaign','Infrastructure Development',14994000,'2026-04-21','2029-01-13',46,192);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (99,'Homa Bay Survey','Other',8440000,'2025-10-17','2027-07-09',12,107);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (100,'Mandera Assessment','Freshwater Ecosystems',980000,'2025-01-26','2027-09-12',38,160);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (101,'Kisii Programme','Freshwater Ecosystems',11262000,'2024-05-18','2027-01-25',15,248);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (102,'Bomet Scheme','Marine & Coastal Conservation',3385000,'2024-10-11','2027-12-12',38,108);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (103,'Kajiado Assessment','Community Empowerment',2828000,'2026-04-27','2028-09-10',12,226);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (104,'Kisumu Programme','Public Health & Medicine',4311000,'2026-04-01','2029-08-01',22,258);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (105,'Machakos Drive','Education & Skills Training',12246000,'2024-06-02','2025-03-19',46,137);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (106,'Meru Survey','Education & Skills Training',1688000,'2025-12-22','2027-10-04',22,178);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (107,'Mandera Drive','Marine & Coastal Conservation',12498000,'2025-11-16','2028-06-06',46,244);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (108,'Kajiado Campaign','Infrastructure Development',10149000,'2024-07-10','2027-12-10',9,146);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (109,'Nairobi Network','Community Empowerment',6915000,'2026-01-06','2029-06-26',40,157);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (110,'Nyeri Cleanup','Marine & Coastal Conservation',5925000,'2026-02-08','2028-06-06',41,123);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (111,'Samburu Cleanup','Public Health & Medicine',4845000,'2024-04-23','2025-06-09',7,285);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (112,'Nairobi Initiative','Wildlife Anti-Poaching & Rescue',7679000,'2026-07-06','2028-08-13',23,240);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (113,'Bomet Programme','Climate Action & Renewable Energy',13422000,'2026-11-25','2029-04-06',29,119);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (114,'Kisumu Project','Public Health & Medicine',5721000,'2025-02-03','2027-03-13',11,288);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (115,'Eldoret Survey','WASH (Water, Sanitation & Hygiene)',6036000,'2026-10-16','2029-01-14',42,143);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (116,'Bungoma Drive','Public Health & Medicine',2159000,'2025-04-07','2027-12-18',47,287);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (117,'Kirinyaga Project','Infrastructure Development',5112000,'2025-04-04','2026-07-19',36,226);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (118,'Kakamega Initiative','Education & Skills Training',562000,'2025-02-10','2028-11-20',31,152);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (119,'Nyeri Initiative','Freshwater Ecosystems',3298000,'2026-05-03','2028-02-10',26,221);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (120,'Migori Upgrade','Waste Management & Circular Economy',1993000,'2026-09-13','2027-06-13',24,148);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (121,'Busia Initiative','Waste Management & Circular Economy',7704000,'2025-05-08','2027-10-02',10,293);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (122,'Nyeri Programme','Infrastructure Development',6132000,'2026-07-25','2029-04-18',4,200);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (123,'Nyandarua Restoration','Agriculture & Food Security',11756000,'2025-10-08','2027-05-03',26,283);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (124,'Kisumu Survey','Community Empowerment',8967000,'2026-11-20','2027-02-25',29,145);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (125,'Kisii Campaign','Other',3657000,'2024-01-14','2025-11-14',13,311);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (126,'Kakamega Assessment','Waste Management & Circular Economy',5738000,'2026-02-03','2028-09-13',36,184);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (127,'Isiolo Survey','Climate Action & Renewable Energy',14810000,'2024-12-20','2027-09-26',27,129);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (128,'Vihiga Drive','Marine & Coastal Conservation',9783000,'2026-10-25','2027-02-19',7,302);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (129,'Marsabit Survey','Education & Skills Training',14883000,'2025-05-13','2028-08-19',39,222);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (130,'Kisumu Drive','Waste Management & Circular Economy',7102000,'2024-10-20','2027-12-13',3,202);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (131,'Samburu Network','Freshwater Ecosystems',1307000,'2026-08-09','2028-01-11',20,180);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (132,'Isiolo Cleanup','Disaster Relief',11720000,'2024-04-05','2026-12-15',21,169);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (133,'Vihiga Assessment','Infrastructure Development',1962000,'2024-08-07','2026-12-16',34,196);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (134,'Nakuru Survey','Other',3104000,'2024-05-23','2027-07-05',34,246);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (135,'Mombasa Drive','Freshwater Ecosystems',14838000,'2024-01-08','2025-08-02',24,281);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (136,'Machakos Project','Education & Skills Training',13992000,'2025-09-13','2028-02-22',2,162);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (137,'Narok Cleanup','Community Empowerment',7808000,'2024-08-19','2027-06-12',11,315);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (138,'Turkana Network','Disaster Relief',1980000,'2025-01-13','2026-03-28',37,300);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (139,'Kitui Campaign','Infrastructure Development',4188000,'2026-04-09','2029-07-17',2,300);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (140,'Nairobi Cleanup','Marine & Coastal Conservation',11106000,'2024-10-26','2025-04-09',39,307);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (141,'Wajir Network','Disaster Relief',11030000,'2025-07-13','2027-08-09',14,220);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (142,'Wajir Upgrade','Agriculture & Food Security',14005000,'2026-07-19','2027-01-17',43,315);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (143,'Narok Survey','Infrastructure Development',10228000,'2026-05-10','2029-02-16',5,187);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (144,'Isiolo Upgrade','Education & Skills Training',14614000,'2025-05-21','2028-11-10',13,139);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (145,'Nyandarua Campaign','Public Health & Medicine',13696000,'2026-07-22','2028-11-05',47,107);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (146,'Migori Project','Waste Management & Circular Economy',7357000,'2025-07-24','2026-10-23',37,309);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (147,'Machakos Scheme','Disaster Relief',12187000,'2024-11-18','2027-08-22',23,230);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (148,'Wajir Drive','Infrastructure Development',14860000,'2026-03-10','2027-08-05',17,286);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (149,'Kericho Upgrade','Education & Skills Training',11222000,'2024-04-12','2025-12-28',20,208);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (150,'Samburu Scheme','Waste Management & Circular Economy',10093000,'2025-08-28','2026-08-02',41,250);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (151,'Eldoret Cleanup','Freshwater Ecosystems',8699000,'2024-11-13','2027-05-14',4,139);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (152,'Garissa Campaign','Education & Skills Training',7204000,'2026-08-05','2028-12-06',6,225);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (153,'Samburu Upgrade','Marine & Coastal Conservation',5634000,'2026-01-01','2028-05-07',11,248);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (154,'Kisii Cleanup','Other',13010000,'2024-03-20','2026-11-14',26,210);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (155,'Homa Bay Restoration','Public Health & Medicine',1118000,'2026-04-24','2028-01-11',34,149);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (156,'Mombasa Upgrade','Public Health & Medicine',10767000,'2026-04-08','2029-06-10',9,127);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (157,'Bomet Survey','Community Empowerment',5515000,'2024-02-27','2025-05-10',30,287);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (158,'Nyandarua Assessment','Agriculture & Food Security',6035000,'2025-11-05','2027-08-12',13,143);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (159,'Kericho Initiative','Freshwater Ecosystems',4175000,'2026-03-07','2029-01-19',33,144);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (160,'Meru Scheme','Disaster Relief',11158000,'2024-07-21','2026-09-20',4,253);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (161,'Nakuru Upgrade','WASH (Water, Sanitation & Hygiene)',11208000,'2024-01-23','2025-07-15',25,132);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (162,'Turkana Cleanup','Disaster Relief',3008000,'2024-12-22','2027-01-10',27,270);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (163,'Nyeri Upgrade','Agriculture & Food Security',4923000,'2026-10-23','2027-07-27',7,231);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (164,'Meru Project','WASH (Water, Sanitation & Hygiene)',13357000,'2024-08-07','2027-04-25',17,313);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (165,'Nyandarua Campaign','Education & Skills Training',12025000,'2025-05-06','2026-09-16',14,277);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (166,'Homa Bay Scheme','Freshwater Ecosystems',544000,'2024-11-03','2025-10-22',32,139);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (167,'Thika Survey','WASH (Water, Sanitation & Hygiene)',12354000,'2026-02-09','2029-04-15',19,168);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (168,'Siaya Initiative','WASH (Water, Sanitation & Hygiene)',13823000,'2024-01-28','2026-06-26',44,181);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (169,'Bungoma Network','WASH (Water, Sanitation & Hygiene)',2056000,'2024-01-28','2025-11-21',11,185);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (170,'Kajiado Cleanup','Community Empowerment',4895000,'2026-02-12','2028-03-04',26,203);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (171,'Siaya Project','Wildlife Anti-Poaching & Rescue',11803000,'2025-07-21','2026-02-05',45,286);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (172,'Nakuru Drive','WASH (Water, Sanitation & Hygiene)',7316000,'2026-08-26','2029-11-15',12,257);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (173,'Bomet Scheme','Community Empowerment',972000,'2026-12-05','2028-08-04',27,213);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (174,'Kisumu Programme','Waste Management & Circular Economy',11231000,'2025-01-23','2028-09-25',37,286);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (175,'Lamu Upgrade','Education & Skills Training',9004000,'2026-12-23','2029-02-14',43,287);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (176,'Malindi Cleanup','Education & Skills Training',11374000,'2026-11-13','2027-09-20',4,103);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (177,'Kisii Survey','Climate Action & Renewable Energy',14457000,'2025-03-03','2027-06-08',22,172);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (178,'Nakuru Survey','Freshwater Ecosystems',9519000,'2026-07-13','2027-02-15',29,306);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (179,'Busia Programme','Climate Action & Renewable Energy',7824000,'2025-02-16','2028-11-01',7,204);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (180,'Vihiga Initiative','Agriculture & Food Security',9496000,'2024-02-26','2027-10-21',20,231);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (181,'Kitui Upgrade','Infrastructure Development',7974000,'2025-06-27','2026-04-28',30,185);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (182,'Homa Bay Network','Infrastructure Development',6452000,'2026-08-04','2027-11-08',1,188);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (183,'Kajiado Upgrade','Other',5283000,'2026-09-12','2029-02-02',11,227);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (184,'Garissa Network','Disaster Relief',12322000,'2025-02-09','2028-04-07',8,201);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (185,'Kitui Cleanup','Other',3622000,'2026-06-04','2028-01-21',44,251);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (186,'Meru Cleanup','Climate Action & Renewable Energy',11288000,'2026-09-05','2028-01-17',4,242);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (187,'Bungoma Assessment','Climate Action & Renewable Energy',8828000,'2024-12-19','2025-12-27',9,127);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (188,'Bomet Upgrade','Community Empowerment',10431000,'2025-09-13','2027-10-23',16,171);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (189,'Kericho Scheme','Waste Management & Circular Economy',7919000,'2024-03-14','2027-12-24',33,177);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (190,'Mandera Network','Disaster Relief',9569000,'2026-04-07','2027-10-23',19,276);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (191,'Kajiado Upgrade','Marine & Coastal Conservation',12139000,'2026-03-17','2029-12-21',21,282);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (192,'Meru Scheme','Agriculture & Food Security',8370000,'2026-10-22','2029-07-22',35,174);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (193,'Bungoma Initiative','Agriculture & Food Security',2244000,'2024-07-05','2025-11-02',13,169);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (194,'Kisii Project','Infrastructure Development',4605000,'2024-01-23','2026-04-25',35,109);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (195,'Kajiado Cleanup','WASH (Water, Sanitation & Hygiene)',10594000,'2026-12-18','2027-12-21',36,200);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (196,'Malindi Survey','Other',13555000,'2026-05-23','2029-01-13',25,207);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (197,'Mandera Survey','Public Health & Medicine',712000,'2026-05-07','2029-08-27',15,263);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (198,'Narok Assessment','Agriculture & Food Security',12598000,'2026-04-25','2029-04-10',29,146);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (199,'Eldoret Drive','Marine & Coastal Conservation',12543000,'2026-02-13','2027-07-09',36,168);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (200,'Garissa Drive','Community Empowerment',14361000,'2025-01-11','2027-12-05',3,140);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (201,'Mandera Assessment','Public Health & Medicine',13175000,'2026-10-27','2029-05-16',37,241);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (202,'Kajiado Programme','Other',12094000,'2025-09-08','2026-09-03',33,141);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (203,'Vihiga Survey','Agriculture & Food Security',7109000,'2024-06-08','2025-11-11',22,193);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (204,'Marsabit Campaign','Other',10629000,'2026-08-18','2029-01-04',43,189);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (205,'Busia Campaign','Infrastructure Development',10554000,'2026-04-02','2029-06-13',8,199);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (206,'Turkana Survey','Disaster Relief',5133000,'2024-09-27','2026-09-26',33,215);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (207,'Migori Initiative','Waste Management & Circular Economy',11174000,'2024-06-17','2025-02-06',35,237);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (208,'Nairobi Upgrade','WASH (Water, Sanitation & Hygiene)',3953000,'2026-11-25','2027-11-14',7,153);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (209,'Kirinyaga Network','Disaster Relief',13200000,'2025-11-27','2026-12-22',10,107);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (210,'Siaya Network','Education & Skills Training',1120000,'2024-02-02','2025-05-18',5,248);
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 11','Government','Nina Thomas','contact11@regionalre.org','+588001729836');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 12','Government','Alice Thomas','contact12@highlandsc.org','+879615270274');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 13','International NGO','Steve Johnson','contact13@sustainabl.org','+904643211329');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 14','Individual','Diana Moore','contact14@ruraldevel.org','+885666504394');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 15','Foundation','Marco Smith','contact15@valleyrest.org','+611944316108');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 16','Individual','Julia Jones','contact16@coastalpro.org','+395077921573');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 17','Individual','Eric Brown','contact17@forestrene.org','+69611537583');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 18','Foundation','Rosa Thompson','contact18@sustainabl.org','+112308638549');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 19','Corporate','Nina Martin','contact19@ruraldevel.org','+191691293717');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 20','Individual','Ivan Miller','contact20@regionalre.org','+154660390742');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 21','Foundation','Rosa Williams','contact21@forestrene.org','+383884866198');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 22','International NGO','George Lee','contact22@nationalcl.org','+639381800094');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 23','Corporate','Helen Brown','contact23@ruraldevel.org','+373660800029');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 24','Government','Paula White','contact24@continenta.org','+433508990774');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 25','Individual','Linda Taylor','contact25@biodiversi.org','+551724301196');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 26','Corporate','Helen Jackson','contact26@urbangreen.org','+368903212516');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 27','Government','Paula White','contact27@atlanticma.org','+586606958660');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 28','International NGO','Fatima Walker','contact28@forestrene.org','+118910440683');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 29','Individual','George Wilson','contact29@atlanticma.org','+949918338001');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 30','International NGO','Quinn Smith','contact30@asiandevel.org','+757781327255');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 31','Corporate','Bob Thompson','contact31@biodiversi.org','+344329446784');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 32','Foundation','Helen Lee','contact32@ruraldevel.org','+948976459315');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 33','Foundation','Quinn Martin','contact33@atlanticma.org','+126999146585');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 34','International NGO','Helen Walker','contact34@wetlandspr.org','+883208200227');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 35','Corporate','Fatima Lee','contact35@valleyrest.org','+735156392601');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 36','Government','Bob Davis','contact36@desertrecl.org','+983094407076');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 37','Government','Linda Davis','contact37@asiandevel.org','+63871553289');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 38','Government','Marco Harris','contact38@wetlandspr.org','+594786236940');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 39','Government','Diana Martin','contact39@nordiccons.org','+828858274691');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 40','Individual','Rosa Lee','contact40@nationalcl.org','+236920691967');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 41','International NGO','Quinn Wilson','contact41@biodiversi.org','+497038046278');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 42','Foundation','Paula Walker','contact42@ruraldevel.org','+15891831621');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 43','Corporate','Carlos Martin','contact43@globalwild.org','+832206067650');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 44','Corporate','Fatima Anderson','contact44@atlanticma.org','+786284297249');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 45','International NGO','Paula Harris','contact45@urbangreen.org','+628874242713');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 46','Corporate','Bob Jones','contact46@africaclea.org','+743544113848');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 47','Individual','Bob Lee','contact47@atlanticma.org','+191240140248');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 48','Corporate','Quinn Thomas','contact48@nationalcl.org','+773738568701');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 49','International NGO','George White','contact49@localcommu.org','+789558906999');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 50','Corporate','Helen Jackson','contact50@desertrecl.org','+774296344958');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 51','Individual','Ivan Garcia','contact51@sustainabl.org','+938239558924');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 52','Individual','Steve Williams','contact52@valleyrest.org','+306919372698');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 53','International NGO','Alice Miller','contact53@atlanticma.org','+671413599241');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 54','Individual','Tina Johnson','contact54@desertrecl.org','+691504729135');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 55','Corporate','Tina Thompson','contact55@desertrecl.org','+18083396378');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 56','Foundation','Linda Johnson','contact56@wetlandspr.org','+907570511906');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 57','Foundation','Marco Anderson','contact57@regionalre.org','+763474420092');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 58','Corporate','Ivan Harris','contact58@highlandsc.org','+994689605624');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 59','Individual','Rosa Jackson','contact59@localcommu.org','+331811839103');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 60','Individual','Quinn Brown','contact60@africaclea.org','+675325865521');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 61','Government','Nina Anderson','contact61@continenta.org','+145959736235');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 62','Government','Ivan Thompson','contact62@biodiversi.org','+557720207509');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 63','Government','Marco Miller','contact63@sustainabl.org','+537689680766');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 64','Government','Rosa Thompson','contact64@globalwild.org','+628325043570');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 65','International NGO','Helen White','contact65@atlanticma.org','+905076977004');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 66','Corporate','Quinn Thomas','contact66@pacificgre.org','+441223565082');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 67','International NGO','Carlos Jones','contact67@coastalpro.org','+612869931869');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 68','Government','Helen Anderson','contact68@asiandevel.org','+113615759047');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 69','Foundation','Tina Martin','contact69@coastalpro.org','+373566125120');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 70','Foundation','Omar Smith','contact70@globalwild.org','+267520418699');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 71','International NGO','Tina Martin','contact71@continenta.org','+673999818762');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 72','Corporate','Bob Anderson','contact72@sustainabl.org','+313813285701');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 73','International NGO','Ivan Thomas','contact73@globalwild.org','+468171143901');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 74','Individual','George Martin','contact74@coastalpro.org','+29977193987');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 75','Individual','Steve Anderson','contact75@localcommu.org','+452187592160');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 76','Corporate','Omar Thomas','contact76@sustainabl.org','+745314945131');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 77','Foundation','Quinn Brown','contact77@globalwild.org','+729900829971');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 78','Government','Diana Martin','contact78@localcommu.org','+337764117705');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 79','Foundation','Steve Harris','contact79@valleyrest.org','+998626138802');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 80','Individual','Alice Harris','contact80@valleyrest.org','+152107327477');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 81','Corporate','Helen Taylor','contact81@coastalpro.org','+539398575277');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 82','Individual','Alice Wilson','contact82@wetlandspr.org','+322233899367');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 83','Government','Carlos Thompson','contact83@coastalpro.org','+237341757401');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 84','Corporate','Steve Wilson','contact84@ruraldevel.org','+244908108692');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 85','Corporate','Helen Davis','contact85@desertrecl.org','+341888107487');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 86','Corporate','Tina Anderson','contact86@continenta.org','+204345515321');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 87','International NGO','Paula Walker','contact87@pacificgre.org','+17366396017');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 88','Government','Paula Lee','contact88@sustainabl.org','+363107992942');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 89','Government','Marco Davis','contact89@wetlandspr.org','+973476758136');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 90','Individual','Nina Harris','contact90@nordiccons.org','+709729790084');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 91','Foundation','Fatima White','contact91@ruraldevel.org','+167270955446');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 92','International NGO','George Thomas','contact92@africaclea.org','+755727675931');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 93','Individual','Ivan Garcia','contact93@ruraldevel.org','+712128928014');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 94','Foundation','Tina Taylor','contact94@nationalcl.org','+476084870519');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 95','Corporate','Nina Anderson','contact95@highlandsc.org','+478964269909');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 96','Foundation','Fatima Lee','contact96@nationalcl.org','+173946398734');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 97','Government','Helen Thompson','contact97@pacificgre.org','+568972785319');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 98','Corporate','Eric Harris','contact98@continenta.org','+26053489772');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 99','Corporate','Quinn Thompson','contact99@desertrecl.org','+937384985150');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 100','Individual','Steve Johnson','contact100@nationalcl.org','+511701548051');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 101','Government','Paula Brown','contact101@continenta.org','+588492970833');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 102','Government','Linda Thompson','contact102@nationalcl.org','+726401844042');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 103','Foundation','Diana Anderson','contact103@africaclea.org','+878646369354');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 104','Government','Quinn Harris','contact104@ruraldevel.org','+955631725051');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 105','Government','Omar Jones','contact105@sustainabl.org','+229283130753');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 106','Individual','Steve Thomas','contact106@highlandsc.org','+101339783148');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 107','Corporate','Karl Taylor','contact107@urbangreen.org','+848063693463');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 108','Foundation','Linda Lee','contact108@nationalcl.org','+679441870024');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 109','Corporate','Fatima Smith','contact109@highlandsc.org','+174125758723');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 110','International NGO','George Garcia','contact110@nationalcl.org','+511442421654');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 111','Foundation','Rosa Johnson','contact111@asiandevel.org','+48606102365');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 112','International NGO','Diana Wilson','contact112@wetlandspr.org','+801666898313');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 113','Government','Helen Davis','contact113@coastalpro.org','+956515490818');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 114','Corporate','Quinn Garcia','contact114@atlanticma.org','+49740924080');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 115','Government','Paula White','contact115@ruraldevel.org','+709310149998');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 116','Foundation','Eric Thompson','contact116@forestrene.org','+237587552692');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 117','Foundation','Rosa Davis','contact117@ruraldevel.org','+127192742877');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 118','Foundation','Ivan Jones','contact118@ruraldevel.org','+391045336904');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 119','Corporate','Linda Moore','contact119@wetlandspr.org','+613298232225');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 120','Foundation','Julia Smith','contact120@desertrecl.org','+999620935604');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 121','Corporate','Nina Thompson','contact121@ruraldevel.org','+562695447268');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 122','Foundation','Marco Davis','contact122@globalwild.org','+345635170508');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 123','Individual','Tina Wilson','contact123@regionalre.org','+376449549092');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 124','International NGO','Fatima Jones','contact124@continenta.org','+387239587766');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 125','Foundation','George Taylor','contact125@sustainabl.org','+31653476296');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 126','International NGO','Fatima Brown','contact126@forestrene.org','+372156184315');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 127','International NGO','Helen Williams','contact127@valleyrest.org','+205358210046');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 128','Government','Nina Moore','contact128@continenta.org','+649581187661');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 129','International NGO','Karl Williams','contact129@valleyrest.org','+975087280062');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 130','Government','Marco Williams','contact130@nordiccons.org','+703019265031');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 131','Government','Marco Smith','contact131@continenta.org','+164069538076');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 132','Foundation','Helen Johnson','contact132@coastalpro.org','+264311402472');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 133','Corporate','Paula Thomas','contact133@wetlandspr.org','+889423349548');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 134','Corporate','Bob Thompson','contact134@urbangreen.org','+675819561096');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 135','Government','George Anderson','contact135@desertrecl.org','+71485024047');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 136','Government','Alice Garcia','contact136@highlandsc.org','+363511253899');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 137','Corporate','Alice Johnson','contact137@coastalpro.org','+753560712271');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 138','International NGO','Helen Garcia','contact138@ruraldevel.org','+649982501269');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 139','Government','Bob Johnson','contact139@sustainabl.org','+463768428107');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 140','International NGO','Eric Harris','contact140@forestrene.org','+309125201729');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 141','International NGO','Marco Anderson','contact141@continenta.org','+935873637580');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 142','Foundation','Omar Thompson','contact142@nordiccons.org','+383104929112');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 143','Corporate','Rosa Anderson','contact143@biodiversi.org','+428440611705');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 144','Individual','Rosa Garcia','contact144@nationalcl.org','+93281217890');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 145','Government','Ivan Thompson','contact145@valleyrest.org','+472950254385');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 146','Foundation','Fatima Smith','contact146@wetlandspr.org','+808975021081');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 147','Corporate','Karl Williams','contact147@sustainabl.org','+858812759121');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 148','Individual','Paula Thompson','contact148@continenta.org','+207927950813');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 149','Foundation','Karl Brown','contact149@urbangreen.org','+131286387753');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 150','Corporate','Bob Miller','contact150@atlanticma.org','+143084649514');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 151','International NGO','Steve Thomas','contact151@pacificgre.org','+857830290429');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 152','Government','Helen Walker','contact152@nordiccons.org','+921304401362');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 153','Foundation','Carlos White','contact153@continenta.org','+825555672620');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 154','Foundation','Linda Johnson','contact154@forestrene.org','+799764538552');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 155','Government','Carlos Miller','contact155@asiandevel.org','+671417124022');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 156','Individual','Marco Miller','contact156@regionalre.org','+258152161448');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 157','Corporate','Fatima Thompson','contact157@pacificgre.org','+527462606300');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 158','Individual','Tina White','contact158@globalwild.org','+469171110739');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 159','Government','Linda Jackson','contact159@forestrene.org','+988014715913');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 160','Individual','Helen Lee','contact160@urbangreen.org','+706213781637');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 161','Government','Linda White','contact161@forestrene.org','+589417381849');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 162','International NGO','Julia Walker','contact162@africaclea.org','+33223115272');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 163','International NGO','Julia Davis','contact163@localcommu.org','+288970258559');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 164','Government','Rosa Martin','contact164@africaclea.org','+723455054143');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 165','International NGO','Omar Anderson','contact165@pacificgre.org','+205889425970');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 166','Individual','Helen Davis','contact166@ruraldevel.org','+338778504632');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 167','Individual','Marco Lee','contact167@asiandevel.org','+284153648273');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 168','Foundation','Fatima Harris','contact168@urbangreen.org','+899999520085');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 169','International NGO','Steve Thomas','contact169@localcommu.org','+114350598093');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 170','Government','Nina Jackson','contact170@urbangreen.org','+169639044885');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 171','International NGO','Julia Martin','contact171@coastalpro.org','+63426282426');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 172','Individual','Helen Jones','contact172@urbangreen.org','+79578627236');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Valley Restoration Partners 173','Individual','Steve Martin','contact173@valleyrest.org','+126248817808');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 174','Foundation','Eric Jones','contact174@localcommu.org','+445649495861');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 175','International NGO','Rosa Thomas','contact175@biodiversi.org','+345660378755');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Wetlands Preservation Fund 176','Foundation','Eric Jones','contact176@wetlandspr.org','+623402158803');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 177','Foundation','Steve Miller','contact177@desertrecl.org','+722057617830');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Asian Development Partners 178','Government','Nina Taylor','contact178@asiandevel.org','+881384806111');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Highlands Conservation Society 179','Foundation','Linda Anderson','contact179@highlandsc.org','+256672528066');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 180','International NGO','Julia Garcia','contact180@sustainabl.org','+455921252890');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 181','Corporate','George Anderson','contact181@nordiccons.org','+204662594124');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 182','International NGO','Helen Walker','contact182@pacificgre.org','+198817415821');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Clean Water Fund 183','Government','Diana Moore','contact183@africaclea.org','+583023746966');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 184','Corporate','Rosa Miller','contact184@urbangreen.org','+278517718126');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 185','Foundation','Tina Jones','contact185@forestrene.org','+895373945362');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Biodiversity Action Network 186','Individual','Bob Wilson','contact186@biodiversi.org','+225553137994');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Continental Health Partners 187','Individual','Ivan Johnson','contact187@continenta.org','+601035795037');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 188','Government','Linda Brown','contact188@coastalpro.org','+32660104622');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 189','Individual','Diana Taylor','contact189@coastalpro.org','+633283035614');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 190','Corporate','Quinn White','contact190@globalwild.org','+721092292243');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 191','Individual','Julia Taylor','contact191@regionalre.org','+631674332429');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Rural Development Trust 192','Government','Linda Moore','contact192@ruraldevel.org','+319856264217');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('National Climate Institute 193','Foundation','Alice Thompson','contact193@nationalcl.org','+361968870326');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 194','Foundation','Eric Williams','contact194@urbangreen.org','+946271763012');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Regional Reforestation Group 195','Individual','Eric Jackson','contact195@regionalre.org','+406709234482');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 196','Corporate','George Jones','contact196@forestrene.org','+754436425084');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Atlantic Marine Initiative 197','Government','Quinn Jones','contact197@atlanticma.org','+564938966574');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 198','International NGO','Rosa Thompson','contact198@urbangreen.org','+931508469555');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Urban Green Solutions 199','Corporate','Alice Taylor','contact199@urbangreen.org','+539423273485');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Local Community Foundation 200','Foundation','Ivan Jones','contact200@localcommu.org','+251458579821');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 201','International NGO','Tina Walker','contact201@globalwild.org','+353630074869');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 202','Corporate','Helen Smith','contact202@sustainabl.org','+469931278947');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Desert Reclamation Alliance 203','Corporate','Quinn Walker','contact203@desertrecl.org','+612606143397');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 204','Foundation','Paula Jones','contact204@coastalpro.org','+211830044665');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Nordic Conservation Trust 205','Foundation','Alice Wilson','contact205@nordiccons.org','+531878587567');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Global Wildlife Fund 206','Foundation','Tina Harris','contact206@globalwild.org','+896354895816');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Coastal Protection Agency 207','International NGO','Tina Thomas','contact207@coastalpro.org','+936638851791');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Sustainable Agriculture Hub 208','Individual','Tina Thompson','contact208@sustainabl.org','+689755342261');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Pacific Green Alliance 209','Foundation','Omar Johnson','contact209@pacificgre.org','+324157531471');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Forest Renewal Initiative 210','Foundation','Quinn Johnson','contact210@forestrene.org','+256545573143');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (11,102,'Water Abstraction','2025-08-08','Approved','2025-08-31','2026-08-31');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (12,76,'Other','2024-04-21','Approved','2024-05-05','2025-05-05');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (13,119,'Emissions','2024-07-04','Approved','2024-07-17','2025-07-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (14,47,'Other','2024-10-04','Approved','2024-10-24','2025-10-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (15,116,'Environmental Impact','2025-01-01','Approved','2025-01-17','2026-01-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (16,117,'Environmental Impact','2025-05-27','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (17,167,'Waste Disposal','2024-09-10','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (18,181,'Emissions','2026-01-13','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (19,182,'Emissions','2026-11-13','Approved','2026-11-28','2027-11-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (20,97,'Other','2026-02-18','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (21,44,'Water Abstraction','2024-11-03','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (22,38,'Waste Disposal','2024-04-15','Approved','2024-05-04','2025-05-04');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (23,187,'Emissions','2025-08-14','Approved','2025-08-27','2026-08-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (24,34,'Waste Disposal','2024-01-08','Approved','2024-01-26','2025-01-25');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (25,4,'Emissions','2026-10-16','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (26,140,'Environmental Impact','2026-10-07','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (27,151,'Emissions','2026-07-18','Approved','2026-07-30','2027-07-30');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (28,154,'Other','2024-01-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (29,141,'Water Abstraction','2025-03-01','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (30,38,'Environmental Impact','2025-12-15','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (31,9,'Other','2025-09-03','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (32,23,'Environmental Impact','2024-08-11','Approved','2024-08-26','2025-08-26');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (33,42,'Water Abstraction','2024-12-29','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (34,192,'Other','2026-01-07','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (35,24,'Water Abstraction','2025-10-23','Approved','2025-11-14','2026-11-14');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (36,210,'Environmental Impact','2026-05-25','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (37,17,'Water Abstraction','2026-08-22','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (38,178,'Water Abstraction','2025-11-05','Approved','2025-12-01','2026-12-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (39,54,'Waste Disposal','2024-04-29','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (40,187,'Other','2024-06-28','Approved','2024-07-27','2025-07-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (41,202,'Water Abstraction','2026-05-24','Approved','2026-06-13','2027-06-13');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (42,67,'Other','2025-12-25','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (43,158,'Other','2026-10-13','Approved','2026-11-12','2027-11-12');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (44,128,'Emissions','2025-01-03','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (45,60,'Water Abstraction','2025-01-31','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (46,7,'Emissions','2024-08-29','Approved','2024-09-14','2025-09-14');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (47,205,'Other','2026-04-29','Approved','2026-05-19','2027-05-19');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (48,90,'Other','2025-03-10','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (49,52,'Water Abstraction','2025-06-05','Approved','2025-06-24','2026-06-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (50,77,'Other','2025-10-25','Approved','2025-11-07','2026-11-07');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (51,176,'Water Abstraction','2025-11-30','Approved','2025-12-28','2026-12-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (52,158,'Environmental Impact','2024-12-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (53,87,'Emissions','2026-08-29','Approved','2026-09-28','2027-09-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (54,35,'Emissions','2024-11-14','Approved','2024-12-11','2025-12-11');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (55,86,'Emissions','2026-04-27','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (56,15,'Other','2025-09-05','Approved','2025-09-25','2026-09-25');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (57,143,'Other','2024-02-08','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (58,176,'Water Abstraction','2025-12-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (59,39,'Water Abstraction','2024-03-04','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (60,97,'Other','2024-12-05','Approved','2024-12-27','2025-12-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (61,48,'Other','2024-08-27','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (62,193,'Water Abstraction','2025-10-06','Approved','2025-10-24','2026-10-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (63,106,'Environmental Impact','2026-10-14','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (64,96,'Emissions','2025-09-11','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (65,78,'Waste Disposal','2024-08-17','Approved','2024-08-28','2025-08-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (66,200,'Waste Disposal','2024-07-08','Approved','2024-07-18','2025-07-18');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (67,205,'Emissions','2026-10-21','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (68,88,'Emissions','2026-12-08','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (69,84,'Waste Disposal','2024-07-20','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (70,133,'Waste Disposal','2025-02-24','Approved','2025-03-20','2026-03-20');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (71,100,'Other','2024-08-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (72,12,'Other','2024-06-27','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (73,12,'Environmental Impact','2026-12-02','Approved','2026-12-21','2027-12-21');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (74,6,'Other','2025-10-01','Approved','2025-10-17','2026-10-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (75,83,'Waste Disposal','2025-01-29','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (76,137,'Water Abstraction','2026-06-22','Approved','2026-07-10','2027-07-10');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (77,39,'Waste Disposal','2025-07-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (78,160,'Other','2026-11-18','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (79,139,'Water Abstraction','2025-10-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (80,181,'Water Abstraction','2025-05-16','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (81,80,'Other','2025-11-24','Approved','2025-12-05','2026-12-05');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (82,34,'Environmental Impact','2026-08-22','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (83,13,'Environmental Impact','2026-02-24','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (84,110,'Emissions','2025-01-01','Approved','2025-01-29','2026-01-29');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (85,162,'Emissions','2025-12-29','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (86,210,'Waste Disposal','2026-12-28','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (87,194,'Emissions','2024-09-26','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (88,206,'Emissions','2024-07-18','Approved','2024-08-17','2025-08-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (89,182,'Emissions','2026-08-21','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (90,58,'Waste Disposal','2025-06-12','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (91,101,'Waste Disposal','2025-11-07','Approved','2025-11-27','2026-11-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (92,117,'Emissions','2024-03-02','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (93,29,'Water Abstraction','2026-09-07','Approved','2026-09-22','2027-09-22');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (94,73,'Water Abstraction','2024-09-17','Approved','2024-10-09','2025-10-09');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (95,210,'Environmental Impact','2025-10-29','Approved','2025-11-10','2026-11-10');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (96,203,'Water Abstraction','2026-12-27','Approved','2027-01-24','2028-01-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (97,106,'Waste Disposal','2025-05-14','Approved','2025-06-08','2026-06-08');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (98,99,'Environmental Impact','2025-11-28','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (99,178,'Other','2026-06-01','Approved','2026-06-24','2027-06-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (100,146,'Water Abstraction','2025-04-28','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (101,172,'Environmental Impact','2026-09-23','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (102,153,'Emissions','2025-10-28','Approved','2025-11-21','2026-11-21');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (103,46,'Water Abstraction','2026-04-11','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (104,28,'Other','2026-02-15','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (105,166,'Environmental Impact','2024-07-04','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (106,36,'Other','2024-01-01','Approved','2024-01-15','2025-01-14');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (107,116,'Other','2025-08-19','Approved','2025-09-16','2026-09-16');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (108,115,'Waste Disposal','2025-02-25','Approved','2025-03-17','2026-03-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (109,77,'Other','2025-09-15','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (110,112,'Water Abstraction','2024-07-01','Approved','2024-07-30','2025-07-30');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (111,131,'Emissions','2024-09-18','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (112,16,'Water Abstraction','2024-04-18','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (113,144,'Water Abstraction','2024-08-12','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (114,8,'Waste Disposal','2026-06-03','Approved','2026-06-25','2027-06-25');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (115,161,'Water Abstraction','2026-02-22','Approved','2026-03-17','2027-03-17');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (116,140,'Waste Disposal','2024-12-21','Approved','2025-01-06','2026-01-06');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (117,143,'Emissions','2026-01-07','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (118,40,'Water Abstraction','2024-09-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (119,19,'Environmental Impact','2024-10-21','Approved','2024-11-15','2025-11-15');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (120,169,'Emissions','2024-10-05','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (121,165,'Emissions','2026-07-22','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (122,179,'Other','2026-05-21','Approved','2026-06-14','2027-06-14');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (123,131,'Emissions','2026-07-10','Approved','2026-07-27','2027-07-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (124,48,'Emissions','2024-01-16','Approved','2024-02-02','2025-02-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (125,183,'Other','2025-07-05','Approved','2025-08-01','2026-08-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (126,148,'Water Abstraction','2024-03-09','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (127,146,'Emissions','2026-01-24','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (128,124,'Environmental Impact','2024-10-17','Approved','2024-11-12','2025-11-12');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (129,193,'Water Abstraction','2026-08-10','Approved','2026-09-05','2027-09-05');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (130,157,'Environmental Impact','2025-05-17','Approved','2025-05-29','2026-05-29');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (131,176,'Other','2025-10-01','Approved','2025-10-21','2026-10-21');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (132,137,'Environmental Impact','2026-08-18','Approved','2026-09-12','2027-09-12');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (133,147,'Water Abstraction','2026-05-12','Approved','2026-05-31','2027-05-31');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (134,75,'Waste Disposal','2024-03-13','Approved','2024-04-11','2025-04-11');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (135,192,'Water Abstraction','2025-06-17','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (136,122,'Other','2024-12-12','Approved','2024-12-31','2025-12-31');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (137,208,'Other','2024-02-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (138,22,'Waste Disposal','2026-11-01','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (139,201,'Water Abstraction','2025-05-31','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (140,72,'Water Abstraction','2025-06-10','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (141,29,'Other','2024-12-23','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (142,190,'Waste Disposal','2026-07-03','Approved','2026-07-18','2027-07-18');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (143,67,'Waste Disposal','2026-09-20','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (144,136,'Environmental Impact','2025-12-03','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (145,38,'Other','2024-11-11','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (146,193,'Emissions','2026-02-23','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (147,113,'Waste Disposal','2025-03-07','Approved','2025-03-28','2026-03-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (148,14,'Water Abstraction','2024-08-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (149,119,'Emissions','2026-09-02','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (150,192,'Other','2025-04-23','Approved','2025-05-15','2026-05-15');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (151,122,'Water Abstraction','2024-10-24','Approved','2024-11-16','2025-11-16');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (152,4,'Water Abstraction','2026-07-08','Approved','2026-07-28','2027-07-28');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (153,136,'Environmental Impact','2024-07-18','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (154,164,'Water Abstraction','2026-06-03','Approved','2026-07-03','2027-07-03');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (155,70,'Water Abstraction','2025-07-07','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (156,26,'Water Abstraction','2026-03-12','Approved','2026-03-29','2027-03-29');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (157,188,'Other','2025-02-03','Approved','2025-02-18','2026-02-18');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (158,81,'Other','2024-01-22','Approved','2024-02-03','2025-02-02');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (159,4,'Emissions','2024-07-19','Approved','2024-08-12','2025-08-12');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (160,90,'Waste Disposal','2025-08-03','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (161,9,'Environmental Impact','2024-07-07','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (162,153,'Waste Disposal','2024-09-06','Approved','2024-09-19','2025-09-19');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (163,23,'Other','2024-09-23','Approved','2024-10-23','2025-10-23');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (164,145,'Waste Disposal','2024-08-15','Approved','2024-09-02','2025-09-02');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (165,76,'Emissions','2024-06-04','Approved','2024-06-22','2025-06-22');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (166,197,'Emissions','2025-10-24','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (167,200,'Environmental Impact','2025-07-21','Approved','2025-08-12','2026-08-12');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (168,100,'Water Abstraction','2024-05-03','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (169,209,'Water Abstraction','2024-12-30','Approved','2025-01-24','2026-01-24');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (170,52,'Other','2026-03-15','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (171,126,'Environmental Impact','2024-10-21','Approved','2024-11-13','2025-11-13');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (172,56,'Other','2024-08-05','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (173,184,'Water Abstraction','2024-07-30','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (174,19,'Other','2025-05-28','Approved','2025-06-07','2026-06-07');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (175,128,'Waste Disposal','2024-01-02','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (176,171,'Emissions','2025-06-29','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (177,85,'Emissions','2024-01-08','Approved','2024-02-02','2025-02-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (178,123,'Emissions','2026-04-07','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (179,200,'Environmental Impact','2025-04-07','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (180,177,'Emissions','2024-09-05','Approved','2024-09-26','2025-09-26');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (181,86,'Water Abstraction','2026-03-31','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (182,166,'Environmental Impact','2026-01-18','Approved','2026-02-07','2027-02-07');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (183,21,'Emissions','2025-08-16','Approved','2025-08-31','2026-08-31');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (184,142,'Environmental Impact','2026-02-25','Approved','2026-03-16','2027-03-16');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (185,179,'Emissions','2024-08-06','Approved','2024-08-27','2025-08-27');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (186,125,'Environmental Impact','2026-06-15','Approved','2026-06-29','2027-06-29');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (187,10,'Waste Disposal','2024-02-21','Approved','2024-03-20','2025-03-20');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (188,62,'Emissions','2026-03-07','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (189,139,'Water Abstraction','2026-10-20','Approved','2026-11-13','2027-11-13');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (190,5,'Environmental Impact','2025-11-25','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (191,202,'Environmental Impact','2026-04-10','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (192,207,'Other','2026-07-27','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (193,138,'Waste Disposal','2025-04-22','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (194,10,'Waste Disposal','2026-09-28','Approved','2026-10-23','2027-10-23');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (195,159,'Environmental Impact','2025-05-12','Approved','2025-05-26','2026-05-26');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (196,4,'Waste Disposal','2024-04-12','Revoked',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (197,204,'Environmental Impact','2026-07-23','Approved','2026-08-20','2027-08-20');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (198,17,'Environmental Impact','2024-08-21','Approved','2024-09-19','2025-09-19');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (199,57,'Environmental Impact','2025-02-19','Approved','2025-03-13','2026-03-13');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (200,84,'Environmental Impact','2024-10-08','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (201,204,'Waste Disposal','2024-04-03','Approved','2024-04-23','2025-04-23');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (202,17,'Environmental Impact','2025-07-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (203,107,'Waste Disposal','2026-01-27','Approved','2026-02-20','2027-02-20');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (204,63,'Other','2024-03-24','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (205,203,'Other','2026-02-09','Approved','2026-02-19','2027-02-19');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (206,125,'Environmental Impact','2024-01-14','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (207,23,'Other','2025-08-04','Approved','2025-08-29','2026-08-29');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (208,178,'Waste Disposal','2025-02-26','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (209,70,'Other','2026-07-11','Approved','2026-07-26','2027-07-26');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (210,157,'Environmental Impact','2025-01-03','Approved','2025-02-01','2026-02-01');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (23,261,'2025-09-08','Pass','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (143,161,'2025-01-28','Pass','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (25,259,'2026-01-11','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (130,157,'2026-08-08','Pending Remediation','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (54,171,'2024-04-18','Pass','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (39,276,'2026-08-29','Fail','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (172,112,'2024-04-20','Fail','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (54,212,'2025-05-29','Pass','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (195,217,'2024-03-29','Pass','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (138,146,'2024-11-19','Pending Remediation','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (132,130,'2024-05-25','Scheduled','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (114,252,'2025-10-29','Pass','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (174,184,'2025-04-16','Pending Remediation','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (59,126,'2025-04-30','Pending Remediation','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (52,197,'2025-03-27','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (125,114,'2026-06-11','Pass','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (157,217,'2024-12-30','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (118,285,'2025-02-01','Fail','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (52,186,'2024-09-17','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (16,172,'2024-10-06','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (118,208,'2024-12-16','Pending Remediation','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (76,255,'2024-11-17','Pending Remediation','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (157,144,'2025-04-15','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (134,226,'2025-03-19','Fail','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (119,172,'2024-01-30','Pending Remediation','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (64,164,'2025-11-01','Pass','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (152,139,'2024-01-11','Pass','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (11,221,'2026-10-29','Pass','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (101,223,'2024-07-19','Fail','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (22,243,'2024-01-26','Pending Remediation','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (56,134,'2026-01-04','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (24,105,'2026-09-09','Pending Remediation','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (181,218,'2024-02-19','Scheduled','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (198,136,'2026-04-10','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (95,261,'2026-08-08','Pending Remediation','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (161,119,'2026-02-27','Scheduled','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (136,109,'2025-08-30','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (179,257,'2025-02-28','Pending Remediation','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (159,186,'2024-04-22','Fail','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (173,194,'2024-04-15','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (120,259,'2024-03-24','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (166,244,'2024-05-17','Fail','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (53,136,'2025-11-16','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (167,223,'2025-03-05','Pending Remediation','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (58,183,'2025-12-23','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (175,209,'2025-07-21','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (89,216,'2026-09-22','Fail','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (32,221,'2026-12-25','Pending Remediation','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (75,216,'2026-01-23','Pending Remediation','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (208,117,'2025-01-20','Scheduled','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (23,121,'2026-03-11','Scheduled','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (20,128,'2024-12-03','Pass','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (38,228,'2024-11-04','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (161,106,'2025-08-23','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (139,134,'2026-08-28','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (189,266,'2024-02-13','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (6,306,'2025-04-20','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (166,186,'2026-04-23','Fail','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (166,302,'2025-10-30','Fail','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (179,236,'2026-06-30','Fail','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (34,303,'2025-09-19','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (59,224,'2026-01-31','Scheduled','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (13,138,'2025-12-24','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (159,142,'2025-08-07','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (182,278,'2024-11-10','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (11,182,'2024-09-16','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (48,153,'2024-03-12','Pending Remediation','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (38,196,'2026-07-07','Fail','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (137,178,'2024-09-05','Scheduled','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (128,297,'2024-10-24','Scheduled','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (82,140,'2024-01-09','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (130,185,'2025-08-28','Fail','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (194,247,'2024-10-28','Pending Remediation','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (114,187,'2024-08-18','Pending Remediation','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (11,136,'2024-08-27','Pass','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (159,157,'2026-07-02','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (15,256,'2025-02-03','Fail','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (201,297,'2025-07-23','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (138,215,'2024-06-27','Scheduled','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (50,226,'2025-10-12','Fail','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (15,271,'2026-01-09','Pass','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (110,195,'2026-03-01','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (89,190,'2025-09-22','Scheduled','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (144,123,'2025-03-17','Pending Remediation','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (190,207,'2026-06-25','Pass','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (187,209,'2026-04-28','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (154,123,'2024-10-21','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (135,186,'2024-05-15','Scheduled','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (194,197,'2024-06-30','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (70,207,'2024-12-24','Fail','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (146,294,'2024-10-07','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (98,175,'2026-10-01','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (78,314,'2025-09-14','Fail','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (119,158,'2024-02-24','Pending Remediation','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (68,177,'2026-08-25','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (74,207,'2025-01-02','Fail','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (166,163,'2024-02-28','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (127,118,'2026-01-10','Fail','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (112,167,'2026-09-01','Scheduled','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (31,196,'2026-11-15','Pending Remediation','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (67,142,'2024-04-29','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (178,135,'2026-01-01','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (93,208,'2025-12-30','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (136,264,'2024-06-06','Fail','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (161,147,'2024-07-12','Fail','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (140,183,'2025-10-09','Scheduled','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (205,178,'2025-07-09','Pending Remediation','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (93,125,'2026-12-30','Fail','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (37,104,'2024-10-07','Fail','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (200,225,'2026-04-23','Pass','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (42,127,'2025-03-22','Pass','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (49,304,'2026-12-12','Scheduled','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (142,280,'2024-08-21','Pass','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (20,130,'2024-09-25','Scheduled','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (90,180,'2026-01-12','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (153,234,'2025-12-01','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (8,291,'2024-08-30','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (178,137,'2025-04-09','Pass','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (34,121,'2026-05-20','Pending Remediation','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (29,120,'2024-02-08','Pending Remediation','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (111,111,'2025-02-06','Pass','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (169,232,'2024-05-01','Fail','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (65,112,'2024-05-15','Pass','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (194,125,'2024-09-10','Scheduled','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (151,152,'2025-01-13','Pending Remediation','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (24,138,'2025-07-22','Scheduled','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (91,142,'2026-10-22','Pending Remediation','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (62,230,'2024-05-19','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (196,104,'2026-12-19','Pass','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (73,144,'2024-01-09','Scheduled','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (55,230,'2026-08-30','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (48,213,'2024-08-07','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (98,209,'2025-03-14','Fail','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (29,295,'2025-10-05','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (134,135,'2026-10-12','Pending Remediation','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (74,243,'2024-03-24','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (30,199,'2025-08-03','Fail','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (80,276,'2026-06-28','Pass','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (75,210,'2025-01-21','Scheduled','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (206,222,'2026-01-22','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (126,273,'2024-08-03','Pass','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (169,274,'2024-06-23','Pass','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (103,278,'2024-07-27','Pending Remediation','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (44,117,'2026-01-14','Scheduled','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (52,253,'2026-04-07','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (109,286,'2026-10-19','Pass','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (197,249,'2025-07-13','Pending Remediation','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (165,203,'2025-12-30','Fail','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (104,225,'2026-11-13','Pass','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (117,128,'2024-09-07','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (60,261,'2024-10-02','Pass','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (14,313,'2024-05-19','Fail','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (46,198,'2025-10-31','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (160,125,'2024-06-05','Pending Remediation','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (197,227,'2026-08-12','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (128,226,'2026-10-30','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (208,239,'2024-02-06','Scheduled','Facility meets all required environmental standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (111,131,'2026-02-24','Fail','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (97,214,'2026-07-30','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (143,269,'2025-09-12','Scheduled','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (126,211,'2024-10-02','Pass','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (125,296,'2024-08-12','Fail','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (169,242,'2026-08-20','Fail','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (41,230,'2024-04-24','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (152,197,'2025-12-23','Pending Remediation','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (83,116,'2024-02-27','Fail','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (94,190,'2024-02-25','Pending Remediation','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (88,198,'2024-07-18','Pass','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (106,190,'2024-04-25','Pending Remediation','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (61,266,'2025-10-01','Fail','Scheduled maintenance of treatment plant overdue.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (177,117,'2025-09-16','Pass','Significant non-compliance detected. Follow-up required.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (6,238,'2025-10-29','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (109,246,'2026-11-20','Scheduled','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (6,279,'2026-08-19','Fail','Air quality levels within permitted thresholds.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (97,247,'2026-03-10','Pass','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (207,226,'2024-07-23','Pending Remediation','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (87,228,'2026-10-26','Scheduled','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (87,143,'2025-09-05','Pass','Site inspection pending environmental officer availability.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (52,228,'2024-06-03','Scheduled','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (55,174,'2025-06-27','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (103,306,'2025-04-07','Fail','Minor violations noted — remediation plan submitted.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (184,249,'2024-07-13','Fail','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (18,246,'2026-12-23','Fail','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (89,304,'2024-06-06','Pending Remediation','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (130,306,'2025-09-06','Pass','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (81,152,'2026-04-28','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (132,217,'2025-01-04','Scheduled','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (181,233,'2025-01-17','Fail','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (170,311,'2026-08-15','Pass','Chemical storage compliant with safety regulations.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (137,308,'2026-06-07','Scheduled','Soil contamination detected near storage area.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (161,116,'2026-12-05','Pass','Full compliance with licensing conditions confirmed.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (38,162,'2024-11-04','Pending Remediation','Emission levels marginally above permitted limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (77,212,'2026-04-20','Pass','Biodiversity impact assessment satisfactory.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (17,263,'2025-02-20','Scheduled','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (74,266,'2024-11-24','Pass','Noise pollution levels exceed regulatory limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (61,204,'2025-05-03','Pass','All waste disposal mechanisms are operational.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (8,163,'2025-09-27','Fail','Runoff management systems are inadequate.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (112,209,'2024-03-16','Pass','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (35,108,'2025-06-13','Pending Remediation','Water treatment protocols need upgrading.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (169,241,'2024-12-26','Fail','Facility meets all required environmental standards.');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-09-22','Illegal dumping of industrial waste near water source.',4,122,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-05-10','Flash floods caused by blocked drainage infrastructure.',24,272,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-03-23','Chemical discharge into river upstream of settlement.',16,129,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2024-09-04','Charcoal burning operation found inside forest reserve.',43,313,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-12-11','Excessive noise pollution from nearby construction.',32,124,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-10-03','Invasive species encroachment reported in wetland.',38,289,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-04-28','Flash floods caused by blocked drainage infrastructure.',14,137,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2025-07-16','Coral bleaching observed along coastal reef system.',27,166,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-10-01','Plastic waste accumulation blocking drainage channels.',24,280,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-05-17','Algae bloom affecting fish populations in the lake.',44,164,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2024-10-23','Illegal sand harvesting detected at riverbed.',31,284,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-02-13','Wildlife road collision incident on highway corridor.',3,290,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-05-05','Excessive noise pollution from nearby construction.',36,199,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-01-13','Poaching snares recovered near wildlife corridor.',35,161,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-01-17','Air quality alert issued due to industrial emissions.',17,178,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2025-04-27','Soil erosion threatening farmland along riverbank.',14,142,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2025-10-11','Flash floods caused by blocked drainage infrastructure.',3,171,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-10-03','Algae bloom affecting fish populations in the lake.',27,186,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-11-24','Excessive noise pollution from nearby construction.',33,117,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-10-31','Coral bleaching observed along coastal reef system.',45,108,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2025-01-11','Coral bleaching observed along coastal reef system.',42,135,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2025-09-17','Invasive species encroachment reported in wetland.',37,122,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2026-11-23','Chemical discharge into river upstream of settlement.',39,276,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-07-13','Algae bloom affecting fish populations in the lake.',9,167,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-11-01','Soil erosion threatening farmland along riverbank.',13,122,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-03-16','Air quality alert issued due to industrial emissions.',37,158,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-04-13','Deforestation activity detected in protected zone.',30,151,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-04-11','Air quality alert issued due to industrial emissions.',40,210,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-07-01','Illegal sand harvesting detected at riverbed.',11,246,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-12-12','Flash floods caused by blocked drainage infrastructure.',30,312,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-04-04','Sewage overflow contaminating local water supply.',13,309,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-10-09','Air quality alert issued due to industrial emissions.',9,211,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-03-17','Soil erosion threatening farmland along riverbank.',47,274,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-04-16','Chemical discharge into river upstream of settlement.',2,175,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2026-07-12','Endangered species sighted outside protected area.',24,250,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-06-24','Illegal dumping of industrial waste near water source.',31,135,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-03-25','Sewage overflow contaminating local water supply.',46,199,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-06-08','Deforestation activity detected in protected zone.',7,243,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2025-04-25','Algae bloom affecting fish populations in the lake.',23,256,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2024-04-03','Illegal dumping of industrial waste near water source.',17,230,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-03-19','Illegal sand harvesting detected at riverbed.',9,244,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-06-17','Uncontrolled bush fire spreading toward residential area.',33,227,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-09-27','Deforestation activity detected in protected zone.',21,282,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-06-17','Poaching snares recovered near wildlife corridor.',21,112,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-07-29','Illegal sand harvesting detected at riverbed.',28,173,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2025-06-24','Charcoal burning operation found inside forest reserve.',21,212,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-10-03','Chemical discharge into river upstream of settlement.',36,269,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-04-18','Sewage overflow contaminating local water supply.',10,114,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-08-21','Excessive noise pollution from nearby construction.',11,281,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-10-10','Oil spill reported along the shoreline.',29,192,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2026-09-20','Coral bleaching observed along coastal reef system.',32,129,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-09-10','Illegal sand harvesting detected at riverbed.',6,153,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-12-10','Charcoal burning operation found inside forest reserve.',18,245,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-03-10','Water borehole contamination reported by community.',1,235,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-05-02','Deforestation activity detected in protected zone.',16,297,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-11-04','Illegal dumping of industrial waste near water source.',19,275,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-03-18','Illegal sand harvesting detected at riverbed.',38,128,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-02-29','Deforestation activity detected in protected zone.',30,313,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2026-07-18','Excessive noise pollution from nearby construction.',39,269,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-07-16','Invasive species encroachment reported in wetland.',47,288,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2024-09-21','Sewage overflow contaminating local water supply.',4,306,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2024-04-23','Deforestation activity detected in protected zone.',36,255,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2025-06-06','Uncontrolled bush fire spreading toward residential area.',16,298,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-02-12','Sewage overflow contaminating local water supply.',11,200,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-11-11','Poaching snares recovered near wildlife corridor.',20,226,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-09-27','Wildlife road collision incident on highway corridor.',9,192,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-11-15','Sewage overflow contaminating local water supply.',32,215,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-07-03','Water borehole contamination reported by community.',39,209,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2026-01-24','Wildlife road collision incident on highway corridor.',12,212,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-03-23','Charcoal burning operation found inside forest reserve.',22,219,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-11-13','Algae bloom affecting fish populations in the lake.',34,262,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-08-18','Coral bleaching observed along coastal reef system.',28,121,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-09-07','Chemical discharge into river upstream of settlement.',9,276,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2026-12-07','Flash floods caused by blocked drainage infrastructure.',19,246,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-04-02','Charcoal burning operation found inside forest reserve.',7,231,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-08-09','Water borehole contamination reported by community.',17,191,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-10-28','Illegal dumping of industrial waste near water source.',8,290,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-01-08','Air quality alert issued due to industrial emissions.',3,122,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-09-01','Invasive species encroachment reported in wetland.',38,286,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2026-07-10','Wildlife road collision incident on highway corridor.',17,188,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2025-01-18','Sewage overflow contaminating local water supply.',12,121,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-06-15','Poaching snares recovered near wildlife corridor.',28,237,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-08-26','Illegal dumping of industrial waste near water source.',11,268,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-04-09','Wildlife road collision incident on highway corridor.',47,225,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2026-01-08','Air quality alert issued due to industrial emissions.',20,123,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-01-25','Poaching snares recovered near wildlife corridor.',2,279,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-03-04','Algae bloom affecting fish populations in the lake.',42,138,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2025-01-25','Deforestation activity detected in protected zone.',20,298,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2026-05-14','Illegal dumping of industrial waste near water source.',8,143,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-06-30','Algae bloom affecting fish populations in the lake.',31,106,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-05-11','Sewage overflow contaminating local water supply.',19,246,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-04-14','Invasive species encroachment reported in wetland.',1,127,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-06-03','Flash floods caused by blocked drainage infrastructure.',32,289,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-08-18','Oil spill reported along the shoreline.',32,203,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2026-09-26','Endangered species sighted outside protected area.',46,116,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2025-10-08','Plastic waste accumulation blocking drainage channels.',5,169,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2026-08-27','Poaching snares recovered near wildlife corridor.',32,260,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-07-07','Flash floods caused by blocked drainage infrastructure.',2,142,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2026-08-19','Illegal sand harvesting detected at riverbed.',29,160,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-11-25','Wildlife road collision incident on highway corridor.',46,269,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-03-10','Flash floods caused by blocked drainage infrastructure.',44,268,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-08-25','Uncontrolled bush fire spreading toward residential area.',40,154,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2024-06-25','Algae bloom affecting fish populations in the lake.',9,145,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2026-10-04','Poaching snares recovered near wildlife corridor.',27,227,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2024-04-06','Illegal dumping of industrial waste near water source.',23,167,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2024-12-23','Charcoal burning operation found inside forest reserve.',3,307,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-08-21','Wildlife road collision incident on highway corridor.',15,131,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-06-12','Invasive species encroachment reported in wetland.',23,297,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2025-07-01','Chemical discharge into river upstream of settlement.',45,232,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-04-13','Coral bleaching observed along coastal reef system.',30,294,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-07-27','Plastic waste accumulation blocking drainage channels.',3,230,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-08-29','Sewage overflow contaminating local water supply.',24,141,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-06-23','Charcoal burning operation found inside forest reserve.',32,288,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-01-14','Invasive species encroachment reported in wetland.',9,132,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2026-05-01','Illegal dumping of industrial waste near water source.',16,314,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2025-08-10','Charcoal burning operation found inside forest reserve.',11,122,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-04-29','Illegal sand harvesting detected at riverbed.',41,271,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-12-20','Flash floods caused by blocked drainage infrastructure.',15,136,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2026-04-18','Coral bleaching observed along coastal reef system.',34,304,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-06-25','Chemical discharge into river upstream of settlement.',1,284,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-06-22','Invasive species encroachment reported in wetland.',21,203,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-06-07','Oil spill reported along the shoreline.',26,295,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-11-05','Water borehole contamination reported by community.',4,262,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-11-30','Soil erosion threatening farmland along riverbank.',27,203,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2025-09-15','Invasive species encroachment reported in wetland.',23,103,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2024-10-27','Air quality alert issued due to industrial emissions.',29,265,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2026-06-24','Illegal sand harvesting detected at riverbed.',42,204,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-06-21','Oil spill reported along the shoreline.',35,186,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2024-09-15','Charcoal burning operation found inside forest reserve.',35,173,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2025-10-01','Charcoal burning operation found inside forest reserve.',22,294,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2024-02-27','Plastic waste accumulation blocking drainage channels.',38,167,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2025-09-14','Flash floods caused by blocked drainage infrastructure.',33,129,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2025-06-15','Charcoal burning operation found inside forest reserve.',23,132,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-09-12','Coral bleaching observed along coastal reef system.',20,247,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-11-25','Endangered species sighted outside protected area.',38,245,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2026-12-28','Wildlife road collision incident on highway corridor.',15,190,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-10-13','Air quality alert issued due to industrial emissions.',34,289,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-11-23','Water borehole contamination reported by community.',13,311,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-07-19','Chemical discharge into river upstream of settlement.',46,209,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-07-07','Oil spill reported along the shoreline.',28,134,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-06-08','Illegal sand harvesting detected at riverbed.',44,235,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2026-11-28','Air quality alert issued due to industrial emissions.',17,250,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2026-06-20','Algae bloom affecting fish populations in the lake.',47,207,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-11-01','Chemical discharge into river upstream of settlement.',32,283,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-11-17','Charcoal burning operation found inside forest reserve.',8,278,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-03-07','Uncontrolled bush fire spreading toward residential area.',36,195,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-04-16','Poaching snares recovered near wildlife corridor.',8,195,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-12-06','Chemical discharge into river upstream of settlement.',8,196,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2025-09-13','Soil erosion threatening farmland along riverbank.',32,108,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-05-13','Oil spill reported along the shoreline.',20,173,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-09-28','Illegal dumping of industrial waste near water source.',8,241,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-05-05','Algae bloom affecting fish populations in the lake.',37,180,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2026-02-11','Algae bloom affecting fish populations in the lake.',47,314,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2024-10-10','Charcoal burning operation found inside forest reserve.',41,218,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2026-07-08','Chemical discharge into river upstream of settlement.',47,184,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2026-04-18','Air quality alert issued due to industrial emissions.',15,202,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-06-26','Excessive noise pollution from nearby construction.',42,123,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2024-02-20','Water borehole contamination reported by community.',41,304,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-09-10','Plastic waste accumulation blocking drainage channels.',6,150,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2024-04-18','Water borehole contamination reported by community.',34,149,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2024-02-08','Poaching snares recovered near wildlife corridor.',43,237,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-07-17','Sewage overflow contaminating local water supply.',16,313,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2026-06-28','Deforestation activity detected in protected zone.',35,256,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2024-04-02','Algae bloom affecting fish populations in the lake.',2,188,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-02-19','Charcoal burning operation found inside forest reserve.',21,198,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2024-07-22','Plastic waste accumulation blocking drainage channels.',11,174,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2024-07-02','Chemical discharge into river upstream of settlement.',20,205,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-10-28','Uncontrolled bush fire spreading toward residential area.',2,283,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-07-21','Invasive species encroachment reported in wetland.',10,206,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-02-08','Poaching snares recovered near wildlife corridor.',4,152,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Community Empowerment','2025-04-29','Algae bloom affecting fish populations in the lake.',33,293,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-07-05','Oil spill reported along the shoreline.',21,219,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-09-18','Illegal dumping of industrial waste near water source.',27,263,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2025-07-05','Plastic waste accumulation blocking drainage channels.',38,273,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2024-09-14','Soil erosion threatening farmland along riverbank.',37,205,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2026-10-21','Sewage overflow contaminating local water supply.',10,196,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-05-17','Plastic waste accumulation blocking drainage channels.',28,243,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-08-09','Wildlife road collision incident on highway corridor.',19,268,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2024-05-03','Algae bloom affecting fish populations in the lake.',18,254,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2026-02-17','Illegal sand harvesting detected at riverbed.',41,155,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2025-07-30','Oil spill reported along the shoreline.',11,290,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-09-07','Deforestation activity detected in protected zone.',26,279,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-07-26','Flash floods caused by blocked drainage infrastructure.',14,257,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2025-10-13','Invasive species encroachment reported in wetland.',41,167,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-07-16','Excessive noise pollution from nearby construction.',16,270,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Education & Skills Training','2025-03-07','Coral bleaching observed along coastal reef system.',39,185,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2024-09-30','Illegal dumping of industrial waste near water source.',39,222,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2024-12-21','Flash floods caused by blocked drainage infrastructure.',36,279,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Other','2026-03-15','Plastic waste accumulation blocking drainage channels.',6,302,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Infrastructure Development','2024-06-07','Plastic waste accumulation blocking drainage channels.',2,314,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2024-09-09','Illegal sand harvesting detected at riverbed.',25,312,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2024-12-28','Illegal dumping of industrial waste near water source.',8,219,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2026-06-29','Illegal dumping of industrial waste near water source.',15,291,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-01-02','Sewage overflow contaminating local water supply.',6,309,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2025-03-28','Endangered species sighted outside protected area.',32,193,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2025-03-04','Illegal dumping of industrial waste near water source.',13,311,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2025-07-22','Water borehole contamination reported by community.',33,227,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Freshwater Ecosystems','2024-12-25','Deforestation activity detected in protected zone.',38,133,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2025-06-15','Water borehole contamination reported by community.',15,234,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2025-01-27','Illegal dumping of industrial waste near water source.',45,274,'Resolved');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (65,175,9276000,'2025-07-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (1,110,949000,'2024-10-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (111,105,4589000,'2023-09-07');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (175,133,7744000,'2025-10-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (93,133,812000,'2024-04-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (13,72,6982000,'2025-12-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (115,81,184000,'2025-03-13');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (50,86,1440000,'2026-03-17');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (207,7,3796000,'2026-11-13');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (109,20,4195000,'2024-02-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (43,85,5192000,'2023-05-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (161,161,1684000,'2023-02-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (123,111,493000,'2026-04-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (205,161,5577000,'2024-05-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (64,28,7859000,'2024-05-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (88,14,5565000,'2025-11-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (204,61,1294000,'2026-05-13');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (159,113,1667000,'2026-07-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (115,149,2145000,'2023-06-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (16,9,6283000,'2024-10-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (178,17,2189000,'2023-05-07');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (206,114,997000,'2024-09-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (157,161,7175000,'2023-05-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (27,174,1014000,'2026-02-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (14,76,6349000,'2025-04-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (25,159,6835000,'2024-04-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (154,202,273000,'2025-07-17');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (99,119,7114000,'2026-06-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (159,26,5664000,'2026-08-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (173,201,525000,'2025-07-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (133,85,9730000,'2024-01-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (28,27,301000,'2026-05-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (183,18,9813000,'2024-02-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (147,33,8437000,'2024-06-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (91,108,7987000,'2026-06-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (114,48,4083000,'2023-10-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (205,12,1091000,'2023-09-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (80,150,7240000,'2025-11-16');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (167,194,5961000,'2024-09-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (150,139,2485000,'2023-10-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (121,80,9984000,'2024-12-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (75,95,232000,'2025-11-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (151,169,2469000,'2023-04-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (61,130,9266000,'2023-04-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (109,89,3301000,'2024-02-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (164,52,1220000,'2024-11-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (49,171,7894000,'2026-11-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (178,120,9926000,'2026-11-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (85,149,9374000,'2024-11-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (158,77,6959000,'2024-11-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (42,27,7543000,'2023-03-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (127,57,160000,'2026-08-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (58,178,3872000,'2025-08-13');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (160,55,4016000,'2025-09-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (189,197,5531000,'2025-02-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (53,103,3118000,'2023-01-14');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (93,3,1308000,'2025-01-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (8,143,1987000,'2023-10-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (75,113,3285000,'2026-07-16');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (150,196,5996000,'2023-03-31');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (8,51,3341000,'2024-08-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (45,57,4392000,'2023-12-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (87,142,4129000,'2024-01-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (51,6,2984000,'2024-06-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (26,6,2348000,'2025-02-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (168,202,1918000,'2024-11-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (54,79,7574000,'2024-05-06');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (95,208,6200000,'2026-09-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (44,135,7206000,'2026-12-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (17,31,2466000,'2023-09-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (204,49,3240000,'2025-12-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (97,178,6231000,'2024-10-13');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (154,110,4106000,'2023-04-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (196,158,9722000,'2024-01-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (138,76,2534000,'2024-11-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (64,14,4688000,'2023-09-16');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (131,150,8111000,'2024-03-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (187,21,7811000,'2026-09-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (158,17,2843000,'2025-11-07');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (100,193,8442000,'2025-02-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (128,133,7706000,'2024-01-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (83,183,6225000,'2025-12-12');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (178,124,8206000,'2025-08-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (69,149,6669000,'2026-07-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (203,150,699000,'2024-02-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (57,52,7506000,'2024-04-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (102,56,5113000,'2025-05-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (97,147,2675000,'2025-02-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (66,141,1488000,'2023-10-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (193,22,4934000,'2025-06-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (133,91,3871000,'2026-04-10');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (11,120,8492000,'2026-06-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (87,110,7491000,'2025-08-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (111,105,6121000,'2025-10-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (82,70,6364000,'2023-02-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (46,114,3930000,'2024-06-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (166,20,5983000,'2023-06-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (76,129,8501000,'2026-01-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (165,21,4628000,'2024-04-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (26,31,1268000,'2025-01-07');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (10,140,3381000,'2024-11-14');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (51,173,5494000,'2024-05-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (78,191,4596000,'2024-01-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (181,155,2358000,'2026-01-17');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (67,3,5006000,'2024-07-31');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (89,201,6716000,'2025-04-10');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (149,194,294000,'2025-08-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (168,132,2545000,'2025-03-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (59,59,3538000,'2025-08-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (60,133,9717000,'2026-02-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (194,120,7659000,'2024-11-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (203,22,5229000,'2024-01-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (110,198,6943000,'2024-03-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (113,116,9249000,'2023-03-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (96,36,9561000,'2023-09-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (79,189,258000,'2025-10-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (208,169,5910000,'2024-11-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (58,108,7074000,'2026-11-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (193,104,8908000,'2024-09-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (84,151,480000,'2026-03-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (202,9,2379000,'2023-11-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (85,146,9979000,'2026-05-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (147,101,6347000,'2024-02-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (101,17,8857000,'2025-03-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (49,122,1879000,'2024-11-04');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (146,116,5091000,'2023-07-10');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (44,27,9158000,'2023-12-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (9,177,9985000,'2025-09-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (7,48,3360000,'2023-05-23');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (99,73,3473000,'2024-04-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (75,169,8691000,'2023-05-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (117,15,6139000,'2025-11-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (3,44,5453000,'2025-04-21');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (101,41,1914000,'2023-09-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (138,108,7935000,'2023-05-21');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (100,53,2228000,'2024-02-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (80,111,7878000,'2023-11-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (155,148,5184000,'2026-04-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (52,129,7619000,'2024-07-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (52,2,2437000,'2025-07-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (17,103,4144000,'2025-12-12');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (85,146,8143000,'2025-07-31');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (119,148,740000,'2023-07-06');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (74,166,7576000,'2024-12-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (180,183,4973000,'2025-03-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (157,208,2969000,'2025-04-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (64,46,7179000,'2025-07-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (99,169,3105000,'2026-12-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (146,25,6547000,'2026-12-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (12,62,2687000,'2024-07-14');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (161,138,4882000,'2026-09-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (18,179,3659000,'2025-10-07');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (106,196,9157000,'2023-09-06');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (95,20,1823000,'2025-10-30');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (197,200,5441000,'2025-04-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (116,43,4241000,'2024-02-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (130,12,7672000,'2023-02-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (19,164,7667000,'2025-02-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (88,191,6642000,'2024-02-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (102,10,275000,'2024-05-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (30,182,2336000,'2024-10-31');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (172,192,7706000,'2025-09-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (119,18,1452000,'2026-01-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (169,63,7271000,'2023-10-15');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (121,72,2743000,'2023-12-16');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (5,156,1746000,'2023-12-29');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (76,32,8859000,'2025-03-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (44,20,283000,'2026-10-19');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (70,40,7319000,'2025-01-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (46,56,664000,'2026-10-14');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (137,56,7342000,'2026-11-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (13,163,8666000,'2026-08-05');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (170,184,1784000,'2025-03-10');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (177,79,7374000,'2023-04-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (154,2,897000,'2025-02-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (197,52,4191000,'2025-02-06');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (62,52,1597000,'2023-02-02');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (108,8,338000,'2024-11-21');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (50,175,1135000,'2024-03-27');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (25,205,2850000,'2023-12-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (12,107,8496000,'2023-08-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (209,84,5386000,'2026-02-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (161,49,3493000,'2026-01-14');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (102,110,2079000,'2024-04-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (55,28,5942000,'2024-10-24');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (45,4,6688000,'2026-09-01');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (81,4,6476000,'2024-03-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (118,57,1181000,'2026-09-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (209,72,6145000,'2023-03-31');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (18,56,6835000,'2024-09-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (197,154,8285000,'2023-07-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (183,138,9425000,'2023-12-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (65,25,9928000,'2024-10-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (162,179,6466000,'2026-10-20');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (198,178,2277000,'2024-11-11');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (45,163,5309000,'2026-09-26');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (124,18,5590000,'2023-02-06');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (156,150,7454000,'2025-02-22');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (131,164,3908000,'2025-10-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (151,181,317000,'2024-04-21');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (6,258,'Other','2023-09-12','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (189,210,'Other','2024-05-13','Completed',52.94,'2025-05-13');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (96,228,'Waste Management & Circular Economy','2024-02-18','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (53,265,'Public Health & Medicine','2024-05-02','Completed',79.31,'2025-05-02');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (114,290,'Education & Skills Training','2023-10-02','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (165,302,'Other','2023-03-23','Completed',97.9,'2024-03-23');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (166,309,'Waste Management & Circular Economy','2023-02-18','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (188,185,'Education & Skills Training','2024-05-11','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (14,271,'Freshwater Ecosystems','2026-11-08','Completed',60.9,'2027-11-08');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (98,234,'Education & Skills Training','2024-01-11','Completed',50.3,'2025-01-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (126,118,'Freshwater Ecosystems','2023-04-17','Completed',56.94,'2024-04-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (53,133,'WASH (Water, Sanitation & Hygiene)','2023-12-22','Completed',90.73,'2024-12-22');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (53,161,'Agriculture & Food Security','2023-06-10','Completed',72.89,'2024-06-10');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (43,285,'Freshwater Ecosystems','2024-05-16','Completed',79.69,'2025-05-16');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (78,174,'Community Empowerment','2025-07-07','Completed',59.87,'2026-07-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (201,224,'WASH (Water, Sanitation & Hygiene)','2025-01-06','Completed',58.22,'2026-01-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (113,209,'Agriculture & Food Security','2026-06-02','Completed',87.26,'2027-06-02');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (210,304,'Climate Action & Renewable Energy','2023-02-10','Completed',70.94,'2024-02-10');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (22,295,'Waste Management & Circular Economy','2026-05-03','Completed',77.09,'2027-05-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (45,166,'Wildlife Anti-Poaching & Rescue','2025-08-07','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (73,197,'Agriculture & Food Security','2026-05-26','Completed',66.33,'2027-05-26');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (184,221,'Freshwater Ecosystems','2023-11-13','Completed',50.2,'2024-11-13');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (129,287,'Disaster Relief','2025-02-05','Completed',95.36,'2026-02-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (102,291,'Education & Skills Training','2025-02-25','Completed',81.41,'2026-02-25');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (151,119,'Wildlife Anti-Poaching & Rescue','2023-03-21','Completed',56.1,'2024-03-21');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (145,142,'Freshwater Ecosystems','2025-06-12','Completed',87.79,'2026-06-12');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (193,285,'Education & Skills Training','2025-11-09','Completed',81.11,'2026-11-09');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (95,279,'Public Health & Medicine','2026-08-26','Completed',70.78,'2027-08-26');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (64,163,'Climate Action & Renewable Energy','2023-03-12','Completed',67.71,'2024-03-12');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (181,274,'Public Health & Medicine','2026-11-29','Completed',57.25,'2027-11-29');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (155,217,'Infrastructure Development','2023-10-29','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (155,249,'Infrastructure Development','2023-11-27','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (198,124,'Infrastructure Development','2026-12-28','Completed',69.49,'2027-12-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (151,121,'Agriculture & Food Security','2024-01-22','Completed',58.13,'2025-01-22');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (110,165,'Disaster Relief','2024-09-10','Completed',76.13,'2025-09-10');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (98,251,'Waste Management & Circular Economy','2025-04-22','Completed',95.29,'2026-04-22');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (23,128,'Infrastructure Development','2026-03-18','Completed',66.88,'2027-03-18');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (37,169,'Disaster Relief','2024-03-05','Completed',69.5,'2025-03-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (79,102,'Marine & Coastal Conservation','2025-10-04','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (18,299,'Disaster Relief','2025-05-05','Completed',82.07,'2026-05-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (188,211,'Marine & Coastal Conservation','2023-12-28','Completed',84.5,'2024-12-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (51,225,'Marine & Coastal Conservation','2025-10-26','Completed',72.08,'2026-10-26');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (209,155,'Marine & Coastal Conservation','2024-02-16','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (47,308,'Other','2024-01-28','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (105,213,'Infrastructure Development','2026-07-02','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (163,143,'WASH (Water, Sanitation & Hygiene)','2024-08-23','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (32,171,'WASH (Water, Sanitation & Hygiene)','2024-12-01','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (61,223,'Climate Action & Renewable Energy','2026-10-09','Completed',50.47,'2027-10-09');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (69,293,'Public Health & Medicine','2026-09-24','Completed',98.39,'2027-09-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (25,155,'Agriculture & Food Security','2023-01-15','Completed',75.48,'2024-01-15');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (195,169,'Climate Action & Renewable Energy','2025-08-27','Completed',79.61,'2026-08-27');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (87,195,'Infrastructure Development','2024-12-03','Completed',90.03,'2025-12-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (93,271,'Wildlife Anti-Poaching & Rescue','2025-02-14','Completed',97.79,'2026-02-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (85,307,'WASH (Water, Sanitation & Hygiene)','2023-01-07','Completed',84.22,'2024-01-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (186,314,'Marine & Coastal Conservation','2023-02-22','Completed',92.58,'2024-02-22');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (72,280,'Other','2024-05-24','Completed',80.3,'2025-05-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (169,222,'Agriculture & Food Security','2025-04-26','Completed',50.15,'2026-04-26');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (164,309,'Education & Skills Training','2023-02-04','Completed',92.8,'2024-02-04');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (207,289,'Education & Skills Training','2026-10-20','Completed',79.73,'2027-10-20');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (103,290,'Community Empowerment','2023-06-16','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (122,269,'Disaster Relief','2023-07-25','Completed',64.4,'2024-07-25');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (50,283,'Marine & Coastal Conservation','2025-12-01','Completed',88.46,'2026-12-01');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (184,230,'Public Health & Medicine','2023-09-19','Completed',54.27,'2024-09-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (173,241,'Climate Action & Renewable Energy','2023-12-11','Completed',96.8,'2024-12-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (124,270,'Agriculture & Food Security','2024-05-08','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (44,293,'Infrastructure Development','2026-12-04','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (112,284,'Public Health & Medicine','2023-11-25','Completed',66.0,'2024-11-25');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (99,297,'Waste Management & Circular Economy','2024-03-27','Completed',82.63,'2025-03-27');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (172,132,'Infrastructure Development','2023-10-06','Completed',81.04,'2024-10-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (126,124,'Other','2026-11-17','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (58,248,'Other','2026-05-15','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (88,197,'Disaster Relief','2025-02-20','Completed',88.47,'2026-02-20');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (112,307,'Freshwater Ecosystems','2024-04-02','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (75,123,'WASH (Water, Sanitation & Hygiene)','2023-07-02','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (152,149,'Disaster Relief','2023-08-26','Completed',56.24,'2024-08-26');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (81,198,'Community Empowerment','2023-01-04','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (152,238,'Freshwater Ecosystems','2025-03-05','Completed',65.66,'2026-03-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (94,305,'Infrastructure Development','2023-09-16','Completed',79.48,'2024-09-16');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (57,128,'Wildlife Anti-Poaching & Rescue','2023-01-19','Completed',72.57,'2024-01-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (38,309,'Waste Management & Circular Economy','2024-03-24','Completed',72.33,'2025-03-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (154,173,'Marine & Coastal Conservation','2026-09-24','Completed',90.56,'2027-09-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (9,254,'Education & Skills Training','2024-09-24','Completed',83.74,'2025-09-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (71,281,'Community Empowerment','2025-09-06','Completed',60.57,'2026-09-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (75,281,'Wildlife Anti-Poaching & Rescue','2023-05-01','Completed',66.32,'2024-05-01');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (184,154,'Disaster Relief','2024-04-05','Completed',52.58,'2025-04-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (199,146,'Climate Action & Renewable Energy','2025-03-13','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (209,269,'Marine & Coastal Conservation','2023-02-14','Completed',66.53,'2024-02-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (174,222,'Education & Skills Training','2025-03-12','Completed',75.86,'2026-03-12');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (73,173,'Disaster Relief','2024-02-04','Completed',76.85,'2025-02-04');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (25,134,'Education & Skills Training','2026-04-03','Completed',52.65,'2027-04-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (182,178,'Climate Action & Renewable Energy','2026-09-02','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (36,214,'Disaster Relief','2025-09-15','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (38,154,'Freshwater Ecosystems','2024-02-05','Completed',50.45,'2025-02-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (186,248,'WASH (Water, Sanitation & Hygiene)','2026-10-21','Completed',92.06,'2027-10-21');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (97,210,'Infrastructure Development','2023-12-11','Completed',54.71,'2024-12-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (122,146,'Public Health & Medicine','2023-08-29','Completed',81.85,'2024-08-29');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (152,212,'Marine & Coastal Conservation','2026-07-08','Completed',62.01,'2027-07-08');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (31,162,'Wildlife Anti-Poaching & Rescue','2025-09-27','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (153,145,'Infrastructure Development','2025-02-07','Completed',98.57,'2026-02-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (172,269,'WASH (Water, Sanitation & Hygiene)','2025-08-07','Completed',81.87,'2026-08-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (71,262,'Infrastructure Development','2025-06-30','Completed',55.88,'2026-06-30');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (22,132,'Climate Action & Renewable Energy','2026-08-06','Completed',74.98,'2027-08-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (6,251,'Community Empowerment','2026-03-18','Completed',83.99,'2027-03-18');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (25,304,'Community Empowerment','2024-01-06','Completed',99.0,'2025-01-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (180,212,'Waste Management & Circular Economy','2026-03-16','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (84,117,'Disaster Relief','2026-01-05','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (209,280,'Public Health & Medicine','2025-03-17','Completed',76.28,'2026-03-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (208,236,'Climate Action & Renewable Energy','2023-05-11','Completed',78.65,'2024-05-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (183,310,'Other','2026-08-27','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (193,154,'Infrastructure Development','2023-08-29','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (154,278,'Marine & Coastal Conservation','2023-01-11','Completed',89.23,'2024-01-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (32,111,'Marine & Coastal Conservation','2026-03-23','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (42,123,'Agriculture & Food Security','2024-06-09','Completed',51.72,'2025-06-09');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (32,230,'Waste Management & Circular Economy','2025-01-14','Completed',58.41,'2026-01-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (169,101,'Freshwater Ecosystems','2024-09-07','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (133,301,'Waste Management & Circular Economy','2026-09-11','Completed',56.85,'2027-09-11');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (126,278,'Education & Skills Training','2025-12-06','Completed',98.84,'2026-12-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (156,238,'Agriculture & Food Security','2024-03-05','Completed',82.47,'2025-03-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (12,161,'Public Health & Medicine','2024-01-21','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (56,135,'Community Empowerment','2026-02-04','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (92,172,'Marine & Coastal Conservation','2026-06-28','Completed',76.94,'2027-06-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (67,198,'Infrastructure Development','2023-12-01','Completed',54.08,'2024-12-01');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (66,274,'Wildlife Anti-Poaching & Rescue','2026-11-23','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (53,119,'Infrastructure Development','2024-07-05','Completed',84.14,'2025-07-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (50,283,'Education & Skills Training','2026-02-28','Completed',90.2,'2027-02-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (155,142,'Wildlife Anti-Poaching & Rescue','2023-11-11','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (202,212,'Wildlife Anti-Poaching & Rescue','2023-02-23','Completed',62.13,'2024-02-23');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (70,132,'Agriculture & Food Security','2023-08-14','Completed',69.93,'2024-08-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (85,264,'WASH (Water, Sanitation & Hygiene)','2025-01-13','Completed',88.13,'2026-01-13');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (38,305,'Freshwater Ecosystems','2024-07-14','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (97,157,'Wildlife Anti-Poaching & Rescue','2023-08-04','Completed',56.05,'2024-08-04');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (135,287,'Waste Management & Circular Economy','2026-04-20','Completed',73.99,'2027-04-20');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (136,190,'Disaster Relief','2026-03-17','Completed',77.03,'2027-03-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (156,126,'Public Health & Medicine','2023-12-16','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (193,200,'Marine & Coastal Conservation','2024-12-07','Completed',83.21,'2025-12-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (202,237,'Agriculture & Food Security','2026-05-02','Completed',69.73,'2027-05-02');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (152,133,'Waste Management & Circular Economy','2023-01-20','Completed',84.95,'2024-01-20');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (169,133,'Marine & Coastal Conservation','2025-02-14','Completed',63.1,'2026-02-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (186,264,'Education & Skills Training','2026-12-19','Completed',83.23,'2027-12-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (108,281,'Climate Action & Renewable Energy','2024-01-10','Completed',67.35,'2025-01-10');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (120,229,'Waste Management & Circular Economy','2024-07-18','Completed',75.51,'2025-07-18');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (184,309,'Freshwater Ecosystems','2024-09-17','Completed',54.26,'2025-09-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (79,205,'Other','2024-10-02','Completed',81.1,'2025-10-02');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (20,287,'Freshwater Ecosystems','2023-07-11','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (15,122,'Disaster Relief','2024-08-08','Completed',74.15,'2025-08-08');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (3,209,'Infrastructure Development','2025-11-07','Completed',56.68,'2026-11-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (128,232,'Infrastructure Development','2026-10-18','Completed',84.2,'2027-10-18');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (104,104,'Community Empowerment','2024-01-25','Completed',86.55,'2025-01-25');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (183,209,'Disaster Relief','2025-12-30','Completed',61.97,'2026-12-30');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (190,270,'Agriculture & Food Security','2026-11-01','Completed',79.76,'2027-11-01');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (44,273,'Other','2025-12-08','Completed',58.57,'2026-12-08');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (94,315,'Marine & Coastal Conservation','2025-11-18','Completed',52.49,'2026-11-18');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (127,198,'Marine & Coastal Conservation','2025-02-03','Completed',66.56,'2026-02-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (174,164,'Agriculture & Food Security','2023-08-30','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (124,176,'Waste Management & Circular Economy','2024-03-12','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (162,246,'Wildlife Anti-Poaching & Rescue','2024-03-21','Completed',95.53,'2025-03-21');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (165,232,'Public Health & Medicine','2025-08-06','Completed',91.57,'2026-08-06');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (15,192,'Public Health & Medicine','2026-06-14','Completed',64.62,'2027-06-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (28,102,'Education & Skills Training','2024-01-17','Completed',50.43,'2025-01-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (111,226,'Freshwater Ecosystems','2023-06-23','Completed',94.03,'2024-06-23');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (106,132,'Climate Action & Renewable Energy','2023-01-15','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (169,165,'Freshwater Ecosystems','2025-08-21','Completed',64.66,'2026-08-21');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (110,147,'Agriculture & Food Security','2024-07-05','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (113,269,'Climate Action & Renewable Energy','2023-11-28','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (192,212,'Public Health & Medicine','2025-01-05','Completed',84.75,'2026-01-05');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (29,149,'Waste Management & Circular Economy','2023-03-24','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (108,291,'Education & Skills Training','2023-03-06','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (51,223,'Infrastructure Development','2024-06-28','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (126,241,'Climate Action & Renewable Energy','2026-10-28','Completed',65.92,'2027-10-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (196,300,'Wildlife Anti-Poaching & Rescue','2025-10-24','Completed',86.35,'2026-10-24');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (100,134,'WASH (Water, Sanitation & Hygiene)','2023-08-09','Completed',56.18,'2024-08-09');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (89,229,'Public Health & Medicine','2026-11-02','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (174,313,'Education & Skills Training','2025-05-29','Completed',86.13,'2026-05-29');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (112,223,'Waste Management & Circular Economy','2024-07-31','Completed',87.28,'2025-07-31');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (64,259,'Marine & Coastal Conservation','2025-11-13','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (72,297,'WASH (Water, Sanitation & Hygiene)','2024-06-23','Completed',62.12,'2025-06-23');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (110,151,'Climate Action & Renewable Energy','2026-12-17','Completed',55.05,'2027-12-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (187,229,'Community Empowerment','2024-01-07','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (152,262,'Infrastructure Development','2023-11-01','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (34,203,'Public Health & Medicine','2024-07-14','Completed',95.53,'2025-07-14');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (110,105,'Community Empowerment','2024-02-13','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (14,198,'Wildlife Anti-Poaching & Rescue','2025-12-11','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (163,160,'Freshwater Ecosystems','2024-11-19','Completed',53.01,'2025-11-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (110,265,'Public Health & Medicine','2024-09-15','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (94,172,'Education & Skills Training','2026-12-28','Completed',65.67,'2027-12-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (13,147,'Public Health & Medicine','2023-01-02','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (191,183,'Freshwater Ecosystems','2024-08-07','Completed',94.52,'2025-08-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (26,211,'Marine & Coastal Conservation','2024-05-31','Completed',67.82,'2025-05-31');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (78,129,'WASH (Water, Sanitation & Hygiene)','2026-10-02','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (142,298,'Marine & Coastal Conservation','2024-11-09','Completed',89.69,'2025-11-09');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (191,300,'Community Empowerment','2025-12-19','Completed',61.67,'2026-12-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (71,154,'Community Empowerment','2025-02-25','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (28,134,'Infrastructure Development','2026-05-17','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (151,268,'Freshwater Ecosystems','2024-01-31','Completed',95.35,'2025-01-31');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (20,240,'Community Empowerment','2024-12-03','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (122,295,'Freshwater Ecosystems','2025-12-28','Completed',52.15,'2026-12-28');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (50,208,'Agriculture & Food Security','2026-12-28','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (195,244,'Education & Skills Training','2025-01-19','Completed',85.15,'2026-01-19');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (112,118,'Climate Action & Renewable Energy','2025-05-08','Completed',96.67,'2026-05-08');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (203,106,'Marine & Coastal Conservation','2026-05-12','In Progress',NULL,NULL);
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Carbon Sequestration Rates — Study 11','Public Health & Medicine',245,4,'2026-04-01','2029-04-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Marine Biodiversity — Study 12','Climate Action & Renewable Energy',293,33,'2025-09-01','2027-09-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Marine Biodiversity — Study 13','Public Health & Medicine',141,37,'2024-10-01','2027-10-01','Proposed','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Carbon Sequestration Rates — Study 14','Freshwater Ecosystems',176,46,'2025-09-01','2026-09-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Carbon Sequestration Rates — Study 15','Public Health & Medicine',264,10,'2025-03-01','2027-03-01','Published','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Wildlife Population Trends — Study 16','Agriculture & Food Security',130,1,'2026-06-01','2029-06-01','Data Analysis','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Air Pollution Levels — Study 17','Disaster Relief',241,17,'2026-03-01','2028-03-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Soil Biodiversity — Study 18','Infrastructure Development',309,1,'2025-04-01','2028-04-01','Published','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Groundwater Quality — Study 19','Agriculture & Food Security',269,38,'2024-12-01','2027-12-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of River Flow Rates — Study 20','Freshwater Ecosystems',184,18,'2024-10-01','2027-10-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring River Flow Rates — Study 21','Freshwater Ecosystems',287,47,'2025-06-01','2026-06-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Marine Biodiversity — Study 22','Climate Action & Renewable Energy',148,12,'2024-10-01','2026-10-01','Published','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Groundwater Quality — Study 23','Waste Management & Circular Economy',142,12,'2025-11-01','2028-11-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Coral Reef Health — Study 24','Freshwater Ecosystems',217,42,'2025-02-01','2028-02-01','Data Analysis','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Invasive Species Spread — Study 25','Wildlife Anti-Poaching & Rescue',106,8,'2024-11-01','2025-11-01','Proposed','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Wetland Extent — Study 26','Infrastructure Development',254,1,'2024-02-01','2027-02-01','Data Analysis','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Wildlife Population Trends — Study 27','Marine & Coastal Conservation',223,37,'2025-03-01','2027-03-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Soil Biodiversity — Study 28','Agriculture & Food Security',278,18,'2026-09-01','2027-09-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Carbon Sequestration Rates — Study 29','WASH (Water, Sanitation & Hygiene)',231,27,'2024-01-01','2025-01-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Wetland Extent — Study 30','Education & Skills Training',268,19,'2024-11-01','2026-11-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Marine Biodiversity — Study 31','WASH (Water, Sanitation & Hygiene)',158,7,'2025-06-01','2026-06-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Air Pollution Levels — Study 32','Public Health & Medicine',255,10,'2024-07-01','2027-07-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Wetland Extent — Study 33','Infrastructure Development',276,20,'2026-05-01','2028-05-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Heavy Metal Contamination — Study 34','Waste Management & Circular Economy',308,46,'2024-01-01','2025-01-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Wetland Extent — Study 35','Wildlife Anti-Poaching & Rescue',215,47,'2025-02-01','2026-02-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Air Pollution Levels — Study 36','Education & Skills Training',133,12,'2025-06-01','2027-06-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Plastic Pollution — Study 37','Marine & Coastal Conservation',306,42,'2024-07-01','2026-07-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Invasive Species Spread — Study 38','WASH (Water, Sanitation & Hygiene)',249,46,'2025-09-01','2028-09-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Agricultural Yield Patterns — Study 39','Education & Skills Training',101,14,'2024-06-01','2027-06-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Soil Biodiversity — Study 40','Education & Skills Training',193,9,'2025-08-01','2026-08-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Wildlife Population Trends — Study 41','Freshwater Ecosystems',115,9,'2024-12-01','2027-12-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Heavy Metal Contamination — Study 42','Public Health & Medicine',280,7,'2026-10-01','2027-10-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Wetland Extent — Study 43','Education & Skills Training',137,6,'2024-02-01','2025-02-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Marine Biodiversity — Study 44','Climate Action & Renewable Energy',291,9,'2026-09-01','2029-09-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Plastic Pollution — Study 45','Climate Action & Renewable Energy',301,42,'2026-01-01','2028-01-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Marine Biodiversity — Study 46','Agriculture & Food Security',142,1,'2025-07-01','2028-07-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Carbon Sequestration Rates — Study 47','Disaster Relief',159,28,'2024-05-01','2025-05-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Invasive Species Spread — Study 48','Community Empowerment',115,15,'2025-03-01','2028-03-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Lake Salinity Levels — Study 49','Education & Skills Training',268,42,'2025-07-01','2026-07-01','Proposed','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Wildlife Population Trends — Study 50','Waste Management & Circular Economy',128,7,'2024-06-01','2027-06-01','Data Analysis','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Agricultural Yield Patterns — Study 51','Waste Management & Circular Economy',142,35,'2024-02-01','2025-02-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Wildlife Population Trends — Study 52','Infrastructure Development',109,16,'2025-02-01','2028-02-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Soil Biodiversity — Study 53','Education & Skills Training',124,20,'2024-06-01','2026-06-01','Published','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Invasive Species Spread — Study 54','Disaster Relief',192,9,'2026-11-01','2027-11-01','Data Collection','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Groundwater Quality — Study 55','Community Empowerment',304,25,'2025-10-01','2026-10-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Air Pollution Levels — Study 56','Infrastructure Development',124,46,'2024-04-01','2027-04-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of River Flow Rates — Study 57','Other',134,22,'2025-06-01','2028-06-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Invasive Species Spread — Study 58','Freshwater Ecosystems',154,40,'2026-02-01','2027-02-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Groundwater Quality — Study 59','Marine & Coastal Conservation',297,20,'2026-02-01','2028-02-01','Proposed','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Carbon Sequestration Rates — Study 60','Marine & Coastal Conservation',118,18,'2026-06-01','2028-06-01','Proposed','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Urban Heat Island Effect — Study 61','Climate Action & Renewable Energy',166,29,'2026-03-01','2027-03-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Heavy Metal Contamination — Study 62','Waste Management & Circular Economy',203,27,'2026-11-01','2027-11-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Air Pollution Levels — Study 63','Infrastructure Development',206,33,'2025-05-01','2028-05-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Groundwater Quality — Study 64','Marine & Coastal Conservation',127,19,'2025-03-01','2028-03-01','Data Collection','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Invasive Species Spread — Study 65','Climate Action & Renewable Energy',272,6,'2025-08-01','2027-08-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Air Pollution Levels — Study 66','Marine & Coastal Conservation',288,7,'2025-07-01','2026-07-01','Data Collection','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Plastic Pollution — Study 67','Community Empowerment',225,14,'2026-12-01','2028-12-01','Proposed','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Wetland Extent — Study 68','Climate Action & Renewable Energy',138,41,'2024-06-01','2027-06-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Heavy Metal Contamination — Study 69','Other',211,31,'2024-01-01','2025-01-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Urban Heat Island Effect — Study 70','Infrastructure Development',146,6,'2024-02-01','2026-02-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Coral Reef Health — Study 71','Agriculture & Food Security',155,43,'2025-03-01','2026-03-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Carbon Sequestration Rates — Study 72','Marine & Coastal Conservation',151,23,'2025-08-01','2027-08-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Heavy Metal Contamination — Study 73','Disaster Relief',247,25,'2024-09-01','2027-09-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Plastic Pollution — Study 74','Public Health & Medicine',139,30,'2024-08-01','2026-08-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Groundwater Quality — Study 75','Climate Action & Renewable Energy',314,9,'2026-08-01','2029-08-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Wildlife Population Trends — Study 76','Disaster Relief',149,27,'2026-09-01','2027-09-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Wildlife Population Trends — Study 77','Freshwater Ecosystems',274,37,'2024-06-01','2026-06-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Lake Salinity Levels — Study 78','Infrastructure Development',217,27,'2025-06-01','2027-06-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Forest Cover Change — Study 79','Marine & Coastal Conservation',218,28,'2025-03-01','2028-03-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Carbon Sequestration Rates — Study 80','Infrastructure Development',277,44,'2025-11-01','2027-11-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Forest Cover Change — Study 81','WASH (Water, Sanitation & Hygiene)',267,2,'2026-07-01','2027-07-01','Data Collection','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Soil Biodiversity — Study 82','Infrastructure Development',175,27,'2024-04-01','2026-04-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Lake Salinity Levels — Study 83','WASH (Water, Sanitation & Hygiene)',190,30,'2025-11-01','2028-11-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Heavy Metal Contamination — Study 84','Other',158,33,'2025-05-01','2028-05-01','Data Collection','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Groundwater Quality — Study 85','Wildlife Anti-Poaching & Rescue',109,1,'2024-03-01','2026-03-01','Published','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Marine Biodiversity — Study 86','Community Empowerment',211,16,'2026-07-01','2027-07-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Coral Reef Health — Study 87','Marine & Coastal Conservation',263,25,'2026-03-01','2028-03-01','Published','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Agricultural Yield Patterns — Study 88','WASH (Water, Sanitation & Hygiene)',282,9,'2026-02-01','2029-02-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Marine Biodiversity — Study 89','Education & Skills Training',153,6,'2024-01-01','2026-01-01','Proposed','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Air Pollution Levels — Study 90','Community Empowerment',198,2,'2026-12-01','2027-12-01','Published','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Agricultural Yield Patterns — Study 91','Infrastructure Development',157,20,'2024-09-01','2025-09-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Soil Biodiversity — Study 92','Waste Management & Circular Economy',122,10,'2026-01-01','2029-01-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of River Flow Rates — Study 93','Community Empowerment',132,7,'2024-05-01','2026-05-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Lake Salinity Levels — Study 94','Education & Skills Training',315,14,'2025-02-01','2027-02-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Lake Salinity Levels — Study 95','Infrastructure Development',120,14,'2026-07-01','2028-07-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Marine Biodiversity — Study 96','Waste Management & Circular Economy',103,12,'2026-10-01','2029-10-01','Data Analysis','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Plastic Pollution — Study 97','Education & Skills Training',224,40,'2026-09-01','2027-09-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Wildlife Population Trends — Study 98','Community Empowerment',108,35,'2024-09-01','2027-09-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Forest Cover Change — Study 99','Freshwater Ecosystems',108,21,'2024-04-01','2025-04-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Urban Heat Island Effect — Study 100','Climate Action & Renewable Energy',152,6,'2025-12-01','2028-12-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Coral Reef Health — Study 101','Agriculture & Food Security',203,13,'2025-03-01','2026-03-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Forest Cover Change — Study 102','Community Empowerment',304,38,'2025-03-01','2026-03-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling River Flow Rates — Study 103','Wildlife Anti-Poaching & Rescue',253,18,'2025-10-01','2026-10-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Heavy Metal Contamination — Study 104','Education & Skills Training',262,5,'2025-03-01','2026-03-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Carbon Sequestration Rates — Study 105','Community Empowerment',312,42,'2026-06-01','2028-06-01','Proposed','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Coral Reef Health — Study 106','Other',148,23,'2024-02-01','2025-02-01','Data Analysis','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Plastic Pollution — Study 107','WASH (Water, Sanitation & Hygiene)',103,21,'2026-01-01','2029-01-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Agricultural Yield Patterns — Study 108','Agriculture & Food Security',117,25,'2025-10-01','2026-10-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Air Pollution Levels — Study 109','Community Empowerment',266,27,'2026-07-01','2028-07-01','Published','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Soil Biodiversity — Study 110','Other',227,32,'2024-05-01','2026-05-01','Proposed','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Plastic Pollution — Study 111','Community Empowerment',199,16,'2026-01-01','2028-01-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Carbon Sequestration Rates — Study 112','Marine & Coastal Conservation',204,3,'2026-09-01','2027-09-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Lake Salinity Levels — Study 113','WASH (Water, Sanitation & Hygiene)',313,27,'2026-05-01','2028-05-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Air Pollution Levels — Study 114','Agriculture & Food Security',299,21,'2025-10-01','2026-10-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Forest Cover Change — Study 115','Education & Skills Training',259,7,'2024-04-01','2025-04-01','Published','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Plastic Pollution — Study 116','Disaster Relief',286,28,'2024-03-01','2025-03-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Soil Biodiversity — Study 117','Waste Management & Circular Economy',301,3,'2024-01-01','2026-01-01','Proposed','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Urban Heat Island Effect — Study 118','Disaster Relief',144,9,'2026-08-01','2027-08-01','Proposed','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling River Flow Rates — Study 119','Infrastructure Development',132,34,'2026-04-01','2029-04-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Plastic Pollution — Study 120','Other',288,31,'2024-02-01','2026-02-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Agricultural Yield Patterns — Study 121','Infrastructure Development',266,14,'2026-02-01','2027-02-01','Published','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Groundwater Quality — Study 122','Infrastructure Development',156,30,'2025-04-01','2027-04-01','Proposed','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Carbon Sequestration Rates — Study 123','Disaster Relief',217,42,'2024-09-01','2025-09-01','Published','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Invasive Species Spread — Study 124','Climate Action & Renewable Energy',259,33,'2024-07-01','2025-07-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Carbon Sequestration Rates — Study 125','Community Empowerment',266,7,'2024-08-01','2025-08-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of River Flow Rates — Study 126','Marine & Coastal Conservation',169,2,'2025-11-01','2028-11-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Air Pollution Levels — Study 127','Education & Skills Training',211,14,'2024-07-01','2027-07-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of River Flow Rates — Study 128','Waste Management & Circular Economy',195,7,'2024-11-01','2026-11-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Carbon Sequestration Rates — Study 129','Freshwater Ecosystems',204,12,'2026-05-01','2029-05-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Soil Biodiversity — Study 130','Infrastructure Development',164,8,'2024-02-01','2025-02-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Air Pollution Levels — Study 131','Agriculture & Food Security',126,18,'2024-10-01','2027-10-01','Data Analysis','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Forest Cover Change — Study 132','Freshwater Ecosystems',288,45,'2025-08-01','2026-08-01','Data Collection','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Carbon Sequestration Rates — Study 133','Disaster Relief',253,19,'2026-01-01','2027-01-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Agricultural Yield Patterns — Study 134','Marine & Coastal Conservation',181,44,'2024-03-01','2025-03-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Groundwater Quality — Study 135','Infrastructure Development',222,28,'2025-01-01','2026-01-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Groundwater Quality — Study 136','Community Empowerment',191,31,'2026-01-01','2028-01-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Soil Biodiversity — Study 137','Public Health & Medicine',246,44,'2025-04-01','2028-04-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Forest Cover Change — Study 138','Waste Management & Circular Economy',306,22,'2025-08-01','2028-08-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Urban Heat Island Effect — Study 139','Education & Skills Training',218,1,'2025-05-01','2028-05-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Urban Heat Island Effect — Study 140','Infrastructure Development',233,47,'2026-01-01','2027-01-01','Published','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Heavy Metal Contamination — Study 141','Climate Action & Renewable Energy',108,16,'2026-12-01','2029-12-01','Published','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Air Pollution Levels — Study 142','Freshwater Ecosystems',197,41,'2024-05-01','2027-05-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Urban Heat Island Effect — Study 143','Infrastructure Development',190,22,'2025-10-01','2027-10-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Wildlife Population Trends — Study 144','Public Health & Medicine',249,34,'2026-06-01','2029-06-01','Proposed','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Carbon Sequestration Rates — Study 145','WASH (Water, Sanitation & Hygiene)',103,32,'2026-03-01','2028-03-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Carbon Sequestration Rates — Study 146','Climate Action & Renewable Energy',174,5,'2025-01-01','2027-01-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Soil Biodiversity — Study 147','Climate Action & Renewable Energy',179,1,'2025-06-01','2028-06-01','Published','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Wetland Extent — Study 148','Education & Skills Training',173,33,'2026-09-01','2027-09-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Wildlife Population Trends — Study 149','Wildlife Anti-Poaching & Rescue',250,6,'2025-04-01','2026-04-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Invasive Species Spread — Study 150','Wildlife Anti-Poaching & Rescue',203,7,'2025-05-01','2028-05-01','Data Collection','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Wetland Extent — Study 151','Infrastructure Development',297,13,'2025-03-01','2027-03-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Air Pollution Levels — Study 152','Waste Management & Circular Economy',246,41,'2025-09-01','2026-09-01','Data Collection','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Wetland Extent — Study 153','Agriculture & Food Security',214,45,'2025-09-01','2028-09-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Coral Reef Health — Study 154','Climate Action & Renewable Energy',208,27,'2025-01-01','2028-01-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Wetland Extent — Study 155','Community Empowerment',178,16,'2026-09-01','2028-09-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Invasive Species Spread — Study 156','Marine & Coastal Conservation',204,43,'2024-08-01','2027-08-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Soil Biodiversity — Study 157','Waste Management & Circular Economy',313,42,'2024-06-01','2027-06-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Plastic Pollution — Study 158','Public Health & Medicine',132,38,'2026-09-01','2029-09-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Lake Salinity Levels — Study 159','Marine & Coastal Conservation',158,44,'2026-03-01','2028-03-01','Data Analysis','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Wildlife Population Trends — Study 160','WASH (Water, Sanitation & Hygiene)',118,1,'2024-10-01','2025-10-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Forest Cover Change — Study 161','Climate Action & Renewable Energy',107,33,'2025-07-01','2026-07-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Lake Salinity Levels — Study 162','Marine & Coastal Conservation',310,16,'2026-05-01','2029-05-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Wetland Extent — Study 163','Infrastructure Development',106,12,'2024-12-01','2027-12-01','Data Collection','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Lake Salinity Levels — Study 164','Waste Management & Circular Economy',175,43,'2024-10-01','2026-10-01','Data Collection','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Invasive Species Spread — Study 165','Disaster Relief',305,7,'2025-07-01','2027-07-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Forest Cover Change — Study 166','Community Empowerment',200,1,'2026-05-01','2027-05-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Heavy Metal Contamination — Study 167','Marine & Coastal Conservation',220,47,'2025-05-01','2026-05-01','Published','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Heavy Metal Contamination — Study 168','Disaster Relief',235,25,'2026-02-01','2027-02-01','Data Analysis','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of River Flow Rates — Study 169','Disaster Relief',302,9,'2025-11-01','2027-11-01','Published','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Invasive Species Spread — Study 170','Climate Action & Renewable Energy',256,43,'2024-10-01','2027-10-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Plastic Pollution — Study 171','Community Empowerment',249,23,'2026-10-01','2028-10-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Agricultural Yield Patterns — Study 172','WASH (Water, Sanitation & Hygiene)',271,7,'2025-11-01','2027-11-01','Data Collection','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Forest Cover Change — Study 173','Marine & Coastal Conservation',287,25,'2025-02-01','2026-02-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Air Pollution Levels — Study 174','Climate Action & Renewable Energy',296,24,'2026-11-01','2027-11-01','Published','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of River Flow Rates — Study 175','Wildlife Anti-Poaching & Rescue',135,41,'2026-09-01','2027-09-01','Data Collection','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Carbon Sequestration Rates — Study 176','Freshwater Ecosystems',152,11,'2025-09-01','2026-09-01','Proposed','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Wildlife Population Trends — Study 177','Public Health & Medicine',308,9,'2024-06-01','2026-06-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Marine Biodiversity — Study 178','Infrastructure Development',287,47,'2026-09-01','2028-09-01','Data Collection','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Heavy Metal Contamination — Study 179','Education & Skills Training',259,36,'2024-02-01','2026-02-01','Data Collection','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Air Pollution Levels — Study 180','Marine & Coastal Conservation',301,34,'2025-02-01','2026-02-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Groundwater Quality — Study 181','Freshwater Ecosystems',311,19,'2025-07-01','2028-07-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Air Pollution Levels — Study 182','Agriculture & Food Security',248,16,'2026-10-01','2029-10-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Lake Salinity Levels — Study 183','Waste Management & Circular Economy',268,2,'2024-06-01','2026-06-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Wetland Extent — Study 184','Freshwater Ecosystems',241,47,'2025-11-01','2026-11-01','Data Collection','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Heavy Metal Contamination — Study 185','WASH (Water, Sanitation & Hygiene)',207,39,'2026-10-01','2027-10-01','Published','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Urban Heat Island Effect — Study 186','Disaster Relief',111,7,'2024-08-01','2027-08-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Lake Salinity Levels — Study 187','Waste Management & Circular Economy',301,15,'2024-01-01','2025-01-01','Data Analysis','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Modelling Groundwater Quality — Study 188','Agriculture & Food Security',224,4,'2025-07-01','2028-07-01','Proposed','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Forest Cover Change — Study 189','Climate Action & Renewable Energy',131,40,'2025-06-01','2026-06-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Agricultural Yield Patterns — Study 190','WASH (Water, Sanitation & Hygiene)',251,1,'2024-07-01','2027-07-01','Data Analysis','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Agricultural Yield Patterns — Study 191','Public Health & Medicine',120,4,'2024-08-01','2025-08-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Agricultural Yield Patterns — Study 192','Waste Management & Circular Economy',134,39,'2025-08-01','2028-08-01','Proposed','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Urban Heat Island Effect — Study 193','Agriculture & Food Security',153,32,'2026-12-01','2028-12-01','Published','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Carbon Sequestration Rates — Study 194','Education & Skills Training',300,36,'2025-11-01','2026-11-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Forest Cover Change — Study 195','Public Health & Medicine',189,27,'2026-10-01','2028-10-01','Data Collection','Modelling future climate scenarios and their effect on local ecosystems.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Agricultural Yield Patterns — Study 196','Waste Management & Circular Economy',290,36,'2024-02-01','2026-02-01','Data Analysis','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Agricultural Yield Patterns — Study 197','Disaster Relief',213,42,'2025-02-01','2026-02-01','Data Collection','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Urban Heat Island Effect — Study 198','Community Empowerment',199,20,'2024-01-01','2026-01-01','Published','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Groundwater Quality — Study 199','Wildlife Anti-Poaching & Rescue',199,29,'2024-04-01','2025-04-01','Data Collection','Remote sensing analysis combined with ground-truthing for habitat mapping.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Assessment of Carbon Sequestration Rates — Study 200','Public Health & Medicine',239,23,'2024-10-01','2026-10-01','Published','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Evaluation of Groundwater Quality — Study 201','Education & Skills Training',286,40,'2025-07-01','2028-07-01','Published','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Invasive Species Spread — Study 202','Disaster Relief',274,19,'2026-08-01','2028-08-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Invasive Species Spread — Study 203','Climate Action & Renewable Energy',291,16,'2024-01-01','2026-01-01','Data Analysis','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Impact of Agricultural Yield Patterns — Study 204','Other',239,19,'2025-10-01','2027-10-01','Proposed','Community-based monitoring of natural resources in rural county settings.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Urban Heat Island Effect — Study 205','Infrastructure Development',165,42,'2026-01-01','2027-01-01','Data Collection','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Analysis of Marine Biodiversity — Study 206','Climate Action & Renewable Energy',219,2,'2025-01-01','2027-01-01','Proposed','Laboratory and field analysis of pollutant concentrations in freshwater bodies.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Wildlife Population Trends — Study 207','Wildlife Anti-Poaching & Rescue',115,38,'2024-05-01','2027-05-01','Data Analysis','Longitudinal data collection aimed at establishing baseline environmental metrics.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Mapping Marine Biodiversity — Study 208','Waste Management & Circular Economy',297,18,'2025-08-01','2026-08-01','Data Collection','Research into the socio-ecological impacts of land use change on biodiversity.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Monitoring Soil Biodiversity — Study 209','Freshwater Ecosystems',130,42,'2024-03-01','2027-03-01','Data Analysis','Assessment of ecosystem services provided by natural landscapes in Kenya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Survey of Soil Biodiversity — Study 210','Agriculture & Food Security',284,15,'2024-12-01','2026-12-01','Published','A comprehensive field study examining environmental change across selected sites.');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (174,91,4477000,'2023-04-02','GRN-4845-000');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (90,28,684000,'2025-11-04','GRN-8271-001');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (29,131,684000,'2024-04-30','GRN-4343-002');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (84,147,3092000,'2026-10-26','GRN-7815-003');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (19,165,3543000,'2024-08-02','GRN-3344-004');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (7,84,3001000,'2024-11-17','GRN-7686-005');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (167,96,3905000,'2024-08-25','GRN-1510-006');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (42,95,415000,'2024-08-18','GRN-3458-007');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (152,7,920000,'2026-06-01','GRN-4464-008');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (207,81,4234000,'2025-11-06','GRN-6636-009');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (56,97,4823000,'2023-03-08','GRN-3458-010');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (98,196,692000,'2023-06-08','GRN-4679-011');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (145,129,4755000,'2026-07-14','GRN-9982-012');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (188,108,4465000,'2023-09-06','GRN-9646-013');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (205,14,3919000,'2026-09-12','GRN-9592-014');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (134,113,2646000,'2024-07-05','GRN-4195-015');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (148,76,2049000,'2024-11-04','GRN-4982-016');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (205,197,3015000,'2024-04-17','GRN-8468-017');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (81,192,995000,'2026-11-20','GRN-4949-018');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (114,188,3408000,'2025-01-11','GRN-2305-019');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (91,144,4192000,'2023-06-06','GRN-6935-020');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (168,124,1937000,'2025-07-08','GRN-7862-021');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (59,146,1076000,'2026-01-06','GRN-5013-022');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (199,105,4840000,'2026-09-25','GRN-3263-023');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (156,67,2400000,'2024-11-30','GRN-6142-024');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (31,21,3396000,'2025-05-12','GRN-9274-025');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (38,148,4098000,'2026-07-19','GRN-4245-026');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (47,117,177000,'2023-12-08','GRN-2979-027');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (108,68,4593000,'2026-12-27','GRN-8698-028');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (191,26,1085000,'2023-03-11','GRN-8068-029');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (7,177,1417000,'2023-05-30','GRN-3168-030');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (132,136,3229000,'2025-05-14','GRN-6805-031');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (33,103,4612000,'2024-05-09','GRN-5806-032');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (31,87,2807000,'2026-04-26','GRN-2765-033');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (185,12,654000,'2024-12-27','GRN-8354-034');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (105,162,3734000,'2025-06-11','GRN-5739-035');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (194,123,1152000,'2024-01-11','GRN-9345-036');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (22,39,113000,'2026-04-30','GRN-7060-037');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (173,167,3765000,'2025-02-15','GRN-6250-038');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (113,46,4217000,'2026-04-19','GRN-5576-039');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (198,25,1952000,'2024-08-31','GRN-9082-040');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (88,13,4671000,'2025-11-26','GRN-9604-041');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (149,131,3545000,'2024-08-07','GRN-6288-042');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (99,82,1511000,'2023-10-21','GRN-1687-043');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (209,189,1775000,'2025-05-31','GRN-9505-044');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (72,148,2625000,'2023-07-23','GRN-6690-045');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (73,43,1021000,'2024-08-12','GRN-5486-046');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (125,113,1882000,'2023-12-13','GRN-5726-047');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (67,156,919000,'2024-04-19','GRN-5565-048');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (37,25,1744000,'2026-02-04','GRN-9334-049');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (194,44,274000,'2026-05-10','GRN-1651-050');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (139,138,1648000,'2023-01-14','GRN-9001-051');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (7,95,1714000,'2024-07-31','GRN-7987-052');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (188,114,4317000,'2023-09-16','GRN-8435-053');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (76,29,1032000,'2025-06-29','GRN-8082-054');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (127,68,761000,'2023-10-08','GRN-5562-055');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (188,172,1004000,'2024-12-25','GRN-2295-056');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (191,204,1872000,'2023-06-02','GRN-6359-057');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (41,130,2797000,'2024-07-19','GRN-8429-058');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (162,189,4251000,'2026-10-08','GRN-2213-059');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (181,177,2628000,'2023-03-20','GRN-8100-060');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (26,181,4320000,'2024-10-12','GRN-4119-061');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (143,170,341000,'2026-07-23','GRN-1130-062');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (63,36,4853000,'2025-02-09','GRN-4607-063');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (173,51,2223000,'2025-08-20','GRN-3481-064');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (125,209,1582000,'2025-10-14','GRN-5630-065');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (34,51,776000,'2025-11-23','GRN-4509-066');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (1,112,601000,'2025-10-01','GRN-4416-067');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (182,46,367000,'2025-05-06','GRN-5310-068');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (158,98,4833000,'2024-04-25','GRN-6713-069');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (124,136,1525000,'2024-09-06','GRN-4799-070');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (75,172,4023000,'2025-09-30','GRN-7425-071');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (154,92,4501000,'2025-09-12','GRN-5840-072');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (25,57,970000,'2024-08-11','GRN-7874-073');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (115,84,2076000,'2026-09-18','GRN-7960-074');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (30,46,3857000,'2024-10-15','GRN-2860-075');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (89,179,3311000,'2026-12-14','GRN-3098-076');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (199,124,4057000,'2026-05-15','GRN-7750-077');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (176,61,287000,'2024-08-18','GRN-5389-078');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (130,56,3400000,'2023-05-05','GRN-6295-079');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (67,173,2651000,'2025-04-22','GRN-7412-080');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (208,114,3533000,'2025-03-27','GRN-5271-081');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (14,69,4027000,'2024-03-24','GRN-6567-082');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (163,210,423000,'2024-09-23','GRN-8334-083');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (105,57,4739000,'2023-12-08','GRN-9782-084');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (53,200,953000,'2026-06-10','GRN-6401-085');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (34,155,4471000,'2023-02-10','GRN-1345-086');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (206,98,789000,'2026-12-14','GRN-6460-087');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (91,197,4579000,'2023-05-10','GRN-1806-088');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (133,54,3016000,'2026-01-01','GRN-4251-089');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (41,138,3290000,'2024-04-14','GRN-5754-090');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (206,42,3112000,'2024-11-09','GRN-7773-091');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (56,142,2087000,'2023-01-28','GRN-1591-092');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (6,194,4363000,'2023-07-29','GRN-9216-093');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (102,203,4022000,'2023-03-28','GRN-3571-094');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (73,78,248000,'2024-04-16','GRN-5051-095');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (9,70,1062000,'2025-02-12','GRN-7565-096');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (34,210,2261000,'2023-06-23','GRN-2253-097');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (19,130,3452000,'2023-02-11','GRN-1241-098');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (191,139,1293000,'2023-07-15','GRN-7408-099');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (50,156,2607000,'2024-10-24','GRN-7965-100');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (132,191,241000,'2024-09-10','GRN-5490-101');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (118,52,866000,'2024-06-25','GRN-8723-102');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (97,75,3568000,'2023-07-10','GRN-4641-103');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (105,144,2331000,'2025-09-16','GRN-5659-104');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (180,137,4200000,'2024-05-15','GRN-7265-105');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (5,128,3274000,'2025-02-02','GRN-9955-106');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (183,28,3754000,'2024-04-03','GRN-1407-107');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (102,198,1951000,'2025-07-04','GRN-7059-108');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (123,145,942000,'2026-08-09','GRN-6089-109');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (86,37,735000,'2023-07-15','GRN-3773-110');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (54,126,4911000,'2024-05-26','GRN-2374-111');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (37,104,3929000,'2025-12-07','GRN-4808-112');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (16,197,4092000,'2024-05-31','GRN-7747-113');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (80,190,2817000,'2023-11-05','GRN-1598-114');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (83,177,4681000,'2026-05-11','GRN-7660-115');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (2,69,1763000,'2026-02-25','GRN-9007-116');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (140,128,2614000,'2026-08-28','GRN-4862-117');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (83,119,4006000,'2025-11-19','GRN-2334-118');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (27,109,684000,'2025-02-08','GRN-3085-119');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (194,4,1377000,'2025-11-30','GRN-2990-120');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (43,51,3634000,'2023-08-21','GRN-1639-121');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (109,127,1448000,'2026-07-06','GRN-9594-122');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (125,36,4531000,'2025-05-06','GRN-7543-123');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (3,76,1013000,'2025-06-10','GRN-5820-124');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (185,174,2270000,'2025-12-06','GRN-6281-125');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (158,96,4668000,'2026-08-24','GRN-3718-126');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (37,75,4336000,'2026-11-03','GRN-4349-127');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (206,158,3091000,'2025-11-29','GRN-5116-128');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (121,119,1775000,'2024-11-07','GRN-3217-129');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (43,135,3931000,'2023-01-21','GRN-6205-130');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (107,46,1281000,'2025-08-21','GRN-2098-131');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (2,80,1587000,'2024-02-13','GRN-2537-132');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (138,118,2761000,'2023-07-13','GRN-2001-133');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (160,120,4919000,'2023-11-17','GRN-2093-134');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (90,163,4630000,'2024-04-07','GRN-6651-135');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (161,4,1628000,'2024-07-16','GRN-5656-136');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (110,150,2554000,'2025-01-22','GRN-7607-137');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (66,144,4482000,'2026-08-06','GRN-4319-138');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (20,152,1298000,'2023-07-30','GRN-4546-139');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (72,46,2203000,'2026-02-28','GRN-2676-140');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (33,205,4328000,'2026-04-17','GRN-7274-141');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (85,148,4901000,'2026-05-23','GRN-5542-142');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (207,189,3928000,'2024-03-04','GRN-3754-143');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (1,201,1949000,'2024-03-19','GRN-2496-144');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (206,158,1250000,'2023-10-21','GRN-3700-145');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (122,1,2698000,'2023-06-09','GRN-1855-146');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (36,131,3651000,'2025-05-21','GRN-8728-147');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (84,78,4149000,'2023-08-29','GRN-4944-148');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (144,101,3140000,'2025-02-28','GRN-8773-149');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (91,80,4326000,'2024-10-11','GRN-9694-150');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (21,155,1802000,'2023-12-07','GRN-5550-151');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (183,37,3631000,'2026-02-21','GRN-8235-152');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (126,178,2102000,'2026-11-04','GRN-2970-153');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (143,112,2902000,'2023-12-31','GRN-1414-154');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (94,120,2884000,'2025-05-18','GRN-4502-155');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (158,144,1614000,'2025-02-22','GRN-7130-156');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (46,192,137000,'2024-02-06','GRN-8243-157');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (93,135,1646000,'2023-01-12','GRN-6085-158');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (85,25,3071000,'2024-06-03','GRN-9237-159');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (4,156,2286000,'2023-03-10','GRN-5504-160');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (165,123,3312000,'2023-03-31','GRN-5145-161');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (71,161,518000,'2026-03-17','GRN-1498-162');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (184,121,3773000,'2025-10-01','GRN-3847-163');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (122,192,4519000,'2023-08-01','GRN-1625-164');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (95,8,1304000,'2026-12-16','GRN-3898-165');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (34,22,3487000,'2023-09-02','GRN-1918-166');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (114,164,560000,'2024-10-05','GRN-2597-167');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (140,72,1640000,'2026-09-03','GRN-1273-168');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (86,173,2642000,'2026-12-23','GRN-3772-169');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (151,185,3050000,'2025-11-23','GRN-1232-170');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (171,104,3460000,'2026-09-29','GRN-2007-171');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (17,50,4158000,'2023-10-30','GRN-5368-172');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (22,45,3682000,'2023-04-02','GRN-5514-173');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (156,51,4190000,'2025-04-18','GRN-3833-174');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (163,192,76000,'2024-09-29','GRN-5485-175');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (144,90,1014000,'2024-11-30','GRN-8639-176');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (146,179,755000,'2026-03-05','GRN-8585-177');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (23,30,791000,'2024-01-09','GRN-2415-178');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (48,82,4892000,'2026-07-07','GRN-1329-179');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (197,44,135000,'2024-03-21','GRN-7136-180');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (118,21,2071000,'2024-09-22','GRN-4130-181');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (192,194,1137000,'2024-09-27','GRN-1873-182');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (98,181,2401000,'2023-12-31','GRN-5570-183');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (36,145,2634000,'2025-04-27','GRN-4702-184');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (49,70,1682000,'2023-12-29','GRN-5832-185');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (67,179,3651000,'2024-06-25','GRN-2514-186');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (126,91,4790000,'2025-01-14','GRN-6715-187');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (198,165,4334000,'2025-07-09','GRN-3793-188');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (10,150,3209000,'2023-11-15','GRN-9813-189');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (146,54,3604000,'2024-12-11','GRN-5729-190');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (54,88,4176000,'2026-02-03','GRN-5406-191');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (24,132,1776000,'2024-06-12','GRN-4575-192');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (120,67,307000,'2023-08-25','GRN-9471-193');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (169,162,1577000,'2025-08-31','GRN-3290-194');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (120,151,2695000,'2025-02-01','GRN-7191-195');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (169,151,327000,'2024-10-22','GRN-2713-196');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (162,92,114000,'2023-11-22','GRN-7904-197');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (122,86,2808000,'2026-08-19','GRN-2641-198');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (48,92,2559000,'2023-11-30','GRN-8648-199');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (140,148,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (113,308,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (152,248,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (188,203,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (63,165,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (154,187,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (174,203,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (11,160,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (108,210,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (148,203,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (42,232,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (77,253,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (146,293,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (34,270,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (202,114,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (80,303,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (206,189,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (102,143,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (1,269,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (52,145,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (79,121,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (61,153,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (24,286,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,276,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (2,223,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (89,126,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (141,276,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (179,155,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (172,197,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (181,163,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (100,133,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (196,135,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (198,184,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (210,273,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (153,201,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (89,226,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (57,256,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (197,161,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (93,188,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (157,254,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (20,266,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (36,228,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (12,155,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (112,124,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (99,268,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,139,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (80,200,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (9,167,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (46,142,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (175,233,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (120,307,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (89,276,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (168,204,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (42,182,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (148,230,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (176,217,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (125,268,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,298,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (78,209,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (190,263,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (155,307,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (129,196,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (183,186,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (29,302,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,237,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (173,121,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (2,187,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (51,232,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (112,113,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (73,111,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (126,218,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (13,254,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (65,209,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (173,176,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (139,169,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (76,192,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (5,215,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (77,263,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (153,129,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (188,110,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (64,145,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (137,125,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (187,138,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (111,171,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (118,277,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (188,311,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (11,120,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (96,110,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (156,286,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (98,232,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (87,264,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,203,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (48,292,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (185,268,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (111,130,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (147,167,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (158,232,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (178,305,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (96,247,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (56,295,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (71,292,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (71,229,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (155,203,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (174,173,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (2,205,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (5,301,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (169,134,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (69,219,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (25,157,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (5,282,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (57,117,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (187,283,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (151,208,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (139,200,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (143,104,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (88,182,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (114,139,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (191,228,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (137,279,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (173,200,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (104,109,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (162,225,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (22,154,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (78,175,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (116,273,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (8,140,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (160,191,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (107,296,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (193,173,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (61,197,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (97,256,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (25,202,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (55,129,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (46,141,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (141,205,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (193,156,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (154,172,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (198,193,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (171,276,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (129,238,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (58,204,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (194,219,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (116,141,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (103,174,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (137,313,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (196,219,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (175,126,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (149,268,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (108,206,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (163,108,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (36,257,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (154,247,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (6,184,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (43,246,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (176,124,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (6,291,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (142,231,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (42,218,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (186,162,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (121,283,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (83,134,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (17,108,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (148,219,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (63,276,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (62,304,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (119,229,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (206,255,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (41,163,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (185,118,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (192,109,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (134,221,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (19,301,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (67,284,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (184,299,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (113,224,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (75,308,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (186,297,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (94,203,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (110,302,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (27,138,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (195,312,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (185,144,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (106,269,'Lab Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (37,163,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (54,168,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (85,265,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (118,282,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (193,163,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (88,176,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (85,302,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (180,167,'Legal Advisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (153,110,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (38,234,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (7,157,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (145,193,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (79,284,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (146,263,'Communications Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (122,283,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (173,176,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (191,307,'Environmental Scientist');

INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (316,'Tom','Odhiambo','1988-04-12','ID-30001','Male',47,'expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (317,'Ann','Chebet','1993-07-22','ID-31001','Female',36,'associate expert',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (318,'Mark','Wafula','1991-11-08','ID-32001','Male',39,'subordinate',103);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (319,'Lena','Muthoni','1986-05-30','ID-33001','Female',19,'expert',105);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (320,'Eric','Barasa','1984-09-14','ID-34001','Male',12,'manager',NULL);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (321,'Zoe','Njeri','1995-02-28','ID-35001','Female',22,'associate expert',101);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (322,'Ian','Ouma','1990-12-01','ID-36001','Male',42,'subordinate',102);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (323,'Rita','Auma','1992-06-19','ID-37001','Female',1,'expert',107);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (324,'Ken','Sigei','1983-04-05','ID-38001','Male',27,'associate expert',112);
INSERT INTO Employees (EmployeeID,FirstName,LastName,DateOfBirth,IDNumber,Gender,BranchID,JobTitle,ManagerID) VALUES (325,'Dora','Bett','1997-08-11','ID-39001','Female',45,'subordinate',102);

INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (211,'Tana Delta Conservation Trust','Marine & Coastal Conservation',4,'info@tanadelta.co.ke','0711001001');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (212,'Kisii Organic Farmers','Agriculture & Food Security',45,'kisiiorganic@gmail.com','0722002002');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (213,'Nairobi Air Watch','Climate Action & Renewable Energy',47,'airwatch@nairobi.co.ke','0733003003');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (214,'Embu Water Initiative','WASH (Water, Sanitation & Hygiene)',14,'embuwater@init.co.ke','0744004004');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (215,'Kakamega Forest Friends','Wildlife Anti-Poaching & Rescue',37,'kakforest@friends.co.ke','0755005005');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (216,'Lamu Marine Society','Marine & Coastal Conservation',5,'lamu@marine.co.ke','0766006006');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (217,'Thika Waste Recyclers','Waste Management & Circular Economy',22,'thika@recyclers.co.ke','0777007007');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (218,'Rift Valley Climate Hub','Climate Action & Renewable Energy',32,'rift@climatehub.co.ke','0788008008');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (219,'Siaya Community Health','Public Health & Medicine',41,'siaya@health.co.ke','0799009009');
INSERT INTO Organizations (OrganizationID,OrganizationName,OrganizationFocus,BranchID,ContactEmail,ContactPhone) VALUES (220,'Marsabit Disaster Relief','Disaster Relief',10,'marsabit@relief.co.ke','0700010010');

INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (211,'Tana Delta Mangrove Survey','Marine & Coastal Conservation',6200000,'2026-01-10','2027-01-10',4,107);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (212,'Kisii Organic Certification Drive','Agriculture & Food Security',2100000,'2026-02-01','2027-02-01',45,113);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (213,'Nairobi Air Quality Monitoring','Climate Action & Renewable Energy',3400000,'2026-03-01','2027-03-01',47,112);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (214,'Embu Borehole Rehabilitation','WASH (Water, Sanitation & Hygiene)',1900000,'2026-01-20','2026-12-20',14,106);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (215,'Kakamega Anti-Snare Campaign','Wildlife Anti-Poaching & Rescue',2700000,'2026-02-15','2027-02-15',37,103);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (216,'Lamu Coral Mapping','Marine & Coastal Conservation',3100000,'2026-03-10','2027-03-10',5,110);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (217,'Thika E-Waste Collection','Waste Management & Circular Economy',1600000,'2026-01-05','2026-12-05',22,115);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (218,'Nakuru Solar Schools','Climate Action & Renewable Energy',4500000,'2026-04-01','2027-10-01',32,112);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (219,'Siaya Maternal Health Drive','Public Health & Medicine',2200000,'2026-02-20','2027-02-20',41,106);
INSERT INTO Projects (ProjectID,ProjectName,ProjectType,Budget,StartDate,EndDate,BranchID,ProjectLeadID) VALUES (220,'Marsabit Flood Early Warning','Disaster Relief',3800000,'2026-03-15','2027-03-15',10,108);

INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Kenya Wildlife Service','Government','Dr. Erustus Kanga','ekanga@kws.go.ke','0201234501');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Safarilink Foundation','Corporate','Lucy Wanjiru','lwanjiru@safarilink.co.ke','0711234502');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('WWF Kenya','International NGO','James Mwenda','jmwenda@wwf.org','0722234503');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Centum Foundation','Corporate','Alice Nderitu','anderitu@centum.co.ke','0733234504');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('GIZ Kenya','International NGO','Hans Muller','hmuller@giz.de','0744234505');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('USAID East Africa','International NGO','Maria Lopez','mlopez@usaid.gov','0755234506');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Kenya Red Cross','Foundation','John Mwangi','jmwangi@redcross.co.ke','0766234507');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Barclays Foundation','Corporate','Patel Raj','rpatel@barclays.co.ke','0777234508');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('East Africa Development Bank','Government','Dr. Amara Diallo','adiallo@eadb.org','0788234509');
INSERT INTO Donors (DonorName,DonorType,ContactPerson,ContactEmail,ContactPhone) VALUES ('Africa Wildlife Foundation','Foundation','Susan Njoki','snjoki@awf.org','0799234510');

INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (211,1,'Environmental Impact','2026-01-05','Approved','2026-01-20','2027-01-20');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (212,2,'Water Abstraction','2026-02-10','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (213,3,'Waste Disposal','2026-01-15','Approved','2026-02-01','2027-02-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (214,4,'Emissions','2026-03-01','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (215,5,'Environmental Impact','2025-11-10','Approved','2025-12-01','2026-12-01');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (216,6,'Water Abstraction','2026-02-20','Rejected',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (217,7,'Waste Disposal','2026-01-25','Approved','2026-02-10','2027-02-10');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (218,8,'Emissions','2026-03-05','Pending Inspection',NULL,NULL);
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (219,9,'Environmental Impact','2026-01-30','Approved','2026-02-15','2027-02-15');
INSERT INTO Licenses (LicenseID,OrganizationID,LicenseType,ApplicationDate,LicenseStatus,IssueDate,ExpiryDate) VALUES (220,10,'Other','2025-12-15','Revoked',NULL,NULL);

INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (211,101,'2026-01-18','Pass','All environmental conditions met satisfactorily.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (212,102,'2026-03-05','Scheduled','Pending site visit by water quality team.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (213,103,'2026-01-28','Pass','Waste handling procedures are fully compliant.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (214,104,'2026-03-12','Scheduled','Emissions test booked for next quarter.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (215,105,'2025-11-25','Pass','Impact assessment approved by regional officer.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (216,106,'2026-02-22','Fail','Abstraction volumes exceed permitted daily limits.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (217,107,'2026-02-08','Pass','Disposal site meets all landfill safety standards.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (218,108,'2026-03-07','Pending Remediation','Emission filters need replacement within 30 days.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (219,109,'2026-02-17','Pass','All construction impact measures are in place.');
INSERT INTO Inspections (LicenseID,InspectorID,InspectionDate,InspectionResult,Remarks) VALUES (220,110,'2025-12-18','Fail','License conditions repeatedly violated. Revoked.');

INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-03-18','Fishing nets illegally set inside marine protected area.',4,107,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Agriculture & Food Security','2026-02-25','Pesticide poisoning of bees reported by local farmers.',45,113,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2026-03-22','Smoke haze from charcoal kilns affecting Nairobi air quality.',47,112,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('WASH (Water, Sanitation & Hygiene)','2026-01-28','Broken water pipe contaminating borehole near Embu town.',14,106,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Wildlife Anti-Poaching & Rescue','2026-03-02','Three elephants found with gunshot wounds near Kakamega.',37,103,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Marine & Coastal Conservation','2026-03-25','Ghost nets entangling sea turtles off Lamu coastline.',5,110,'Open');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Waste Management & Circular Economy','2026-02-14','Electronics dumped illegally behind Thika industrial park.',22,115,'Closed');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Climate Action & Renewable Energy','2026-04-01','Dust storm caused by sand harvesting near Nakuru lake.',32,112,'Investigating');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Public Health & Medicine','2026-03-08','Malaria outbreak in Siaya linked to stagnant water bodies.',41,106,'Resolved');
INSERT INTO Incidents (IncidentType,IncidentDate,Description,BranchID,ReportedByID,ResolutionStatus) VALUES ('Disaster Relief','2026-03-30','Flash floods destroyed 3 bridges in Marsabit subcounty.',10,108,'Investigating');

INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (211,211,3100000,'2026-01-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (211,212,3100000,'2026-01-09');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (212,213,2100000,'2026-01-25');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (213,214,3400000,'2026-02-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (214,215,1900000,'2026-01-18');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (215,216,2700000,'2026-02-12');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (216,217,3100000,'2026-03-08');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (217,218,1600000,'2026-01-03');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (218,219,4500000,'2026-03-28');
INSERT INTO ProjectFunding (ProjectID,DonorID,Amount,FundingDate) VALUES (219,220,2200000,'2026-02-18');

INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (211,102,'Marine & Coastal Conservation','2026-01-15','Completed',87.5,'2027-01-15');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (212,113,'Agriculture & Food Security','2026-02-03','Completed',79.0,'2027-02-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (213,112,'Climate Action & Renewable Energy','2026-03-03','Completed',93.0,'2027-03-03');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (214,106,'WASH (Water, Sanitation & Hygiene)','2026-01-22','In Progress',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (215,103,'Wildlife Anti-Poaching & Rescue','2026-02-17','Completed',85.5,'2027-02-17');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (216,110,'Marine & Coastal Conservation','2026-03-12','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (217,115,'Waste Management & Circular Economy','2026-01-07','Completed',90.25,'2027-01-07');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (218,112,'Climate Action & Renewable Energy','2026-04-03','Scheduled',NULL,NULL);
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (219,106,'Public Health & Medicine','2026-02-22','Completed',82.0,'2027-02-22');
INSERT INTO EnvironmentalAudits (OrganizationID,LeadAuditorID,AuditFocus,AuditDate,AuditStatus,ComplianceScore,NextAuditDate) VALUES (220,108,'Disaster Relief','2026-03-31','In Progress',NULL,NULL);

INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Tana Delta Mangrove Carbon Study','Marine & Coastal Conservation',107,4,'2026-01-10','2027-06-10','Data Collection','Assessing carbon storage capacity of mangrove ecosystems in the Tana Delta.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Pesticide Impact on Kisii Pollinators','Agriculture & Food Security',113,45,'2026-02-01','2027-02-01','Data Collection','Field study on declining bee populations linked to agricultural chemical use.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Urban Air Quality Index Nairobi','Climate Action & Renewable Energy',112,47,'2026-03-01','2027-03-01','Data Analysis','Monitoring PM2.5 and CO2 levels across 10 Nairobi zones over 12 months.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Groundwater Salinity in Embu','WASH (Water, Sanitation & Hygiene)',106,14,'2026-01-20','2026-12-20','Data Collection','Testing salinity and heavy metal levels in borehole water across Embu county.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Elephant Corridor Mapping Kakamega','Wildlife Anti-Poaching & Rescue',103,37,'2026-02-15','2027-08-15','Data Collection','GPS-tagging study to map elephant movement through Kakamega forest patches.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Lamu Sea Turtle Nesting Patterns','Marine & Coastal Conservation',110,5,'2026-03-10','2027-09-10','Data Collection','Tracking nesting site selection and clutch success of green turtles on Lamu beaches.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('E-Waste Heavy Metals in Thika Soil','Waste Management & Circular Economy',115,22,'2026-01-05','2026-12-05','Data Analysis','Laboratory analysis of lead and mercury leaching from informal e-waste dumps.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Solar Irradiance Mapping Nakuru','Climate Action & Renewable Energy',112,32,'2026-04-01','2027-04-01','Proposed','Proposed study mapping optimal solar panel placement in peri-urban Nakuru.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Malaria Vector Breeding in Siaya','Public Health & Medicine',106,41,'2026-02-20','2027-02-20','Data Collection','Identifying Anopheles mosquito breeding hotspots linked to land use in Siaya.');
INSERT INTO ResearchStudies (StudyTitle,FocusArea,LeadResearcherID,BranchID,StartDate,EndDate,StudyStatus,Abstract) VALUES ('Flash Flood Risk Modelling Marsabit','Disaster Relief',108,10,'2026-03-15','2027-03-15','Data Collection','Hydrological modelling of flood-prone catchments in Marsabit using satellite data.');

INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (211,211,1550000,'2026-01-06','KWS-TDM-001');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (212,212,1050000,'2026-01-23','SAF-KSI-002');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (213,213,1700000,'2026-02-26','WWF-NAI-003');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (214,214,950000,'2026-01-16','CTM-EMB-004');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (215,215,1350000,'2026-02-10','GIZ-KAK-005');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (216,216,1550000,'2026-03-06','USA-LAM-006');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (217,217,800000,'2026-01-01','KRC-THK-007');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (218,218,2250000,'2026-03-26','BAR-NKR-008');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (219,219,1100000,'2026-02-16','EAD-SIA-009');
INSERT INTO ResearchFunding (StudyID,DonorID,Amount,FundingDate,GrantReferenceNumber) VALUES (220,220,1900000,'2026-03-28','AWF-MRS-010');

INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (211,107,'Marine Surveyor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (211,110,'Field Ecologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (212,113,'Lead Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (212,114,'Field Trainer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (213,101,'Project Director');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (213,116,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (214,106,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (214,108,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (215,103,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (215,105,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (164,129,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (190,171,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (58,136,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (27,274,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (140,123,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,109,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (24,156,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (130,255,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (144,151,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (167,280,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (108,157,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (151,172,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (2,295,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (41,279,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (88,172,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (56,296,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (27,124,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (25,192,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (155,168,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (12,287,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (138,132,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (21,242,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (213,261,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (93,248,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (181,118,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (170,159,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (75,121,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (26,198,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (117,263,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (42,195,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (54,272,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (180,275,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (19,256,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (44,237,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (63,142,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (98,170,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (177,243,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (176,184,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (199,115,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (211,109,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (81,203,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (17,155,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (184,181,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (168,228,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (165,218,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,136,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (191,244,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,292,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (110,250,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (93,157,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (131,227,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (194,113,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,261,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (203,275,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (153,117,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (98,253,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (136,165,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (3,275,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (30,275,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (193,169,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (165,188,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (76,212,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (117,101,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (185,168,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (196,146,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (28,323,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (77,316,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (130,256,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,196,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (42,239,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (136,101,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (83,226,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (29,193,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (79,162,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (62,325,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (21,122,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (125,309,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (195,237,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (33,133,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (122,241,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,236,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,155,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (194,287,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (52,283,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (103,272,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (96,213,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (116,131,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (58,117,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (6,251,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (59,251,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (2,119,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (162,116,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (18,109,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (19,232,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (72,272,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (55,239,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (186,247,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (122,163,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (122,307,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (49,125,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (169,211,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,206,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (187,114,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (168,266,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (16,204,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (87,305,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (64,150,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (138,215,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (109,147,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (119,164,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (114,307,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (26,113,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (139,315,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (24,293,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (43,205,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (124,155,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (16,143,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (1,200,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (201,301,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (74,209,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (188,301,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (170,284,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,149,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (56,115,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (189,239,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (192,181,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (13,250,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (129,319,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (41,115,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (21,318,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (18,253,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (173,321,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (104,131,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (64,249,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (11,259,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (108,269,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (145,234,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (67,153,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (184,181,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,202,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (172,266,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (118,181,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (19,103,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (160,245,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (19,238,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (130,168,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (90,118,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (95,173,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (113,314,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (181,178,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (207,268,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (3,271,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (77,270,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (35,168,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (28,291,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,170,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (155,154,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (88,153,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (163,319,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (130,226,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (217,114,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (163,209,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (12,101,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (198,134,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,142,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (114,242,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (110,244,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (29,120,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (39,240,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (214,195,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (142,138,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (33,111,'Environmental Scientist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (94,304,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (92,154,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (64,271,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (91,300,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (105,259,'Marine Biologist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (40,161,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (205,308,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (106,107,'Community Liaison');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (189,186,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (106,306,'Agronomist');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (189,308,'Site Supervisor');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (69,141,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (180,128,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (10,320,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (57,152,'Finance Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (90,179,'Climate Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (59,158,'Field Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (169,150,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (85,172,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (198,172,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (165,231,'Health Officer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (174,316,'Wildlife Ranger');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (85,108,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (67,146,'Water Engineer');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (68,110,'Data Analyst');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (153,212,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (187,302,'GIS Technician');
INSERT INTO ProjectTeam (ProjectID,EmployeeID,ProjectRole) VALUES (112,256,'Wildlife Ranger');
SET FOREIGN_KEY_CHECKS = 1;
